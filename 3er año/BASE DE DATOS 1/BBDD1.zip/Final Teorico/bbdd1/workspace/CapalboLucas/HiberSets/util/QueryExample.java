package util;

import java.util.Iterator;

import model.Estacionamiento;
import model.SEM;
import model.Zona;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.concurrent.*;

public class QueryExample {

	private static SessionFactory sessions;


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		try {

			System.out
					.println("----------------------- Setting up Hibernate -----------------------");
			Configuration cfg = new Configuration();
			cfg.configure();

			System.out.println("Building sessions.........");

			sessions = cfg.buildSessionFactory();
			long start = System.nanoTime(); //Inicio del timer para medir la duraccion de la consulta

			makeQueries();
			
			long elapsedTime = System.nanoTime() - start;   //Calculo de la duraccion en nanosegundos
			
			//Diferentes formas de mostrar el resultado
			System.out.println("Tiempo transcurrido: " + elapsedTime + " nanosegundos");
			//convert to seconds 
			TimeUnit seconds = TimeUnit.NANOSECONDS;
			System.out.println("Que tambien es equivalente a  " + seconds.toMillis(elapsedTime) + " milisegundos");
			System.out.println("Que tambien es equivalente a  " + seconds.toSeconds(elapsedTime) + " segundos");

		} catch (Exception e) {
			System.out
					.println("------------------------FAIL.------------------------");
			e.printStackTrace();
		}

		
		
	}

	/**
	 * Para la forma de listas , sacar las resstricciones del not null para la infraccion y el vehiuclo.

utilizar basicamente la misma confirguracion que antes.
	 */

	private static void makeQueries() {
        Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction(); //Inicia la transaccion
			SEM semPersistido = (SEM) session.load(SEM.class, new Long(1)); //Obtiene el sistema con id 1. En este caso el unico
			System.out.println("Cantidad de dispositivos moviles: " + semPersistido.getDispositivosMoviles().size());
			
			Iterator<Estacionamiento> estacionamientos = semPersistido.getEstacionamientos().iterator();
			while (estacionamientos.hasNext()) {
				Estacionamiento estacionamiento = (Estacionamiento) estacionamientos.next();
				System.out.println("Estacionamiento");
				
			}
			
			
			//Obtiene el iterador para la coleccion de zonas.
			Iterator<Zona> zonasIterador =  semPersistido.getZonas().iterator();
			while (zonasIterador.hasNext()) {
				Zona zona = (Zona) zonasIterador.next();
				System.out.println("Zona: " + zona.getDescripcion()); //Imprime en consola una zona particular y su descripcion
			}
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)
				tx.rollback();
			session.close();
		}
		session.disconnect();
		
	}
}
