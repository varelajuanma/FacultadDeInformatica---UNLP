package model;

import java.util.Collection;
import java.util.HashSet;

public class Inspector {

    private Long oid;
    private String nombre;
    private String apellido;
    private String legajo;

    private Collection<Infraccion> infracciones;
    private DispositivoMovil dispositivoMovil;


    public Inspector(){
        this.setInfracciones(new HashSet<Infraccion>());
    }

    public Inspector(String nombre, String apellido, String legajo, DispositivoMovil dispositivoMovil){
        this.setNombre(nombre);
        this. setApellido(apellido);
        this.setLegajo(legajo);
        this.setDispositivoMovil(dispositivoMovil);
        this.setInfracciones(new HashSet<Infraccion>());
    }

    public Long getOid() {
        return oid;
    }
    public void setOid(Long oid) {
        this.oid = oid;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getLegajo() {
        return legajo;
    }
    public void setLegajo(String legajo) {
        this.legajo = legajo;
    }
    public Collection<Infraccion> getInfracciones() {
        return infracciones;
    }
    public void setInfracciones(Collection<Infraccion> infracciones) {
        this.infracciones = infracciones;
    }
    public DispositivoMovil getDispositivoMovil() {
        return dispositivoMovil;
    }
    public void setDispositivoMovil(DispositivoMovil dispositivoMovil) {
        this.dispositivoMovil = dispositivoMovil;
    }

    public void agregarInfraccion(Infraccion infraccion) {
        this.getInfracciones().add(infraccion);
    }




}
