package model;

import java.util.Collection;
import java.util.HashSet;

public class SEM {
    private Collection<Estacionamiento> estacionamientos;
    private Collection<Zona> zonas;
    private Collection<DispositivoMovil> dispositivosMoviles;
    private Long oid;

    public SEM(){
        this.setEstacionamientos(new HashSet<Estacionamiento>());
        this.setZonas(new HashSet<Zona>());
        this.setDispositivosMoviles(new HashSet<DispositivoMovil>());
    }


    public Collection<DispositivoMovil> getDispositivosMoviles() {
        return dispositivosMoviles;
    }



    public void setDispositivosMoviles(
            Collection<DispositivoMovil> dispositivosMoviles) {
        this.dispositivosMoviles = dispositivosMoviles;
    }



    public void agregarZona(Zona zona) {
        this.getZonas().add(zona);
    }

    public Collection<Zona> getZonas() {
        return zonas;
    }


    public void setZonas(Collection<Zona> zonas) {
        this.zonas = zonas;
    }


    public Collection<Estacionamiento> getEstacionamientos() {
        return estacionamientos;
    }

    public void setEstacionamientos(Collection<Estacionamiento> estacionamientos) {
        this.estacionamientos = estacionamientos;
    }

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public void agregarEstacionamiento(Estacionamiento estacionamiento){
        this.getEstacionamientos().add(estacionamiento);
    }

    public void agregarDispositivoMovil(DispositivoMovil dispositivoMovil) {
        this.getDispositivosMoviles().add(dispositivoMovil);
    }

}
