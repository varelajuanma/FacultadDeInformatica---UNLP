package model;

import java.util.Collection;
import java.util.HashSet;

public class Vehiculo {

    private Long oid;
    private String patente;
    private Collection<Estacionamiento> estacionamientos;
    //private List<Estacionamiento> estacionamientos;
    private Collection<Infraccion> infracciones;

    public Vehiculo(){
        this.setEstacionamientos(new HashSet<Estacionamiento>());
        this.setInfracciones(new HashSet<Infraccion>());
        /**
         * Armar con diferentes tipos de colecciones:
         * Usar un HashSet mape con List e indice
         * usar un HashSet y mapear con bag
         *
         * Numero de objetos: 20000.
         *
         */
    }

    public Vehiculo(String patente){
        this.setPatente(patente);
        this.setEstacionamientos(new HashSet<Estacionamiento>());
        this.setInfracciones(new HashSet<Infraccion>());

    }



    public Collection<Infraccion> getInfracciones() {
        return infracciones;
    }

    public void setInfracciones(Collection<Infraccion> infracciones) {
        this.infracciones = infracciones;
    }

    private void setPatente(String patente2) {
        this.patente=patente2;

    }

    public String getPatente(){
        return this.patente;
    }

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public Collection<Estacionamiento> getEstacionamientos() {
        return estacionamientos;
    }

    public void setEstacionamientos(Collection<Estacionamiento> estacionamientos) {
        this.estacionamientos = estacionamientos;
    }

    public void agregarEstacionamiento(Estacionamiento estacionamiento) {
        this.getEstacionamientos().add(estacionamiento);

    }

    public void agregarInfraccion(Infraccion infraccion){
        this.getInfracciones().add(infraccion);
    }

    
    
    
    
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((patente == null) ? 0 : patente.hashCode());
//		return result;
//	}
//
//	
//	
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Vehiculo other = (Vehiculo) obj;
//		if (patente == null) {
//			if (other.patente != null)
//				return false;
//		} else if (!patente.equals(other.patente))
//			return false;
//		return true;
//	}

}
