package model;

import java.util.Date;

public class EstacionamientoSMS extends Estacionamiento {
	
	private String numeroCelular;

	public EstacionamientoSMS() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EstacionamientoSMS(Date fecha, Integer horaInicio, Integer horaFin, Vehiculo vehiculo, String celular) {
		super(fecha, horaInicio, horaFin, vehiculo);
		this.setNumeroCelular(celular);
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}


	
	

}
