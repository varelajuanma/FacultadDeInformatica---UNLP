package model;

import java.util.Date;

public class EstacionamientoPuntual extends Estacionamiento {

	public EstacionamientoPuntual() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EstacionamientoPuntual(Date fecha, Integer horaInicio, Integer horaFin, Vehiculo vehiculo) {
		super(fecha, horaInicio, horaFin, vehiculo);
		// TODO Auto-generated constructor stub
	}
	
	

}
