package model;

public class PuntoDeVenta {
	
	private Long oid;
	private String calle;
	private Integer numero;
	private String propietario;
	private String telefono;
	
	public PuntoDeVenta(){
		
	}
	
	public PuntoDeVenta(String calle, Integer numero, String propietario, String telefono){
		this.setCalle(calle);
		this.setNumero(numero);
		this.setPropietario(propietario);
		this.setTelefono(telefono);
	}
	
	
	public Long getOid() {
		return oid;
	}
	public void setOid(Long oid) {
		this.oid = oid;
	}
	public String getCalle() {
		return calle;
	}
	public void setCalle(String calle) {
		this.calle = calle;
	}
	public Integer getNumero() {
		return numero;
	}
	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	public String getPropietario() {
		return propietario;
	}
	public void setPropietario(String propietario) {
		this.propietario = propietario;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	
	

}
