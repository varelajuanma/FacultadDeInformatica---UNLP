package model;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;

public abstract class SEMRepository {
	public abstract List<Infraccion> getInfraccionesQry(Session s, String apellido, String zona, Date fecha, String empiezanCon);
}
