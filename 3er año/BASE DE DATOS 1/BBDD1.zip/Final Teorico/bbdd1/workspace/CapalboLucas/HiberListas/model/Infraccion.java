package model;

import java.util.Date;

public class Infraccion {
	private Long oid;
	private Date fecha;
	private Integer hora;
	private String observacion;
	private Inspector inspector;
	private Zona zona;
	private Vehiculo vehiculo;
	
	
	public Infraccion(){
		
	}
	
	public Infraccion(Date fecha, Integer hora, String observacion, Inspector inspector, Zona zona, Vehiculo vehiculo){
		this.setFecha(fecha);
		this.setHora(hora);
		this.setObservacion(observacion);
		this.setInspector(inspector);
		this.getInspector().agregarInfraccion(this);
		this.setZona(zona);
		this.setVehiculo(vehiculo);
		this.getVehiculo().agregarInfraccion(this);
	}
	
	
	public Long getOid() {
		return oid;
	}
	public void setOid(Long oid) {
		this.oid = oid;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public Integer getHora() {
		return hora;
	}
	public void setHora(Integer hora2) {
		this.hora = hora2;
	}
	public String getObservacion() {
		return observacion;
	}
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	public Inspector getInspector() {
		return inspector;
	}
	public void setInspector(Inspector inspector) {
		this.inspector = inspector;
	}
	public Zona getZona() {
		return zona;
	}
	public void setZona(Zona zona) {
		this.zona = zona;
	}
	public Vehiculo getVehiculo() {
		return vehiculo;
	}
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}
	
	
	

}
