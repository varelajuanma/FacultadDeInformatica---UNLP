package model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class SEMRepositoryHQL extends SEMRepository {

	@Override
	public List<Infraccion> getInfraccionesQry(Session s, String apellido,
			String zona, Date fecha, String empiezanCon) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Query hqlQuery = s.createQuery("Select i " +
		//SIN JOINS
				"from Infraccion i " +
				"where i.zona.descripcion = :zdesc AND i.inspector.apellido = :ape " +
				"      AND i.fecha = :fec AND i.vehiculo.patente LIKE '%" + empiezanCon + "'") 
		//CON JOINS, mismo orden que al resolverlo con iteradores		
		/*		"from Zona z inner join z.inspectores ins inner join ins.infracciones i inner join i.vehiculo v " +
				"where z.descripcion = :zdesc AND ins.apellido = :ape AND i.fecha = :fec AND v.patente LIKE '%" + empiezanCon + "'") */ 
		//CON JOINS, a partir de las infracciones directamente
		/*   	"from Infraccion i inner join i.zona z inner join i.inspector ins " +
				"where z.descripcion = :zdesc AND ins.apellido = :ape AND i.fecha = :fec AND i.vehiculo.patente LIKE '%" + empiezanCon + "'") */
				.setString("zdesc", zona)
				.setString("ape", apellido)
				.setString("fec", df.format(fecha));
		return hqlQuery.list();
	}
	
	
/*	Obtener las infracciones realizadas por un vehiculo (se ingresa como dato del vehículo su patente) ordenadas por fecha de
	forma ascendente */
	public List<Infraccion> getInfraccionesVehiculo(Session s, String patente) {
		Query hqlQuery = s.createQuery("Select i " +
		//SIN JOIN
				"from Infraccion i where i.vehiculo.patente = :pat " +
		//CON JOIN
		/*		"from Vehiculo v inner join v.infracciones i " +
				"where v.patente = :pat " + */
				"order by i.fecha")
				.setString("pat", patente);
		return hqlQuery.list();
	}

	
/* 	9.2. Obtener todos vehículos que alguna vez han cometido alguna infracción. Tener en cuenta que cada vehículo debe aparecer
	una sola vez en el listado*/
	public List<Vehiculo> getVehiculosConInfraccion(Session s) {
		Query hqlQuery = s.createQuery(
		//CON JOIN (inner join, tiene que haber infracciones, es necesario el distinct)
		/*		"Select distinct v " +
		  		"from Vehiculo v inner join v.infracciones");
		*/
		//SIN JOIN, consultando el tamaño de la colección de infracciones de cada vehiculo, no precisa distinct
		/*		"Select v " +
				"from Vehiculo v WHERE size(v.infracciones)>0");
		*/
		//SIN JOIN, preguntando si hay elementos en la colección (elements()), no precisa distinct
				"Select v " +
				"from Vehiculo v WHERE EXISTS elements(v.infracciones)");
		return hqlQuery.list();
	}
	
/*	9.3. Para cada vehiculo, obtener la cantidad total de infracciones realizadas en un periodo dado.
 *  Ordenar el listado por patente */
	//DEVUELVE UNA LISTA DE ARREGLOS Object[] UNO POR CADA CAMPO 
	public List getCantidadInfraccionesVehiculos(Session s, Date fD, Date fH) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Query hqlQuery = s.createQuery(
				"Select v.patente, count(i) " + 
				"from Vehiculo v inner join v.infracciones i " +
				"where i.fecha between :fD and :fH " + 
				"group by v.patente " +
				"order by v.patente")
			.setString("fD", df.format(fD))
			.setString("fH", df.format(fH));
		return hqlQuery.list();
	}
	
	/* podría no ser necesario?? usando s.load(Vehiculo.class, oid) pero es por oid que no lo sabemos... */
	public Vehiculo getVehiculo(Session s, String patente) {
		Query hqlQuery = s.createQuery(
				"from Vehiculo v " +
				"where v.patente = :patente")
			.setString("patente", patente);
		return (Vehiculo) hqlQuery.list().get(0);
	}
	
}
