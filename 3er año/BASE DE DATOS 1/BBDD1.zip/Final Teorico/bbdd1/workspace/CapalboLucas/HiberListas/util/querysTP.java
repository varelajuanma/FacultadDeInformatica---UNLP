/* Alumno: Lucas Capalbo Lavezzo (9196/2 - lucas.capalbo@gmail.com */
package util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import model.Estacionamiento;
import model.EstacionamientoPuntual;
import model.Infraccion;
import model.SEM;
import model.SEMRepositoryHQL;
import model.SEMRepositoryIterator;
import model.Vehiculo;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.concurrent.*;

public class querysTP {

	private static SessionFactory sessions;

	public static void main(String[] args) {
		Estacionamiento est;
		Configuration cfg;
		try {
			System.out.println("Alumno: Lucas Capalbo Lavezzo (9196/2 - lucas.capalbo@gmail.com");
			System.out.println("NOTA: Solo se hacen las consultas aquí, para cargar las BdD utilice el DBLoader");

			String archs[] = { "hibernateConcreta.cfg.xml", "hibernateJerarquia.cfg.xml" };
			for (String arch : archs) {
				System.out.println("\n-----------------------------------------------------------------");
				System.out.println("--- Configurando desde: " + arch);
				System.out.println("-----------------------------------------------------------------");
				cfg = new Configuration();				
				cfg.configure(arch);
				sessions = cfg.buildSessionFactory();
				
				getInfraccionesITE_HQL();         // ejs 3 y 7
				getInfraccionesVehiculo();        // ej  9.1
				getVehiculosConInfracciones();    // ej  9.2
				getCantidadInfraccionesPeriodo(); // ej  9.3
				est = makeInsert();               // ej 10
				makeDelete(est);                  // ej 11
			}
		} catch (Exception e) {
			System.out
					.println("------------------------FAIL.------------------------");
			e.printStackTrace();
		}
	}
	
	
	// Diferentes formas de mostrar el resultado	
	private static void printTime(long elapsedTime) {
		TimeUnit seconds = TimeUnit.NANOSECONDS;
		System.out.println("Transcurrieron " + 
				elapsedTime + " nanosegundos == " +
				seconds.toMillis(elapsedTime) + " milisegundos == " +
				seconds.toSeconds(elapsedTime) + " segundos\n\n");
	}

	
	//ejercicios 3 (iteradores) y 7 (HQL)
	private static void getInfraccionesITE_HQL() {
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			System.out.println("3 - Implementar, usando iteradores de java, la siguiente consulta:\n" +
					           "Retornar todas las infracciones que labraron los inspectores de apellido Perez en la zona\n" +
					           "Zona9 para una fecha dada como parámetro a aquellos vehículos que posean la patente terminada en 3.");

			//ingreso de parametros
			System.out.print("Fecha (dd/mm/yyyy - ENTER 23/10/2010): ");			
			BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
			String sfecha = inFromUser.readLine();
			Date fecha = null;
			if(sfecha.equals("")) 
				fecha = df.parse("23/10/2010");
			else
				fecha = df.parse(sfecha);
			
			long start = System.nanoTime();
			List<Infraccion> ii = new SEMRepositoryIterator()
					.getInfraccionesQry(session, "Perez", "Zona9", fecha, "3");
			long elapsedTime = System.nanoTime() - start;
			for (Infraccion i : ii) {
				System.out.println("\tVehiculo " + i.getVehiculo().getPatente() +
						           "\tInfraccion: " + i.getObservacion());
			}
			System.out.println("\tTotal Resultados: " + ii.size());			
			printTime(elapsedTime);

			System.out.println("7 - Implemente la consulta del punto 3, usando HQL.");
			start = System.nanoTime();
			ii = new SEMRepositoryHQL()
					.getInfraccionesQry(session, "Perez", "Zona9", fecha, "3");
			elapsedTime = System.nanoTime() - start;
			tx.commit();

			for (Infraccion i : ii) {
				System.out.println("\tVehiculo " + i.getVehiculo().getPatente() +
				                   "\tInfraccion: " + i.getObservacion());
			}
			System.out.println("\tTotal Resultados: " + ii.size());			
			printTime(elapsedTime);

		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)	tx.rollback();
			session.close();
		}
		session.disconnect();
	}



	//ejercicio 9 - 1
	private static void getInfraccionesVehiculo() {
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			System.out.println("9.1 - Obtener las infracciones realizadas por un vehiculo (se ingresa como dato del vehículo\n" +
						       "su patente) ordenadas por fecha de forma ascendente");

			//ingreso de parametros
			System.out.print("Patente (XXX## - ENTER AAA22): ");			
			BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
			String patente = inFromUser.readLine();
			if(patente.equals(""))
				patente = "AAA22";

			long start = System.nanoTime();
			List<Infraccion> ii = new SEMRepositoryHQL().getInfraccionesVehiculo(session, patente);
			long elapsedTime = System.nanoTime() - start;
			tx.commit();
			
			for (Infraccion i : ii) {
				System.out.println("\tInfraccion: " + i.getObservacion() +
						           "\tFecha: " + i.getFecha());
			}
			System.out.println("\tTotal Resultados: " + ii.size());			
			printTime(elapsedTime);
			
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null) tx.rollback();
			session.close();
		}
		session.disconnect();
	}

	
	//ejercicio 9 - 2
	private static void getVehiculosConInfracciones() {
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			System.out.println("9.2 - Obtener todos vehículos que alguna vez han cometido alguna infracción.\n" +
					           "Tener en cuenta que cada vehículo debe aparecer una sola vez en el listado.");
			long start = System.nanoTime();
			Collection<Vehiculo> vv = new SEMRepositoryHQL().getVehiculosConInfraccion(session);
			long elapsedTime = System.nanoTime() - start;
			tx.commit();

			for (Vehiculo v : vv) {
				System.out.println("\tVehiculo: " + v.getPatente());
			}
			System.out.println("\tTotal Resultados: " + vv.size());			
			printTime(elapsedTime);

		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null) tx.rollback();
			session.close();
		}
		session.disconnect();
	}

	
	//ejercicio 9 - 3
	private static void getCantidadInfraccionesPeriodo() {
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			System.out.println("9.3 - Para cada vehiculo, obtener la cantidad total de infracciones realizadas en un periodo dado.\n" +
					           "Ordenar el listado por patente");
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			
			//ingreso de parametros
			System.out.print("Fecha Desde (dd/mm/yyyy - ENTER 01/10/2010): ");			
			BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
			Date d_fecha = null, h_fecha = null;
			String sfecha = inFromUser.readLine();			
			if(sfecha.equals("")) 
				d_fecha = df.parse("01/10/2010");
			else
				d_fecha = df.parse(sfecha);
			System.out.print("Fecha Hasta (dd/mm/yyyy - ENTER 05/10/2010): ");
			sfecha = inFromUser.readLine();			
			if(sfecha.equals("")) 
				h_fecha = df.parse("05/10/2010");
			else
				h_fecha = df.parse(sfecha);
						
			long start = System.nanoTime();
			List ff = new SEMRepositoryHQL().getCantidadInfraccionesVehiculos(session,d_fecha, h_fecha);
			long elapsedTime = System.nanoTime() - start;
			tx.commit();
			
			for (Object f : ff) {
				Object[] fields = (Object[]) f;
				System.out.println("\tVehiculo: " + fields[0] + 
						           "\tInfracciones: " + fields[1]);
			}
			System.out.println("\tTotal Resultados: " + ff.size());			
			printTime(elapsedTime);
			
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null) tx.rollback();
			session.close();
		}
		session.disconnect();
	}

	
	//ejercicio 10
	private static Estacionamiento makeInsert() {
		Estacionamiento est = null;
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			System.out.println("10 - Con la implementación provista, agregar una instancia de la clase EstacionamientoPuntual\n" +
					           "(asociada a un vehículo existente) al objeto SEM y tomar el tiempo insumido en la inserción.");
			Vehiculo v = new SEMRepositoryHQL().getVehiculo(session, "AAA4");
			SEM sem = (SEM) session.load(SEM.class, new Long(1));			
			est = new EstacionamientoPuntual(new Date(), 3, 4, v);
			
			long start = System.nanoTime();
			sem.agregarEstacionamiento(est);
			tx.commit();
			long elapsedTime = System.nanoTime() - start;

			System.out.println("\tEstacionamiento agregado");
			printTime(elapsedTime);

		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null) tx.rollback();
			session.close();
		}
		session.disconnect();
		return est;
	}

	
	//ejercicio 11
	private static void makeDelete(Estacionamiento est) {
		Estacionamiento estABorrar = null;
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			System.out.println("11 - Eliminar el estacionamiento insertado en el punto 10 y tomar el tiempo insumido por\n" +
					           "la operación.");
			/* Tuve que hacer esto porque session.delete(est) no anda porque manejan clases distintas:
			   model.EstacionamientoPuntual$$EnhancerByCGLIB$$e71f66c1 vs. model.EstacionamientoPuntual	*/

			// buscamos el estacionamiento y el SEM en la bdd nuevamente 
			EstacionamientoPuntual ee = (EstacionamientoPuntual) session.load(EstacionamientoPuntual.class, est.getOid());
			SEM sem = (SEM) session.load(SEM.class, new Long(1));
			Vehiculo v = new SEMRepositoryHQL().getVehiculo(session, est.getVehiculo().getPatente() );
			long start = System.nanoTime();
			/* elimino las referencias al estacionamiento desde el sem y el vehiculo */
			sem.getEstacionamientos().remove(ee);
			v.getEstacionamientos().remove(ee);
			/* Si las colecciones de estacioanmiento del sem o del vehiculo se cargan y se intenta eliminar
			 *  el estacionamiento con session.delete(), da error avisando que el objeto borrado será reinsertado
			 *  luego por las operaciones en cascada si no se lo remueve de las colecciones
			 * En este caso, si no se hubiese recuperado al sem y al vehiculo se podria hacer el session.delete()
			 *  directamente (no se reinsetaría porque nadie más lo trae a memoria)*/
			
			/* Elimino el estacionamiento en si */
			session.delete(ee);
			/* La otra forma, para que ande el session.delete(est) (con est en lugar de ee) es redefinir el
			 * HashCode() y el equals() de Vehiculo y de Estacionamiento para que utilicen atributos del negocio,
			 * sino falla porque usa la identidad y hibernate cambia los objetos por otros de unas clases derivadas
			 * de las nuestras */
			tx.commit();
			long elapsedTime = System.nanoTime() - start;

			System.out.println("\tEstacionamiento borrado");			
			printTime(elapsedTime);
			
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null) tx.rollback();
			session.close();
		}
		session.disconnect();
	}
	
}
