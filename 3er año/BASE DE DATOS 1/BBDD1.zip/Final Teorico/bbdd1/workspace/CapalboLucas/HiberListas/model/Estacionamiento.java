package model;

import java.util.Date;

public abstract class Estacionamiento {
	
	private Long oid;
	private Date fecha;
	private Integer horaInicio;
	private Integer horaFin;
	private Vehiculo vehiculo;

	public Estacionamiento(){}
	
	/**
	 * Hacer archivo de mapping para las tres versiones de jerarquias.
	 * @param fecha
	 * @param horaInicio
	 * @param horaFin
	 * @param vehiculo
	 */
	

	public Estacionamiento(Date fecha, Integer horaInicio, Integer horaFin, Vehiculo vehiculo) {
		super();
		this.setFecha(fecha);
		this.setHoraFin(horaFin);
		this.setHoraInicio(horaInicio);
		this.setVehiculo(vehiculo);
		this.getVehiculo().agregarEstacionamiento(this);
		
	}



	public Vehiculo getVehiculo() {
		return vehiculo;
	}



	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}



	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Integer getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Integer horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Integer getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(Integer horaFin) {
		this.horaFin = horaFin;
	}



	public Long getOid() {
		return oid;
	}



	public void setOid(Long oid) {
		this.oid = oid;	
	}
	
	
	
///* prueba para ver si con esto funciona el session.delete(unEstaciomiento) sin tener
// * que buscarlo en la bdd primero por el proxy*/
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((fecha == null) ? 0 : fecha.hashCode());
//		result = prime * result
//				+ ((horaInicio == null) ? 0 : horaInicio.hashCode());
//		result = prime * result
//				+ ((vehiculo == null) ? 0 : vehiculo.hashCode());
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Estacionamiento other = (Estacionamiento) obj;
//		if (fecha == null) {
//			if (other.fecha != null)
//				return false;
//		} else if (!fecha.equals(other.fecha))
//			return false;
//		if (horaInicio == null) {
//			if (other.horaInicio != null)
//				return false;
//		} else if (!horaInicio.equals(other.horaInicio))
//			return false;
//		if (vehiculo == null) {
//			if (other.vehiculo != null)
//				return false;
//		} else if (!vehiculo.equals(other.vehiculo))
//			return false;
//		return true;
//	}
	
	

}
