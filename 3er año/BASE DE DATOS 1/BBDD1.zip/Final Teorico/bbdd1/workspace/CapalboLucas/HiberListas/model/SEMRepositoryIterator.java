package model;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.hibernate.Session;

public class SEMRepositoryIterator extends SEMRepository {
	
	public List getInfraccionesQry(Session s, String apellido, String zona, Date fecha, String empiezanCon) {
		SEM sem = (SEM) s.load(SEM.class, new Long(1)); //Obtiene el sistema con id 1. En este caso el unico
		List<Infraccion> ii = new LinkedList<Infraccion>();
		for(Zona z: sem.getZonas())
			if(z.getDescripcion().equals(zona))
				for(Inspector ins: z.getInspectores())
					if(ins.getApellido().equals(apellido))
						for(Infraccion i: ins.getInfracciones() ) 							
							if(i.getFecha().equals(fecha) && i.getVehiculo().getPatente().endsWith(empiezanCon) )
								ii.add(i);
		
		return ii;
	}
}
