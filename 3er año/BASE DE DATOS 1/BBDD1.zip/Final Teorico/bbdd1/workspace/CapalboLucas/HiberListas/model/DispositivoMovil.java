package model;

public class DispositivoMovil {
	
	private Long oid;
	private String numero;
	
	
	public DispositivoMovil(){		
	}
	
	public DispositivoMovil(String numero){
		this.setNumero(numero);
	}
	
	public Long getOid() {
		return oid;
	}
	public void setOid(Long oid) {
		this.oid = oid;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	

}
