package model;

import java.util.Collection;
import java.util.ArrayList;

public class Zona {

    private Long oid;
    private String descripcion;

    Collection<PuntoDeVenta> puntosDeVenta;
    Collection<Inspector> inspectores;

    public Zona(){
        this.setPuntosDeVenta(new ArrayList<PuntoDeVenta>());
        this.setInspectores(new ArrayList<Inspector>());
    }

    public Zona(String descripcion){
        this.setDescripcion(descripcion);
        this.setPuntosDeVenta(new ArrayList<PuntoDeVenta>());
        this.setInspectores(new ArrayList<Inspector>());

    }

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Collection<PuntoDeVenta> getPuntosDeVenta() {
        return puntosDeVenta;
    }

    public void setPuntosDeVenta(Collection<PuntoDeVenta> puntosDeVenta) {
        this.puntosDeVenta = puntosDeVenta;
    }

    public Collection<Inspector> getInspectores() {
        return inspectores;
    }

    public void setInspectores(Collection<Inspector> inspectores) {
        this.inspectores = inspectores;
    }

    public void agregarInspector(Inspector inspector) {
       this.getInspectores().add(inspector);
    }



}
