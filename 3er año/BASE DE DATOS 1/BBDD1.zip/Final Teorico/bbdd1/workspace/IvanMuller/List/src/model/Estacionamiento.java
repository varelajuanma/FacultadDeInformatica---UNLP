package model;

import java.util.Date;

public abstract class Estacionamiento {
	
	private Long oid;
	private Date fecha;
	private Integer horaInicio;
	private Integer horaFin;
	private Vehiculo vehiculo;

	public Estacionamiento(){}
	
	/**
	 * Hacer archivo de mapping para las tres versiones de jerarquias.
	 * @param fecha
	 * @param horaInicio
	 * @param horaFin
	 * @param vehiculo
	 */
	

	public Estacionamiento(Date fecha, Integer horaInicio, Integer horaFin, Vehiculo vehiculo) {
		super();
		this.setFecha(fecha);
		this.setHoraFin(horaFin);
		this.setHoraInicio(horaInicio);
		this.setVehiculo(vehiculo);
		this.getVehiculo().agregarEstacionamiento(this);
		
	}



	public Vehiculo getVehiculo() {
		return vehiculo;
	}



	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}



	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Integer getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Integer horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Integer getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(Integer horaFin) {
		this.horaFin = horaFin;
	}



	public Long getOid() {
		return oid;
	}



	public void setOid(Long oid) {
		this.oid = oid;	
	}
	
}
