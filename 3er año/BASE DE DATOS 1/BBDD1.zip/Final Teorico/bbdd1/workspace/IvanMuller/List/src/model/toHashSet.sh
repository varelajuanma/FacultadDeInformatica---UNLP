#!/bin/bash

for a in *.java; do
	cat "$a" | sed s:ArrayList:HashSet:g >"$a.new";
done;

rm *.java
rename 's/\.new$//' *.java.new
