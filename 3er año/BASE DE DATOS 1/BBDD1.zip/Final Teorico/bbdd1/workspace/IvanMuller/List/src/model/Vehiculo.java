package model;

import java.util.Collection;
import java.util.ArrayList;

public class Vehiculo {

    private Long oid;
    private String patente;
    private Collection<Estacionamiento> estacionamientos;
    //private List<Estacionamiento> estacionamientos;
    private Collection<Infraccion> infracciones;

    public Vehiculo(){
        this.setEstacionamientos(new ArrayList<Estacionamiento>());
        this.setInfracciones(new ArrayList<Infraccion>());
        /**
         * Armar con diferentes tipos de colecciones:
         * Usar un ArrayList mape con List e indice
         * usar un ArrayList y mapear con bag
         *
         * Numero de objetos: 20000.
         *
         */
    }

    public Vehiculo(String patente){
        this.setPatente(patente);
        this.setEstacionamientos(new ArrayList<Estacionamiento>());
        this.setInfracciones(new ArrayList<Infraccion>());

    }



    public Collection<Infraccion> getInfracciones() {
        return infracciones;
    }

    public void setInfracciones(Collection<Infraccion> infracciones) {
        this.infracciones = infracciones;
    }

    private void setPatente(String patente2) {
        this.patente=patente2;

    }

    public String getPatente(){
        return this.patente;
    }

    public Long getOid() {
        return oid;
    }

    public void setOid(Long oid) {
        this.oid = oid;
    }

    public Collection<Estacionamiento> getEstacionamientos() {
        return estacionamientos;
    }

    public void setEstacionamientos(Collection<Estacionamiento> estacionamientos) {
        this.estacionamientos = estacionamientos;
    }

    public void agregarEstacionamiento(Estacionamiento estacionamiento) {
        this.getEstacionamientos().add(estacionamiento);

    }

    public void agregarInfraccion(Infraccion infraccion){
        this.getInfracciones().add(infraccion);
    }

}
