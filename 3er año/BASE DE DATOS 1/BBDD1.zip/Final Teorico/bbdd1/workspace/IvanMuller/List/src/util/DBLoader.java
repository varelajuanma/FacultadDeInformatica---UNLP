package util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import model.DispositivoMovil;
import model.Estacionamiento;
import model.EstacionamientoPuntual;
import model.EstacionamientoSMS;
import model.Infraccion;
import model.Inspector;
import model.SEM;
import model.Vehiculo;
import model.Zona;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class DBLoader {

	private static SessionFactory sessions;

	public DBLoader() {
	}

	public static void main(String[] args) {

		try {			
			ConfigAll("hibernateConcreta.cfg.xml");
			ConfigAll("hibernateJerarquia.cfg.xml");

		} catch (Exception e) {
			System.out
					.println("------------------------FAIL.------------------------");
			e.printStackTrace();
		}

	}

	private static void ConfigAll(String archivoConf) throws ParseException {
		System.out
				.println("----- Setting up Hibernate from " + archivoConf + " -----");
		Configuration cfg = new Configuration();
		cfg.configure(archivoConf);
		System.out.println("Droping schema.........");
		new SchemaExport(cfg).drop(true, true);
		System.out.println("DONE.");
		System.out.println("Generating schema.........");
		new SchemaExport(cfg).create(true, true);
		System.out.println("DONE.");
		System.out.println("Building sessions.........");
		sessions = cfg.buildSessionFactory();
		createObjects();
	}

	public static void createObjects() throws HibernateException,
			ParseException {

		Session session = sessions.openSession();
		Date today = null;
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		try {
			today = df.parse("14/10/2010");
			System.out.println("Today = " + df.format(today));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		SEM sem = new SEM();
		List<Vehiculo> vehiculos;

		vehiculos = agregarEstacionamientosSMS(sem);
		agregarZonas(sem);
		agregarInfracciones(sem, vehiculos);

		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(sem);

			session.flush();
			System.out.println("Session flush");
			session.connection().commit();

			tx.commit();

			System.out.println("Despues del commit ********");

		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)
				tx.rollback();
			session.close();
		}finally{
			
		}

		session.disconnect();

	}

	private static void agregarInfracciones(SEM sem, List<Vehiculo> vehiculos) {
		Date today = null;
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		int vehiculo = 0;
		int cantidadVehiculos = vehiculos.size();
		for (Zona zona : sem.getZonas()) {
			for (Inspector inspector : zona.getInspectores()) {
				
				for (int i = 0; i < 5; i++) {
					for (int j = 1; j < 30; j++) {
						
						try {
							today = df.parse(j+"/10/2010");
							
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							System.out
									.println("ERROR EN GENERAR FECHAS PARA INFRACCIONES");
						}	
					Infraccion infraccion = new Infraccion(today, 10,
							"Mal estacionado", inspector, zona,
							vehiculos.get(vehiculo));
					vehiculo= (vehiculo+1)% cantidadVehiculos;
					}
					
				}
				
				
			

			}
		}

	}

	private static List<Vehiculo> agregarEstacionamientosSMS(SEM sem) {
		List<Vehiculo> vehiculos = new Vector<Vehiculo>();
		Date today = null;
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

		for (int i = 0; i < 25; i++) {
			String celular = "221-"+i;
			Vehiculo vehiculo = new Vehiculo("AAA" + i);
			vehiculos.add(vehiculo);

			for (int j = 0; j < 15; j++) {

				try {
					today = df.parse(j + "/10/2010");
				} catch (ParseException e) {
					e.printStackTrace();
					System.out
							.println("ERROR EN LA GENERACION DE ESTACIONAMIENTOS");
				}
				for (int j2 = 1; j2 < 10; j2++) {
					Estacionamiento estacionamientoSMS = new EstacionamientoSMS(
							today, j2, j2 + 1, vehiculo, celular);
					sem.agregarEstacionamiento(estacionamientoSMS);
				}

			}

			for (int j = 0; j < 15; j++) {

				try {
					today = df.parse(j + "/11/2010");
				} catch (ParseException e) {
					e.printStackTrace();
					System.out
							.println("ERROR EN LA GENERACION DE ESTACIONAMIENTOS");
				}
				for (int j2 = 1; j2 < 10; j2++) {
					Estacionamiento estacionamientoPuntual = new EstacionamientoPuntual(
							today, j2, j2 + 1, vehiculo);
					sem.agregarEstacionamiento(estacionamientoPuntual);
				}

			}

		}

	

		return vehiculos;

	}


	private static void agregarZonas(SEM sem) {
		for (int i = 0; i < 50; i++) {
			Zona zona = new Zona("Zona" + i);
			sem.agregarZona(zona);
			agregarInspectores(zona, sem);

		}

	}

	private static void agregarInspectores(Zona zona, SEM sem) {
		for (int i = 0; i < 5; i++) {

			DispositivoMovil dispositivoMovil = new DispositivoMovil("numero"
					+ i);
			Inspector inspector = new Inspector("Nombre"
					+ zona.getDescripcion(), "Perez", "legajo",
					dispositivoMovil);
			zona.agregarInspector(inspector);
			sem.agregarDispositivoMovil(dispositivoMovil);
		}
	}

}
