package util;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import model.Estacionamiento;
import model.EstacionamientoPuntual;
import model.Infraccion;
import model.SEM;
import model.SEMRepositoryHQL;
import model.SEMRepositoryIterator;
import model.Vehiculo;
import model.Zona;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.concurrent.*;

public class querysVarias {

	private static SessionFactory sessions;

	public static void main(String[] args) {		
		Estacionamiento est;
		try {
			System.out
					.println("----------------------- Setting up Hibernate -----------------------");
			
			//cargarTodo("hibernateConcreta.cfg.xml");
			//cargarTodo("hibernateJerarquia.cfg.xml");
			String archs[] = {"hibernateConcreta.cfg.xml", "hibernateJerarquia.cfg.xml"};			
			for (String arch : archs) {
				System.out.println(arch);
				Configuration cfg = new Configuration();
				cfg.configure(arch);
				
				sessions = cfg.buildSessionFactory();
				
				getInfraccionesITE_HQL(); //ej 3 y 7
				getInfraccionesVehiculo(); //ej 9.1
				getVehiculosConInfracciones(); //ej 9.2
				getCantidadInfraccionesPeriodo(); //ej 9.3
				est = makeAgregar();	//ej. 10			
				makeBorrar(est);    //ej. 11
			}

		} catch (Exception e) {
			System.out
					.println("------------------------FAIL.------------------------");
			e.printStackTrace();
		}
	}


	private static void getInfraccionesITE_HQL() {
        Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction(); //Inicia la transaccion
			
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			System.out.println("3 - Implementar, usando iteradores de java, la siguiente consulta: Retornar todas las infracciones que labraron los inspectores de apellido 'Perez' en la zona 'Zona9' para una fecha dada	como parámetro a aquellos vehículos que posean la patente terminada en 3.");			
			long start = System.nanoTime(); //Inicio del timer para medir la duraccion de la consulta
			List<Infraccion> ii = new SEMRepositoryIterator().getInfraccionesQry(session, "Perez", "Zona9", df.parse("23/10/2010"), "3" );
			long elapsedTime = System.nanoTime() - start;   //Calculo de la duraccion en nanosegundos
			for(Infraccion i : ii) {
				System.out.println("Infraccion: " + i.getObservacion());
			}		
			System.out.println("total: " + ii.size());
			
			//Diferentes formas de mostrar el resultado
			System.out.println("Tiempo transcurrido: " + elapsedTime + " nanosegundos");
			TimeUnit seconds = TimeUnit.NANOSECONDS;
			System.out.println("Que tambien es equivalente a  " + seconds.toMillis(elapsedTime) + " milisegundos");
			System.out.println("Que tambien es equivalente a  " + seconds.toSeconds(elapsedTime) + " segundos");
			
			
			
			System.out.println("7. Implemente la consulta del punto 3, usando HQL.");			
			start = System.nanoTime(); //Inicio del timer para medir la duraccion de la consulta
			ii = new SEMRepositoryHQL().getInfraccionesQry(session, "Perez", "Zona9", df.parse("23/10/2010"), "3" );
			elapsedTime = System.nanoTime() - start;   //Calculo de la duraccion en nanosegundos
			tx.commit();
			
			for(Infraccion i : ii) {
				System.out.println("Infraccion: " + i.getObservacion());
			}		
			System.out.println("total: " + ii.size());
			
			//Diferentes formas de mostrar el resultado
			System.out.println("Tiempo transcurrido: " + elapsedTime + " nanosegundos");
			seconds = TimeUnit.NANOSECONDS;
			System.out.println("Que tambien es equivalente a  " + seconds.toMillis(elapsedTime) + " milisegundos");
			System.out.println("Que tambien es equivalente a  " + seconds.toSeconds(elapsedTime) + " segundos");
			
			
			/* zona 9
			 * bd grande
			 *  iterator - set
			 *   total: 3
			 *	 Tiempo transcurrido: 579836427 nanosegundos
			 *	 Que tambien es equivalente a  579 milisegundos
			 *	 Que tambien es equivalente a  0 segundos
			 * 	hql - set
			 *   total: 3
			 *	 Tiempo transcurrido: 246042232 nanosegundos
			 *	 Que tambien es equivalente a  246 milisegundos
			 *	 Que tambien es equivalente a  0 segundos
			 * hql - list
			 *   total: 3
				 Tiempo transcurrido: 239440729 nanosegundos
				 Que tambien es equivalente a  239 milisegundos
				 Que tambien es equivalente a  0 segundos
			 *
			 *
			 * bd chica
			 *  iterator
			 *   total: 0
				 Tiempo transcurrido: 79351454 nanosegundos
				 Que tambien es equivalente a  79 milisegundos
				 Que tambien es equivalente a  0 segundos
				hql
				 total: 0
				 Tiempo transcurrido: 210275293 nanosegundos
				 Que tambien es equivalente a  210 milisegundos
				 Que tambien es equivalente a  0 segundos
			 */
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)
				tx.rollback();
			session.close();
		}
		session.disconnect();		
	}
	
	
	
	
	private static void getInfraccionesVehiculo() {
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction(); // Inicia la transaccion

			System.out.println("9.1 - Obtener las infracciones realizadas por un vehiculo (se ingresa como dato del vehículo su patente) ordenadas por fecha de forma ascendente");
			long start = System.nanoTime(); //Inicio del timer para medir la duraccion de la consulta
			Collection ii = new SEMRepositoryHQL().getInfraccionesVehiculo(session, "AAA22");
			long elapsedTime = System.nanoTime() - start;   //Calculo de la duraccion en nanosegundos
			tx.commit();
			for (Object i : ii) {
				System.out.println("Infraccion: "	+ ((Infraccion) i).getObservacion());
			}
			System.out.println("total: " + ii.size());
			
			//Diferentes formas de mostrar el resultado
			System.out.println("Tiempo transcurrido: " + elapsedTime + " nanosegundos");
			TimeUnit seconds = TimeUnit.NANOSECONDS;
			System.out.println("Que tambien es equivalente a  " + seconds.toMillis(elapsedTime) + " milisegundos");
			System.out.println("Que tambien es equivalente a  " + seconds.toSeconds(elapsedTime) + " segundos");
			
			/*
			 * DB CHICA AAA1 - SETS - total: 7
		     *  Tiempo transcurrido: 233477676 nanosegundos
		     *  Que tambien es equivalente a 233 milisegundos
		     *  Que tambien es equivalente a 0 segundos
			 * DB GRANDE AAA22 - SETS - total: 1450
			 *  Tiempo transcurrido: 955617251 nanosegundos
			 *  Que tambien es equivalente a 955 milisegundos
			 *  Que tambien es equivalente a 0 segundos
			 * DB GRANDE - LISTS - total: 1450   MÁS RAPIDO CON LISTS ************
				Tiempo transcurrido: 933393866 nanosegundos
				Que tambien es equivalente a  933 milisegundos
				Que tambien es equivalente a  0 segundos
			 */
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)
				tx.rollback();
			session.close();
		}
		session.disconnect();
	}
	
	
	
	
	private static void getVehiculosConInfracciones() {
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction(); // Inicia la transaccion

			System.out.println("9.2 - Obtener todos vehículos que alguna vez han cometido alguna infracción. Tener en cuenta que cada vehículo debe aparecer una sola vez en el listado");
			long start = System.nanoTime(); //Inicio del timer para medir la duraccion de la consulta
			Collection<Vehiculo> vv = new SEMRepositoryHQL().getVehiculosConInfraccion(session);
			long elapsedTime = System.nanoTime() - start;   //Calculo de la duraccion en nanosegundos
			tx.commit();
			
			for (Vehiculo v : vv) {
				System.out.println("Vehiculo: " + v.getPatente());
			}
			System.out.println("total: " + vv.size());
			
			//Diferentes formas de mostrar el resultado
			System.out.println("Tiempo transcurrido: " + elapsedTime + " nanosegundos");
			TimeUnit seconds = TimeUnit.NANOSECONDS;
			System.out.println("Que tambien es equivalente a  " + seconds.toMillis(elapsedTime) + " milisegundos");
			System.out.println("Que tambien es equivalente a  " + seconds.toSeconds(elapsedTime) + " segundos");
			
			/*
			 * DB CHICA - SETS - total: 5
			 *  Tiempo transcurrido: 214257041 nanosegundos
			 *  Que tambien es equivalente a 214 milisegundos
			 *  Que tambien es  equivalente a 0 segundos
			 * DB GRANDE - SETS - total: 25
			 *  Tiempo transcurrido: 219694206 nanosegundos
			 *  Que tambien es equivalente a 219 milisegundos
			 *  Que tambien es equivalente a 0 segundos
			 * DB GRANDE - LIST - total: 25   MÁS RAPIDO CON LISTS ************
				Tiempo transcurrido: 204032690 nanosegundos
				Que tambien es equivalente a  204 milisegundos
				Que tambien es equivalente a  0 segundos
			 */		
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)
				tx.rollback();
			session.close();
		}
		session.disconnect();
	}
	
	
	
	
	private static void getCantidadInfraccionesPeriodo() {
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction(); // Inicia la transaccion

			System.out.println("9.3 - Para cada vehiculo, obtener la cantidad total de infracciones realizadas en un periodo dado. Ordenar el listado por patente");
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			long start = System.nanoTime(); //Inicio del timer para medir la duraccion de la consulta
			Collection ff = new SEMRepositoryHQL().getCantidadInfraccionesVehiculos(
					session,
					df.parse("01/10/2010"),
					df.parse("05/10/2010")
			);
			long elapsedTime = System.nanoTime() - start;   //Calculo de la duraccion en nanosegundos
			tx.commit();			
			for (Object f : ff) {
				Object[] fields = (Object[]) f;
				System.out.println(fields[0] + ":  " + fields[1]);
			}
			System.out.println("total: " + ff.size());
			
			
			//Diferentes formas de mostrar el resultado
			System.out.println("Tiempo transcurrido: " + elapsedTime + " nanosegundos");
			TimeUnit seconds = TimeUnit.NANOSECONDS;
			System.out.println("Que tambien es equivalente a  " + seconds.toMillis(elapsedTime) + " milisegundos");
			System.out.println("Que tambien es equivalente a  " + seconds.toSeconds(elapsedTime) + " segundos");
			
			/* DB CHICA - SETS - total: 5
			 *  Tiempo transcurrido: 206085416 nanosegundos
			 *  Que tambien es equivalente a  206 milisegundos
			 *  Que tambien es equivalente a  0 segundos
			 * 
			 * DB GRANDE - SETS - total: 25
			 *	Tiempo transcurrido: 278175537 nanosegundos
			 *	Que tambien es equivalente a  278 milisegundos
			 *	Que tambien es equivalente a  0 segundos
			 *
			 * DB GRANDE - LISTS - total: 25   MÁS RAPIDO CON LISTS ************
				Tiempo transcurrido: 203328381 nanosegundos
				Que tambien es equivalente a  203 milisegundos
				Que tambien es equivalente a  0 segundos
			 */			
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)
				tx.rollback();
			session.close();
		}
		session.disconnect();
	}
	
	
	
	private static Estacionamiento makeAgregar() {
		Estacionamiento est = null;
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction(); // Inicia la transaccion

			System.out.println("10 - Con la implementación provista, agregar una instancia de la clase EstacionamientoPuntual (asociada a un vehículo existente) al objeto SEM y tomar el tiempo insumido en la inserción.");			
			Vehiculo v = new SEMRepositoryHQL().getVehiculo(session, "AAA22");
			SEM sem = (SEM) session.load(SEM.class, new Long(1)); //Obtiene el sistema con id 1. En este caso el unico
			est = new EstacionamientoPuntual(new Date(), 3,4,v );
			long start = System.nanoTime(); //Inicio del timer para medir la duraccion de la consulta
			sem.agregarEstacionamiento( est );			
			tx.commit();
			long elapsedTime = System.nanoTime() - start;   //Calculo de la duraccion en nanosegundos
			
			//Diferentes formas de mostrar el resultado
			System.out.println("Tiempo transcurrido: " + elapsedTime + " nanosegundos");
			TimeUnit seconds = TimeUnit.NANOSECONDS;
			System.out.println("Que tambien es equivalente a  " + seconds.toMillis(elapsedTime) + " milisegundos");
			System.out.println("Que tambien es equivalente a  " + seconds.toSeconds(elapsedTime) + " segundos");
			
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)
				tx.rollback();
			session.close();
		}
		session.disconnect();
		return est;
	}
	
	
	private static void makeBorrar(Estacionamiento est) {
		Estacionamiento estABorrar = null;
		Session session = sessions.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction(); // Inicia la transaccion
			
			System.out.println("11. Eliminar el estacionamiento insertado en el punto 10 y tomar el tiempo insumido por la operación.");
			
			EstacionamientoPuntual ee = (EstacionamientoPuntual) session.load(EstacionamientoPuntual.class, est.getOid());
			SEM sem = (SEM) session.load(SEM.class, new Long(1));
			Vehiculo v = new SEMRepositoryHQL().getVehiculo(session, est.getVehiculo().getPatente() );
			long start = System.nanoTime(); //Inicio del timer para medir la duraccion de la consulta
			sem.getEstacionamientos().remove(ee);
			v.getEstacionamientos().remove(ee);
			session.delete(ee);
					
			
			
			tx.commit();
			long elapsedTime = System.nanoTime() - start;   //Calculo de la duraccion en nanosegundos			
			
			//Diferentes formas de mostrar el resultado
			System.out.println("Tiempo transcurrido: " + elapsedTime + " nanosegundos");
			TimeUnit seconds = TimeUnit.NANOSECONDS;
			System.out.println("Que tambien es equivalente a  " + seconds.toMillis(elapsedTime) + " milisegundos");
			System.out.println("Que tambien es equivalente a  " + seconds.toSeconds(elapsedTime) + " segundos");
		} catch (Exception e) {
			e.printStackTrace();
			if (tx != null)
				tx.rollback();
			session.close();
		}
		session.disconnect();
	}
}
