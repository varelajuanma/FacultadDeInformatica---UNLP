SECRET_KEY = "dev"
DEBUG = True
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASS = 'password1'
DB_NAME = 'proyecto'
