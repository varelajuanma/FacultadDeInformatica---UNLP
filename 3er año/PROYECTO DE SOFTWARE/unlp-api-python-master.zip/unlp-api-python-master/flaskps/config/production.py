SECRET_KEY = '\xa6\xbaG\x80\xc9-$s\xd5~\x031N\x8f\xd9/\x88\xd0\xba#B\x9c\xcd_'
DEBUG = False
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASS = 'password1'
DB_NAME = 'proyecto'
