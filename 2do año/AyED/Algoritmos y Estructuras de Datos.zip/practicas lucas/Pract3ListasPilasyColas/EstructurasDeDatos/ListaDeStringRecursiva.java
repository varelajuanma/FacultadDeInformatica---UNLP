package EstructurasDeDatos;

public class ListaDeStringRecursiva extends ListaPosicionalDeStrings {

	/* //inner-class NodoListaRecursiva
	protected class NodoListaRecursiva {
		private String dato = "";
		private NodoListaRecursiva nextNode;
		
		public String getDato() {
			return dato;
		}
		public NodoListaRecursiva getNext() {
			return nextNode;
		}
		public void setDato(String dato) {
			this.dato = dato;
		}
		public void setNext(NodoListaRecursiva nextNode) {
			this.nextNode = nextNode;
		}
	}
	*/
	
	private int tama�oLista = 0;
	private NodoListaRecursiva start, currentPosition; //referencias
	
	//devuelve True o False seg�n la posici�n sea v�lida
	private boolean isValid(int position) {
		return ((position>=0) && (position<tama�oLista));
	}
	//devuelve True o False seg�n la lista est� llena
	//private boolean isFull() {
	//	return si no hay m�s memoria ---- si falla al crear un nodo
	//}
	
	//constructor -- no se indica void en la signature
	public ListaDeStringRecursiva() {
	}

	//se prepara para recorrerla desde el comienzo
	public void begin() {
		currentPosition = start;
	}
	
	//avanza al pr�ximo elem de la lista
	public void next() {
		if (currentPosition != null) currentPosition = currentPosition.getNext();
	}
	
	//determina si lleg� al final de la lista
	public boolean end() {
		return (currentPosition == null);
	}

	public String get() {
		return ((currentPosition != null) ? currentPosition.getDato() : null);
	}

	public String get(int pos) {
		NodoListaRecursiva aux;
		aux = start;
		int i=0;		
		while ((i<pos) && (aux!=null)) {
			aux = aux.getNext();
		}
		return ((aux != null) ? aux.getDato() : null);
	}

	public boolean add(String elem, int pos) {
		if (pos>=0 && pos<=this.tama�oLista)  {
			//creo nuevo nodo y guardo el dato
			NodoListaRecursiva aux = new NodoListaRecursiva();
			aux.setDato(elem);
			//lo ubico....
			if (pos == 0) { //al comienzo de la lista >> reemplaza al start
				aux.setNext(start);
				start = aux;
			} else {        //al medio o final >> busco la posici�n contando desde el comienzo
				//me quedo en ante con el anterior a la posic�n buscada
				NodoListaRecursiva ante = start;
				int i=1; //as� hago uno menos
				while ((i<pos) && (ante!=null)) {
					ante = ante.getNext();
					i++;
				}			
				aux.setNext(ante.getNext());
				ante.setNext(aux);
			}
			//cuento el elemento
			this.tama�oLista++;
			return true;
		} else {
			return false;
		}
	}
	
	//elimina elem actual
	public void remove() {
		//busco el actual para sacarlo y corregir referencias
		if (currentPosition == start) {
			start = start.getNext();
			currentPosition = start;
			//corrijo el tama�o
			this.tama�oLista--;
		} else if (currentPosition != null) {
			NodoListaRecursiva ante, nodo;				
			ante = start; //preciso mantener el anterior para corregir referencias
			nodo = start.getNext();
			while ((nodo != this.currentPosition)) {
				ante = nodo;
				nodo = nodo.getNext();
			}
			//lo desreferencio
			ante.setNext(currentPosition.getNext());
			if (currentPosition.getNext()==null) {
				currentPosition = ante;
			} else {
				currentPosition = currentPosition.getNext();
			}	
			//corrijo el tama�o
			this.tama�oLista--;
		}
	}

	//elimina elem en posici�n pos
	public void remove(int pos) {
		if (!this.isEmpty() && isValid(pos)) {
			if (pos == 0) { //si quiere sacar al primero
				if (currentPosition == start) currentPosition = currentPosition.getNext();
				start = start.getNext();
			} else {		//busco el nodo anterior para cambiar su referencia
				NodoListaRecursiva ante = start;
				int i=1; //as� hago uno menos
				while (i<pos) {
					ante = ante.getNext();
					i++;
				}			
				//corrijo si mi actual es que el se elimina
				if ((ante.getNext()==currentPosition) && (currentPosition != null)) {
					if (currentPosition.getNext()==null) {
						currentPosition = ante;
					} else {
						currentPosition = currentPosition.getNext();
					}	
				}
				//lo desreferencio
				ante.setNext(ante.getNext().getNext());
			}
			//descuento el elemento
			this.tama�oLista--;			
		}
	}
	
	//retorna True si elem est� dentro de la lista; False en caso contrario
	public boolean includes(String elem) {
		if (this.isEmpty()) {
			return false;
		} else {
			NodoListaRecursiva nodo = start;
			while ((nodo != null) && (!nodo.getDato().equals(elem))) { nodo = nodo.getNext(); }
			return (nodo != null);
		}
	}
	
	public int size() {
		return tama�oLista;
	}
	
}
