package EstructurasDeDatos;
//la hice yo para probar no lo pedia elejercicio
public abstract class ListaPosicionalDeStrings {
  //se prepara para iterar elementos de la lista
  public abstract void begin();
  
  //avanza al pr�ximo elem de la lista
  public abstract void next();
  
  //determina si lleg� al final de la lista
  public abstract boolean end();
  
  //retorna el elem actual
  public abstract String get();

  //retorna el elem en la posici�n pos
  public abstract String get(int pos);
  
  //agrega elem a la posicion pos, devuelve True si pudo agregar
  public abstract boolean add(String elem, int pos);
  
  //elimina elem actual
  public abstract void remove();
  
  //elimina elem en posici�n pos
  public abstract void remove(int pos);
  
  //retorna True si est� vac�a; False en caso contrario
  public boolean isEmpty() {
	  return (this.size()==0);
  }
  
  //retorna True si elem est� dentro de la lista; False en caso contrario 
  public abstract boolean includes(String elem);

  //retorna la longitud de la lista
  public abstract int size();
}