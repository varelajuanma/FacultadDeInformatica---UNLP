package EstructurasDeDatos;

/*  EJERCICIO 5 PRACTICA 3 - Lista no posicional
    Implementacion con arreglos  */
public class ListaDeStrings {
	protected int tama�oLista = 0;
	protected String[] elementos; //buff para elementos de la lista
	protected int tamMax = 50;   //tam maximo por defecto
	protected int currentPosition=-1, end = -1;  //-1 inv�lido: comienza vac�a
	
	//devuelve True o False seg�n la posici�n sea v�lida
	protected boolean isValid(int position) {
		return ((position>=0) && (position<=end));
	}
	//devuelve True o False seg�n la lista est� llena
	protected boolean isFull() {
		return (end == tamMax);
	}
	
	//constructor -- no se indica void en la signature
	public ListaDeStrings() {
		elementos = new String[tamMax];		
	}

	//se prepara para recorrerla desde el comienzo
	public void begin() {
		currentPosition = 0;
	}
	
	//avanza al pr�ximo elem de la lista
	public void next() {
		if (currentPosition<=end) currentPosition++;
	}
	
	//determina si lleg� al final de la lista
	public boolean end() {
		return (currentPosition == end+1);
	}

	public String get() {
		return ((isValid(currentPosition)) ? elementos[currentPosition] : null);
	}

	public boolean add(String elem) {
		if (!this.isFull())  {
			int pos = 0; //en la pos.actual o al comienzo si esta vacia
			if (!this.isEmpty() && isValid(currentPosition)) pos = currentPosition;
			//corro los �ltimos elementos para hacer lugar 
			for(int i=end; i>=pos; i--) { 
				elementos[i+1] = elementos[i];
			}
			//ubico al nuevo
			elementos[pos] = elem;
			//desplazo el final
			end++;
			//corrijo el actual
			if (currentPosition>=pos) currentPosition++;
			//cuento el elemento
			this.tama�oLista++;
			return true;
		} else {
			return false;
		}
	}
	
	//elimina elem actual
	public void remove() {
		remove (this.currentPosition);
	}

	//elimina la primer ocurrencia de elem
	public void remove(String elem) {
		if (!this.isEmpty()) {
			this.remove(this.indexOf(elem));
		}
	}
	
	//AUXILIAR: elimina elem en posici�n pos
	private void remove(int pos) {
		if (!this.isEmpty() && isValid(pos)) {
			//corro los �ltimos pisando al que borro
			for(int i=pos; i<=(end-1); i++) {
				elementos[i] = elementos[i+1];
			}
			//corrijo el final y currentPosition
			end--;			
			if (currentPosition>=pos) { currentPosition--; }
			//descuento el elemento
			this.tama�oLista--;
			//si qued� vac�a
			if (this.tama�oLista==0) {
				currentPosition=-1;
			}
		}
	}
	
	//AUXILIAR: retorna �ndice de primer ocurrencia de elem
	private int indexOf(String elem) {
		if (this.isEmpty()) {
			return -1;
		} else {
			int pos = 0;
			while ((pos<=end) && (!elementos[pos].equals(elem))) { pos++; }
			return ((pos<=end) ? pos : -1);
		}
	}
	
	//retorna True si elem est� dentro de la lista; False en caso contrario
	public boolean includes(String elem) {
		return (this.indexOf(elem)!=-1);
	}
	
	//retorna True si est� vac�a; False en caso contrario
	public boolean isEmpty() {
		return (this.size()==0);
	}
	  
	//retorna la cantidad de elementos en la lista
	public int size() {
		return tama�oLista;
	}
}