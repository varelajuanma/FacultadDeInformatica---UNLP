package EstructurasDeDatos;

public class PilaMin extends PilaDeString {
	protected String minimo;
	protected PilaDeString minimosAnteriores;
	
	public PilaMin() {
		minimosAnteriores = new PilaDeString();
	}
	
	//retorna (sin eliminar) el elemento menor de la pila
	public String min() {
		return minimo;
	}
	
	//sobreescribe al padre. Lo invoca con super.push()
	public void push(String elem) {
		//si es el 1er dato o es menor al m�nimo
		if(this.isEmpty() || elem.compareTo(minimo)<0) {
			//apilo el m�nimo como anterior y tomo al nuevo
			if (minimo!=null) minimosAnteriores.push(minimo);
			minimo = elem;
		}
		super.push(elem); //apilo al dato
	}
	
	//sobreescribe al padre. Lo invoca con super.pop()	
	public String pop() {
		String elem = super.pop();
		if(elem==minimo) minimo = minimosAnteriores.pop();
		return elem;
	}
}
