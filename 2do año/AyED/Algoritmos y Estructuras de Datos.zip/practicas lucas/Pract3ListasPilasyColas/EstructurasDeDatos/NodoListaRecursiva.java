package EstructurasDeDatos;

//en realidad s�lo la usa ListaDeStringRecursiva...
//podr�a haber hecho una inner class
public class NodoListaRecursiva {
	private String dato = "";
	private NodoListaRecursiva nextNode;
	
	public String getDato() {
		return dato;
	}
	public NodoListaRecursiva getNext() {
		return nextNode;
	}
	public void setDato(String dato) {
		this.dato = dato;
	}
	public void setNext(NodoListaRecursiva nextNode) {
		this.nextNode = nextNode;
	}
}