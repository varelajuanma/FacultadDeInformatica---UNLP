package EstructurasDeDatos;

public class PilaDeString {
	//protected ListaDeStringArreglo myList = new ListaDeStringArreglo();
	protected ListaDeStringRecursiva myList = new ListaDeStringRecursiva();
	
	public int size() {
		return myList.size();
	}
	
	public boolean isEmpty() {
		return myList.isEmpty();
	}
	
	//para hacer una pila con la lista:
	// - push: agrega en pos 0
	// - pop: devuelve el elem en pos 0
	//como la posici�n 0 se accede directamente el orden es constante (implementaci�n Recursiva)
	//en implementaci�n de arreglos ser�a constante si agrego y leo de size()-1
	public void push(String elem) {
		myList.add(elem, 0);
	}
	public String pop() {
		String buff = myList.get(0);
		myList.remove(0);
		return buff;
	}
}
