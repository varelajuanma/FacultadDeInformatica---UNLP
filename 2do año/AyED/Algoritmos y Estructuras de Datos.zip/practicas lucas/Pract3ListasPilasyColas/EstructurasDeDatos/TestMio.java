package EstructurasDeDatos;

public class TestMio {
	public static void main(String[] args) {
		//ListaDeStringArreglo myList = new ListaDeStringArreglo();
		ListaDeStringRecursiva myList = new ListaDeStringRecursiva();
		//ejercicio 5 b - Pract 3 
		//ListaDeStringArreglo2 myList = new ListaDeStringArreglo2();
		
		System.out.println("Vac�a: " + myList.isEmpty() );
		myList.add("Lucas", 0);
		System.out.println("y ahora que agreg� a 'Lucas'.. Vac�a: " + myList.isEmpty() );
		myList.remove(0);
		System.out.println("y ahora que sac� a 'Lucas'.. Vac�a: " + myList.isEmpty() );
		myList.add("Lucas", 0);
		myList.add("Pablo", 1);
		myList.add("Javier", 1);
		myList.add("Mart�n", 2);
		myList.add("Pyto", 1);
		String yo = new String("Lucas"); //para combrobar que distintos objetos Strings
										 //con igual valor se comparan bien con equals
										 //de hacer .includes("Lucas") andar�a porq a las cadenas ctes las toma como un mismo objeto si son iguales
		System.out.println("'Pepe'?: " + myList.includes("Pepe") );
		System.out.println("'Lucas'?: " + myList.includes(yo) );
		System.out.println("Elementos: " + myList.size() );
		myList.begin();
		while (!myList.end()) {
			System.out.println(myList.get());
			myList.next();
		} 
		
		myList.remove(1);
		myList.remove(1);
		System.out.println("Elimin� dos. Elementos: " + myList.size() );
		myList.begin();		
		while (!myList.end()) {
			System.out.println(myList.get());
			myList.next();
		}		
	}
}
