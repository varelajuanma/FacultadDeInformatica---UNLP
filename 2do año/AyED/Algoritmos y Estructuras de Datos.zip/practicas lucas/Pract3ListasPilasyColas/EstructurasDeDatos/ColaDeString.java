package EstructurasDeDatos;

public class ColaDeString {
	//private ListaDeStringArreglo myList = new ListaDeStringArreglo();
	private ListaDeStringRecursiva myList = new ListaDeStringRecursiva();
	
	public int size() {
		return myList.size();
	}  
	
	public boolean isEmpty() {
		return myList.isEmpty();
	}
	
	//para hacer una cola con la lista:
	// - push: agrega en pos 0
	// - pop: devuelve el �ltimo elem
	//RECURSIVA:
	//como la posici�n 0 se accede directamente el push es de orden constante
	//si pop devolviese el elem (size-1) el orden ser�a lineal
	//para volverlo constante, cuando se hace push con la cola vac�a
	//se comienza a recorrer la lista con begin, para mantener ese
	//elemento como posici�n actual. Cuando se hace push en pos 0,
	//la ref. al elem actual se mantiene, dando acceso cte al �lt elem
	//ARREGLO:
	public void push(String elem) {
		myList.add(elem, 0);
		if (myList.size()==1) myList.begin();
	}
	public String pop() {
		String buff = myList.get();
		myList.remove();
		return buff;
	}
}
