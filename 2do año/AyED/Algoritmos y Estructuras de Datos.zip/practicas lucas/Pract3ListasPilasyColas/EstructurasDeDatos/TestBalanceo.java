package EstructurasDeDatos;

public class TestBalanceo {
	public static boolean TestBalance(String cad) {
		PilaDeString p = new PilaDeString();
		int i = 0;
		boolean todoBien = true;
		Character c;
		while(i<cad.length() && todoBien) {
			c = cad.charAt(i);
			if (c=='[' || c=='(' || c=='{') {
				  //apilo el caracter de apertura
			      p.push(c.toString());
			} else {
				  //si hay algo apilado me fijo si es el correspondiente
				  if (!p.isEmpty()) {
					  String cAnt = p.pop();
					  todoBien = (cAnt.equals("[") && c==']') || (cAnt.equals("{") && c=='}') || (cAnt.equals("(") && c==')');
				  } else {
					  todoBien = false;
				  }
			}	  
			i++;
		}			
		return (todoBien);
	}
	
	
	public static void main(String args[]){
		System.out.println(TestBalanceo.TestBalance("{()[()]}"));
		System.out.println(TestBalanceo.TestBalance("([)]"));
		System.out.println(TestBalanceo.TestBalance("{a()[()]}"));
		System.out.println(TestBalanceo.TestBalance("{{()[()]}{[()]}}"));
	}
}
