package EstructurasDeDatos;

/*  EJERCICIO 5 PRACTICA 3 (c) - Lista no posicional
    Implementacion con arreglos  */
public class ListaOrdenadaDeStringArreglo extends ListaDeStrings {
	//sobreescribo el m�todo de la clase padre para agregarlo en el lugar adecuado
	public boolean add(String elem) {
		if (!this.isFull())  {
			int pos = 0; //en la pos.actual o al comienzo si esta vacia
			if (!this.isEmpty()) {
				//no hace pos = currentPos sino que busca el primero mayor o igual
				
				//b�squeda lineal ***** hasta el primero mayor o igual ******
				//es O(n)
				//while ((pos<=end) && (elementos[pos].compareTo(elem)<0)) { pos++; }
				//si pos<=end encontr� donde ubicarlo y agrega ah�
				//sino, elem es mayor a todos; se ubica en pos (end+1)
				
				//b�squeda binaria **** hasta el primero mayor o igual ******
				//es O(log2 N)
				int izq = 0, der = end, centro = (izq+der) / 2;
				while((izq<der) && !elementos[centro].equals(elem)) {
					if (elementos[centro].compareTo(elem)<0) { //segunda mitad
						izq = centro +1;
					} else {								 //primer mitad
						der = centro - 1;
					}
					centro = (izq+der) / 2;
				}
				if (elementos[centro].compareTo(elem)<0) centro++;
				pos = centro; 
			}
			//corro los �ltimos elementos para hacer lugar 
			for(int i=end; i>=pos; i--) { 
				elementos[i+1] = elementos[i];
			}
			//ubico al nuevo
			elementos[pos] = elem;
			//desplazo el final
			end++;
			//corrijo el actual
			if (currentPosition>=pos) currentPosition++;
			//cuento el elemento
			this.tama�oLista++;
			return true;
		} else {
			return false;
		}
	}
	
	//sobreescribo equals y toString de Object
	public boolean equals(Object otraLista) {
		boolean iguales = false;
		if(otraLista.getClass()==this.getClass()) {
			ListaOrdenadaDeStringArreglo l2 = (ListaOrdenadaDeStringArreglo) otraLista;
			if (this.size()==l2.size()) {
				//iguales = (this.toString().equals(otraLista.toString())); evita cambiar las posiciones actuales
				//�y usar l2.elementos[] y l2.tama�oLista?				
				//las recorre hasta terminar mientras sean iguales los elementos
				this.begin();
				l2.begin();				
				while(!this.end() && this.get().equals(l2.get())) {
					this.next();
					l2.next();
				}
				iguales = (this.end() && l2.end());				
			}
		}
		return iguales;
	}
	
	public String toString() {
		int p = 0;
		StringBuffer Buff = new StringBuffer();
		while(p<=end) {
			if (p>0) Buff.append(", ");
			Buff.append(elementos[p++]);
		}
		return Buff.toString();
	}
}
