package EstructurasDeDatos;

/*  EJERCICIO 5 PRACTICA 3 (b) - Lista posicional extiende lista no posicional
    Implementacion con arreglos  */
//la implementaci�n recursiva esta en al practica de arbol directamente, en vez de ser de String es de Object
public class ListaDeStringArreglo2 extends ListaDeStrings {
	//constructor -- no se indica void en la signature
	public ListaDeStringArreglo2() {
		elementos = new String[tamMax];		
	}

	public String get(int pos) {
		return ((isValid(pos)) ? elementos[pos] : null);
	}

	public boolean add(String elem, int pos) {
		if (!this.isFull() && (pos>=0 && pos<=this.tama�oLista))  {
			//corro los �ltimos elementos para hacer lugar 
			for(int i=end; i>=pos; i--) { 
				elementos[i+1] = elementos[i];
			}
			//ubico al nuevo
			elementos[pos] = elem;
			//desplazo el final
			end++;
			//corrijo el actual
			if (currentPosition>=pos) currentPosition++;
			//cuento el elemento
			this.tama�oLista++;
			return true;
		} else {
			return false;
		}
	}
	
	//elimina elem en posici�n pos
	public void remove(int pos) {
		if (!this.isEmpty() && isValid(pos)) {
			//corro los �ltimos pisando al que borro
			for(int i=pos; i<=(end-1); i++) {
				elementos[i] = elementos[i+1];
			}
			//corrijo el final y currentPosition
			end--;			
			if (currentPosition>=pos) { currentPosition--; }
			//descuento el elemento
			this.tama�oLista--;
			//si qued� vac�a
			if (this.tama�oLista==0) {
				//start=-1;
				currentPosition=-1;
			}
		}
	}
}
