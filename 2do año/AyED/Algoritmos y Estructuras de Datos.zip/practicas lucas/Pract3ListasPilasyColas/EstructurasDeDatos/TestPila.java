package EstructurasDeDatos;

public class TestPila {
	public static void main(String args[]){
		PilaDeString p1, p2;
		//ColaDeString p1, p2;
		String valor2;
		p1 = new PilaDeString();
		//p1 = new ColaDeString();
		p1.push("1");
		p1.push("2");
		p2 = p1;
		System.out.println("Tama�o de la pila: " + p1.size());
		valor2 = p2.pop();		
		System.out.println("Se sac�: " + valor2);
		System.out.println("Tama�o de la pila: " + p1.size());		
		System.out.println("El valor del tope de la pila es: " + p1.pop());
		System.out.println("Tama�o de la pila: " + p1.size());
	}
}
