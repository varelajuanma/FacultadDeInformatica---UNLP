package EstructurasDeDatos;

//prueba a ListaOrdenadaDeStringArreglo
public class TestListaOrdenada {

	public static void main(String[] args) {
		ListaOrdenadaDeStringArreglo l = new ListaOrdenadaDeStringArreglo();
		l.add("Programaci�n de Computadoras");
		l.add("Organizaci�n de Computadoras");
		l.add("Arquitectura de Computadoras");
		l.add("Matem�tica 1");
		l.add("Matem�tica 2");
		l.add("Ingenier�a de Software 1");
		l.add("Introducci�n a Bases de Datos");
		l.add("Algoritmos y Estructuras de Datos");
		l.add("Orientaci�n a Objetos 1");
		l.add("Seminario de Lenguajes - C");
		l.add("Seminario de Lenguajes - ADA");
		
		System.out.println("Materias ordenadas:");
		System.out.println(l.toString());
		
		ListaOrdenadaDeStringArreglo l2 = new ListaOrdenadaDeStringArreglo();
		//l2.add("Programaci�n de Computadoras");
		//l2.add("Organizaci�n de Computadoras");
		l2.add("Programaci�n de Computadoras");
		l2.add("Organizaci�n de Computadoras");
		l2.add("Arquitectura de Computadoras");
		l2.add("Seminario de Lenguajes - C");
		l2.add("Seminario de Lenguajes - ADA");
		l2.add("Ingenier�a de Software 1");
		l2.add("Introducci�n a Bases de Datos");
		l2.add("Algoritmos y Estructuras de Datos");
		l2.add("Orientaci�n a Objetos 1");
		l2.add("Matem�tica 1");
		l2.add("Matem�tica 2");	
		
		System.out.println(l2.toString());
		System.out.println(l2.equals(l));
		
/*		l.begin();
		while(!l.end()) {
			System.out.println(l.get());
			l.next();
		}*/
	}
}
