package EstructurasDeDatos;

public class TestPilaMin {

	public static void main(String[] args) {
		PilaMin p = new PilaMin();
		p.push("lucas");
		p.push("pedro");
		p.push("miguel");
		p.push("carla");
		p.push("roberto");
		p.push("anah�");
		System.out.println("M�nimo de los " + p.size() + ": " + p.min());
 		while(!p.isEmpty()) {
			System.out.println("M�nimo: " + p.min() + ". Saco a: " + p.pop());	
		}
	}

}
