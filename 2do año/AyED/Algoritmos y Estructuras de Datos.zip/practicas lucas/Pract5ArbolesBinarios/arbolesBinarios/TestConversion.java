package arbolesBinarios;

import arboles.Pila;

public class TestConversion {
	public static void main(String[] args) {
		if(args.length!=1) {
			System.out.println("Debe indicar la cadena postfija");
		}else{
			ArbolDeExpresion A = ArbolDeExpresion.convertirPostFija(args[0]);
			System.out.println("print del arbol de expresion para: " + args[0]);
			System.out.println(A);
			System.out.println("Recorrido Post-Orden: (lo agregue en ArbolBinario delegando a los hijos)");
			System.out.println(A.postOrden());
			StringBuffer sb = new StringBuffer();
			Pila p = new Pila();
			p.push(A);
			ArbolBinario AUX;
			while(!p.isEmpty()) {
				//desapilo
				AUX = (ArbolBinario) p.pop();
				if(AUX==null) { //marca de impresion
					//si es nulo procesa al siguiente
					AUX = (ArbolBinario) p.pop();
					sb.append(AUX.getDatoRaiz());
				} else {
					//si lo debe procesar
					if(AUX.esHoja()) {
						sb.append(AUX.getDatoRaiz());						
					} else {
						p.push(AUX);	//lo apila
						p.push(null);	//pidiendo su impresion
						//y apila a los hijos que tenga para que sean procesados antes
						if(AUX.getHijoIzquierdo()!=null) p.push(AUX.getHijoIzquierdo());
						if(AUX.getHijoDerecho()!=null) p.push(AUX.getHijoDerecho());
					}
				}				
			}
			System.out.println("O bien por post-orden iterativo: " + sb);
		}
	}
}
