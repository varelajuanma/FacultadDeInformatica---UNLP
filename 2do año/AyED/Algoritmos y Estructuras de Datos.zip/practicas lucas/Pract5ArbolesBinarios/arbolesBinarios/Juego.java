package arbolesBinarios;

import java.io.IOException;

public class Juego {
	private ArbolBinario preguntas; //base de preguntas y respuestas

	public Juego() {
		//por defecto solo tiene una respuesta para arriesgar: perro.
		preguntas = new ArbolBinario("perro");
	}
	public Juego(ArbolBinario preguntas) {
		this.preguntas = preguntas;
	}
	
	private String leoString() {
		try {
			StringBuffer rta;
			do {
				char car = (char) System.in.read();
				rta = new StringBuffer();				
				while (car != '\n') {
					rta.append(car);
					car = (char) System.in.read();
				}
			} while(rta.length()==0);
			return rta.toString();
		} catch(IOException e) {
			return "";
		}	
	}
	
	private char leoRespuesta() {
		try {
			char car;			
			System.out.println(" [S/N : Q:Salir]: ");
			do {
			    car = (char) System.in.read();
			} while (("SsNnQq").indexOf(car)<0);
			return Character.toUpperCase(car);
		} catch(IOException e) {
			return (' ');
		}
	}
	
	
	private boolean jugarPartida() {
		System.out.println("Eleg� un animal, seguro que te lo adivino!");
		
		boolean gana = false;
		ArbolBinario BdD = this.preguntas;
		char c = ' ';
		while(!BdD.esHoja() && c!='Q') {
			System.out.print(BdD.getDatoRaiz());
			c = leoRespuesta();
			if(c=='S') { 
				BdD = BdD.getHijoIzquierdo();
			} else if(c=='N') {
				BdD = BdD.getHijoDerecho();
			}
		}
		//si no cancelo, arriesga la PC
		if(c!='Q') {
			System.out.print("Pensaste en un/a " + BdD.getDatoRaiz());
			c = leoRespuesta();
		}
		//si cancelo sale
		if(c=='Q') {
			System.out.println("Ronda abortada por el usuario... arrugaste!");
			return false;
		} else {
			//sino se fija si acert� o no
			if(c=='S') { 
				System.out.println("Perdiste!");
			} else {
				gana = true;
				System.out.println("���GANASTE!!!");
				System.out.println("�Qu� animal habias elegido?");
				String respCorrecta;
				respCorrecta = leoString();				
				String respIncorrecta = (String) BdD.getDatoRaiz();
				System.out.println("�Qu� puedo preguntar para diferenciar un/a " + respCorrecta + " de un/a " + respIncorrecta + "?");
				BdD.getRaiz().setDato(leoString());
				BdD.agregarHijoDerecho(new ArbolBinario(respIncorrecta));
				BdD.agregarHijoIzquierdo(new ArbolBinario(respCorrecta));
			}			
			return gana;
		}
	}
	
	public void Jugar() {
		char c;
		int cont = 0;
		do {
			if (this.jugarPartida()) cont++;
			System.out.print("Otra Ronda? ");
			c = leoRespuesta();	
		} while (c=='S');
		System.out.println("Ganaste " + cont + " veces!!!");
		System.out.println("GRACIAS POR JUGAR!");
	}
}
