package arbolesBinarios;
import arboles.Lista;

public class TestBinarios {
	public static void main(String[] args) {
		/* Creo el �rbol:         A
		 * 					B			C
		 * 				D		E
		 * 			F									 */
		ArbolBinario binA = new ArbolBinario("A");
		ArbolBinario binB = new ArbolBinario("B");
		binA.agregarHijoIzquierdo(binB);
		binA.agregarHijoDerecho(new ArbolBinario("C"));
		
		ArbolBinario binD = new ArbolBinario("D");
		binB.agregarHijoIzquierdo(binD);
		binB.agregarHijoDerecho(new ArbolBinario("E"));
		
		binD.agregarHijoIzquierdo(new ArbolBinario("F"));
		
		System.out.println("Frontera de A:");
		Lista frontera = binA.frontera();
		frontera.begin();
		while(!frontera.end()) {
			System.out.print(((ArbolBinario) frontera.get()).getDatoRaiz());
			System.out.print(" ");
			frontera.next();
		}
		System.out.println("\n");
		System.out.println("Recorrido por niveles de A");
		System.out.println(binA + "\n");
		
		ArbolBinario binA2 = new ArbolBinario("A");
		binA2.agregarHijoIzquierdo(binB); 				 //el mismo HI que binA
		binA2.agregarHijoDerecho(new ArbolBinario("C")); //un HD igual al de A
		System.out.println("binA = binA2? " + binA.esIgual(binA2));
		binA2.agregarHijoDerecho(new ArbolBinario("C1")); //un HD igual al de A
		System.out.println("Ahora que cambie el HD de binA2? " + binA.esIgual(binA2));
		binA2.agregarHijoDerecho(new ArbolBinario("C")); //un HD igual al de A
		binA2.agregarHijoIzquierdo(binA);
		System.out.println("Ahora que volv� el HD y cambie la estructura de binA2? " + binA.esIgual(binA2));
		binA2.agregarHijoIzquierdo(binB);
		System.out.println("Ahora que los dej� igualitos? " + binA.esIgual(binA2));
		
		System.out.println();
		System.out.println("binA es zigzag? " + binA.zigZag());
		System.out.println("binB es zigzag? " + binB.zigZag());
		System.out.println("binD es zigzag? " + binD.zigZag());
		
		ArbolBinario zz1 = new ArbolBinario("zz1");
		ArbolBinario zz2 = new ArbolBinario("zz2");
		ArbolBinario zz3 = new ArbolBinario("zz3");
		ArbolBinario zz4 = new ArbolBinario("zz4");
		zz1.agregarHijoIzquierdo(zz2);
		zz2.agregarHijoDerecho(zz3);
		zz3.agregarHijoIzquierdo(zz4);
		zz4.agregarHijoDerecho(new ArbolBinario("ZigZag!!!"));
		System.out.println("zz1 es ZigZag???" + zz1.zigZag());
		System.out.println();
		System.out.println(binD);
		System.out.println("est� lleno binD? " + binD.lleno());
		binD.agregarHijoDerecho(new ArbolBinario("HD de binD"));
		System.out.println("y ahora que tiene HD? " + binD.lleno());
		System.out.println("est� lleno binB? " + binB.lleno());
		System.out.println(binB);
		binB.getHijoDerecho().agregarHijoIzquierdo(new ArbolBinario("B der izq"));
		binB.getHijoDerecho().agregarHijoDerecho(new ArbolBinario("B der der"));
		System.out.println("ahora que lo llen�, est� lleno binB? " + binB.lleno());
		
		System.out.println("como esta lleno, coloreo a binB? " + binB.colorear());
		
		System.out.println(binB);
		System.out.println();
		System.out.println("binA es completo? " + binA.completo());
		System.out.println("binB es completo? " + binB.completo());
		binB.getHijoDerecho().eliminarHijoIzquierdo();
		System.out.println("binB es completo ahora que le saque el nieto DI? " + binB.completo());
		binB.getHijoDerecho().eliminarHijoDerecho();
		System.out.println("binB es completo ahora que le saque el nieto DD? " + binB.completo());
		binB.eliminarHijoDerecho();
		System.out.println("binB es completo ahora que le saque el HD? " + binB.completo());
		System.out.println(binB);//nooo esta ultima salio mal revisar.
		
		ArbolBinario espejoA = binA.espejo();
		System.out.println(binA);
		System.out.println("y su espejo...");
		System.out.println(espejoA);
	}

}
