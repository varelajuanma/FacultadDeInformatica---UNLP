package arbolesBinarios;

import arboles.Pila;

public class ArbolDeExpresion extends ArbolBinario {

	public ArbolDeExpresion() {
	}
	public ArbolDeExpresion(Object dato) {
		super(dato);
	}
	protected ArbolDeExpresion(NodoBinario nodo) {
		super(nodo);
	}

	//recibe un string con una expresion posfija
	//y crea un arbol binario de expresion a partir de ella
	//Ej: ab+7y*+        =     (a+b) + (7*y)
	//					+
	//			+				*
	//		a		b		7		y
	//para hacerlo utiliza una pila. Apila alboles con los n�meros (que seran hojas)
	//y al encontrar un operando, desapila dos valores, los toma como hijos
	//de un arbol con el operando actual como raiz. lo apila y continua.
	public static ArbolDeExpresion convertirPostFija(String exp) {
		Pila p = new Pila();
		Character c;
		ArbolDeExpresion A;
		for(int i=0; i<exp.length(); i++) {
			c = exp.charAt(i);
			A = new ArbolDeExpresion(c);
			if("+-*/".indexOf(c)>=0) {
				A.agregarHijoIzquierdo((ArbolDeExpresion) p.pop());
				A.agregarHijoDerecho((ArbolDeExpresion) p.pop());								
			}
			p.push(A);			
		}
		return (ArbolDeExpresion) p.pop();
	}
}
