package arbolesBinarios;

import java.io.IOException;

public class TestJuego {

	public static void main(String[] args) throws IOException {
		/*	  	           Es felino?
			     SI                          NO
			gato                         Es canino?
			        Es dom�stico?                   Canguro
			 Perro                  Lobo
		 */		
		ArbolBinario BdD = new ArbolBinario("Es dom�stico?");
		BdD.agregarHijoIzquierdo(new ArbolBinario("Perro"));
		BdD.agregarHijoDerecho(new ArbolBinario("Lobo"));

		ArbolBinario aux = new ArbolBinario("Es canino?");
		aux.agregarHijoIzquierdo(BdD);
		aux.agregarHijoDerecho(new ArbolBinario("canguro"));
		
		BdD = new ArbolBinario("Es felino?");
		BdD.agregarHijoIzquierdo(new ArbolBinario("gato"));
		BdD.agregarHijoDerecho(aux);
		
		Juego miJuego = new Juego(BdD);
		miJuego.Jugar();
	}

}
