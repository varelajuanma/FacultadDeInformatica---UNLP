package arbolesBinarios;

public class DatoMinMax {
	private int dato = 0;
	private boolean esMax = false;
	
	public DatoMinMax(int dato) {
		this.dato = dato;		
	}	
	public DatoMinMax(int dato, boolean esMax) {
		this.dato = dato;
		this.esMax = esMax;
	}

	public int getDato() {
		return dato;
	}
	public void setDato(int dato) {
		this.dato = dato;
	}
	
	public boolean IsMax() {
		return esMax;
	}
	public boolean IsMin() {
		return !esMax;
	}	
	public void setMax() {
		this.esMax = true;
	}
	public void setMin() {
		this.esMax = false;
	}

	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof DatoMinMax) {
			return this.getDato()==((DatoMinMax) obj).getDato();
		} else {
			return super.equals(obj);
		}
	}

	@Override
	public String toString() {
		return ((Integer) this.getDato()).toString();
	}
}
