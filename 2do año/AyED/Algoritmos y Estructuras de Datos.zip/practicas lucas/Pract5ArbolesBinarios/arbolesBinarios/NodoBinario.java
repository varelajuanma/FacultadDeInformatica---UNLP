package arbolesBinarios;
public class NodoBinario {
	protected Object dato;
	protected NodoBinario hijoIzq, hijoDer;
	
	//CONSTRUCTOR INDICANDO EL DATO QUE CONTENDR� EL NODO////////
	public NodoBinario(Object dato){
		setDato(dato);
		hijoIzq = null;
		hijoDer = null;
	}
	
	//GETTERS Y SETTERS /////////////////////////////////////////
	public Object getDato() {
		return dato;
	}
	public void setDato(Object dato) {
		this.dato = dato;
	}
	
	public NodoBinario getHijoDerecho() {
		return hijoDer;
	}
	public void setHijoDerecho(NodoBinario unHijo) {
		this.hijoDer = unHijo;
	}
	
	public NodoBinario getHijoIzquierdo() {
		return hijoIzq;
	}
	public void setHijoIzquierdo(NodoBinario unHijo) {
		this.hijoIzq = unHijo;
	}
	
	public String toString() {
		return dato.toString();
	}
}
