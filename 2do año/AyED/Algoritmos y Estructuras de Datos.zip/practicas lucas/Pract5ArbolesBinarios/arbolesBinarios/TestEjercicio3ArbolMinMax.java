package arbolesBinarios;

public class TestEjercicio3ArbolMinMax {

	public static void main(String[] args) {
		ArbolBinario raiz = new ArbolBinario(new DatoMinMax(5,false));

		ArbolBinario HI = new ArbolBinario(new DatoMinMax(8,true));
		HI.agregarHijoIzquierdo(new ArbolBinario(new DatoMinMax(18)));
		HI.agregarHijoDerecho(new ArbolBinario(new DatoMinMax(1)));
		
		ArbolBinario HD = new ArbolBinario(new DatoMinMax(10,false));
		HD.agregarHijoIzquierdo(new ArbolBinario(new DatoMinMax(80)));
		HD.agregarHijoDerecho(new ArbolBinario(new DatoMinMax(0)));
		
		raiz.agregarHijoDerecho(HD);
		raiz.agregarHijoIzquierdo(HI);
		
		System.out.println(raiz.valor());
	}

}
