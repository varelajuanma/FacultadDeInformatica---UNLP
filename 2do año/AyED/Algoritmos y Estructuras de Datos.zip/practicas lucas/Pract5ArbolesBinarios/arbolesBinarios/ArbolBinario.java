package arbolesBinarios;
import arboles.ArbolGeneral;
import arboles.Cola;
import arboles.Lista;
import arboles.ListaPosicional;
import arboles.Pila;

public class ArbolBinario {
	protected NodoBinario raiz;
	
	//CONSTRUCTORES ////////////////////////////////////////////////////////
	public ArbolBinario(){
		raiz = null;		
	}
	public ArbolBinario(Object dato){
		raiz = new NodoBinario(dato);
	}
	/* Crea el �rbol binario a partir de uno general.
	 * Cada v�rtice del gral ser� una hoja. Si gral es una hoja, ser� la �nica.
	 * Sino, se crea una raiz con contenido null, su HI el Hijo m�s izq del gral
	 * y su HD el gral, tratado del mismo modo.  
	 */
	public ArbolBinario(ArbolGeneral gt) {
		if(gt.esHoja()) {	//construye la ra�z con su mismo dato
			raiz = new NodoBinario(gt.getDatoRaiz());
		} else {			//construye una ra�z nula
			raiz = new NodoBinario(null);			
			Lista hijos =  gt.getHijos();
			hijos.begin();
			//le quita a gt su hijo m�s izquierdo (as�, va a tender a convertirse en hoja)
			ArbolGeneral hijoMasIzquierdo = (ArbolGeneral) hijos.get();
			gt.eliminarHijo(hijoMasIzquierdo);
			//lo toma como propio
			this.agregarHijoIzquierdo(new ArbolBinario(hijoMasIzquierdo));
			//y agrega lo que queda de gt a su derecha
			//eventualmente gt se va a convertir en hoja porque le sac� todos los hijos
			//y va a ser s�lo una hoja de this
			this.agregarHijoDerecho(new ArbolBinario(gt));			
		}
	}
	protected ArbolBinario(NodoBinario nodo){
		raiz = nodo;
	}

	//M�TODOS DE LA CLASE //////////////////////////////////////////////////
	protected NodoBinario getRaiz() {
		return raiz;		
	}
	public Object getDatoRaiz() {
		return (raiz==null) ? null : raiz.getDato();
	}
	public ArbolBinario getHijoDerecho() {
		ArbolBinario HD = null;
		if(raiz!=null) 
			if(raiz.getHijoDerecho()!=null) HD = new ArbolBinario(raiz.getHijoDerecho());
		return HD;
	}
	public ArbolBinario getHijoIzquierdo() {
		ArbolBinario HI = null;
		if(raiz!=null)
			if(raiz.getHijoIzquierdo()!=null) HI = new ArbolBinario(raiz.getHijoIzquierdo());
		return HI;
	}
	public void agregarHijoDerecho(ArbolBinario unHijo) {
		if(raiz!=null) raiz.setHijoDerecho(unHijo.getRaiz());
	}	
	public void agregarHijoIzquierdo(ArbolBinario unHijo) {
		if(raiz!=null) raiz.setHijoIzquierdo(unHijo.getRaiz());
	}
	public void eliminarHijoDerecho() {
		if(raiz!=null) raiz.setHijoDerecho(null);
	}
	public void eliminarHijoIzquierdo() {
		if(raiz!=null) raiz.setHijoIzquierdo(null);
	}
	
	//devuelve true/false seg�n el nodo sea hoja o no
	public boolean esHoja() {
		return (raiz==null) ? true : (raiz.getHijoDerecho()==null && raiz.getHijoIzquierdo()==null);
	}
	//cadena multilinea con recorrido en niveles del arbol
	public String toString() {
		StringBuffer buff = new StringBuffer();		
		Cola c = new Cola();
		c.push(this);	//el mismo arbol
		c.push(null);	//marca de fin de nivel
		ArbolBinario aux, HI, HD;
		while(!c.isEmpty()) {
			aux = (ArbolBinario) c.pop();
			if(aux==null) {		//termin� un nivel
				if(!c.isEmpty()) {
					buff.append("\n");
					c.push(aux);	//paso la marca al final si queda algo
				}
			} else {				
				buff.append(aux.getDatoRaiz().toString().replace(" ", "_"));
				buff.append(" ");
				HI = aux.getHijoIzquierdo();
				HD = aux.getHijoDerecho();
				if(HI!=null) c.push(HI);
				if(HD!=null) c.push(HD);
			}
		}
		return buff.toString();
	}
	//devuelve una Lista con la frontera del arbol (sus hojas, de izq. a der.)
	//hace un recorrido en Pre-Orden, a los nodos que sean hojas los pone en la lista
	public Lista frontera() {				
		ListaPosicional miFrontera = new ListaPosicional(); //para el resultado
		if(raiz==null) return miFrontera;
		Pila buff = new Pila();			//para demorar los hijos derechos (a los izquierdos los proceso directamente)
		buff.push(this);
		ArbolBinario aux;
		while(!buff.isEmpty()) {
			aux = (ArbolBinario) buff.pop();	//toma al que estaba apilado para seguir
			if(aux.esHoja()) {
				miFrontera.add(aux,miFrontera.size()); 	//si es hoja forma parte de la frontera				
			} else {
				if(aux.getHijoDerecho()!=null) buff.push(aux.getHijoDerecho());
				if(aux.getHijoIzquierdo()!=null) buff.push(aux.getHijoIzquierdo());
			}
		}
		return miFrontera;
	}
	// Devuelve true/false seg�n tengan el mismo valor y la misma estructura
	public boolean esIgual(ArbolBinario otroArbol) {
		boolean iguales = false;
		if(otroArbol!=null) {
			iguales = true;
			Cola c1 = new Cola();
			Cola c2 = new Cola();
			c1.push(this);		//encolo al arbol principal
			c2.push(otroArbol);	//encolo al arbol principal 

			ArbolBinario arbol1, arbol2;
			while(iguales && !c1.isEmpty() && !c2.isEmpty()) {
				arbol1 = (ArbolBinario) c1.pop();
				arbol2 = (ArbolBinario) c2.pop();
				if(arbol1==null) {
					iguales = (arbol2==null);
				} else if(arbol1.getDatoRaiz().equals(arbol2.getDatoRaiz())) {
					c1.push(arbol1.getHijoIzquierdo());
					c2.push(arbol2.getHijoIzquierdo());
					c1.push(arbol1.getHijoDerecho());
					c2.push(arbol2.getHijoDerecho());
				} else {
					iguales = false;					
				}
			}
			return (iguales && (c1.isEmpty()==c2.isEmpty()));
		}		
		return iguales;
	}
	/* Devuelve true/false seg�n otroArbol sea menor (o no) que this
	 * Un �rbol A es menor a uno B si:
	 * 	a < b	(ra�ces iguales)
	 * 	a = b  ^  Ai < Bi
	 *  a = b  ^  Ai = Bi  ^  Ad < Bd 
	 *  La definicion es para arboles de enteros. Lo implemente con Comparable para
	 *  que sea mas general el concepto
	 */
	@SuppressWarnings("unchecked")
	public boolean esMenor(ArbolBinario otroArbol) {
		boolean soyMenor = false;
		if(otroArbol!=null) {
			int compara = ((Comparable) this.getDatoRaiz()).compareTo(otroArbol.getDatoRaiz());
			if (compara<0) {
				soyMenor = true;
			} else if (compara==0){
				ArbolBinario miHI = this.getHijoIzquierdo();
				ArbolBinario suHI = otroArbol.getHijoIzquierdo();
				if(miHI==null) {
					soyMenor = (suHI==null);
				} else {
					if(miHI.esMenor(suHI)) {
						soyMenor = true;
					} else if(miHI.esIgual(suHI)) {
						soyMenor = this.getHijoDerecho().esMenor(otroArbol.getHijoDerecho());
					}
				}
			}
		}
		return soyMenor;			
	}
	/* Devuelve true si el �rbol es degenerado con direcciones alternadas,
	 * esto es, si en lugar de ser una lista donde todos los hijos est�n
	 * en el lado izquierdo o derecho, se van alternando. 
	 * Arbol Degenerado				Arbol Degenerado con posiciones Alternadas
	 *    o										o
	 *     o									 o
	 *      o									o
	 *       o									 o
	 */
	public boolean zigZag() {
		boolean esZigZag = true;
		ArbolBinario aux = this;
		ArbolBinario HI, HD;
		int ban = -1; //0 derecha, 1 izquierda
		while(esZigZag && aux!=null) {
			HI = aux.getHijoIzquierdo();
			HD = aux.getHijoDerecho();
			if(HI!=null && HD!=null) {	//si tiene dos hijos no es zigzag
				esZigZag = false;
			} else if(HI!=null) {		//si tiene HI
				if(ban != 1) {			//y no venia por la izquierda
					aux = HI;
				} else {
					esZigZag = false;	//si venia por izq, se rompi� el Zig-Zig
				}
			} else if(HD!=null) {		//si tiene HD
				if(ban != 0) {			//y no venia por la derecha
					aux = HD;
				} else {
					esZigZag = false;	//si venia por der, se rompi� el Zig-Zig
				}
			} else {
				aux = null;				//si no tengo ningun hijo paso a nulo para salir
			}
		}
		return esZigZag;
	}
	/* Devuelve true si el �rbol es lleno (si tiene todas las hojas en el mismo
	 * nivel y adem�s tiene todas las hojas posibles: todos los nodos intermedios
	 * tienen dos hijos) */
	public boolean lleno() {
		boolean esLleno = true;
		boolean encontroHoja;
		Cola c = new Cola();
		c.push(null);	//marca de fin de nivel		
		ArbolBinario aux = this, HI, HD;
		//hago el recorrido por nivel
		while(!c.isEmpty() && esLleno) {			
			if(aux==null) {
				if(!c.isEmpty()) {
					c.push(aux);	//mantengo la marca de fin de nivel
					aux = (ArbolBinario) c.pop();	//toma al primero del siguiente nivel
				}
			} else {
				encontroHoja = aux.esHoja(); 	//si el primero es hoja todos seran hojas
				//saco a todos los del mismo nivel			
				while(!c.isEmpty() && esLleno && aux!=null) {
					if (aux.esHoja()) {	//si encontre una hoja, es lleno si ya tenia hojas
						esLleno = encontroHoja;
					} else if(encontroHoja) {
						esLleno = false; //si no es hoja pero habia hojas en su nivel no esta lleno
					} else {
						//sino miro sus hijos
						HI = aux.getHijoIzquierdo();
						HD = aux.getHijoDerecho();
						if(HI==null || HD==null) {	//si le falta alguno, no esta lleno
							esLleno = false;
						} else {					//si tiene los dos los encolo
							c.push(HI);
							c.push(HD);
						}
					}
					aux = (ArbolBinario) c.pop();	//toma al siguiente del mismo nivel o null
				}				
			}
		}
		return esLleno;
	}
	/* devuelve true/false segun el arbol sea completo o no
	 * un arbol de altura h es completo si es lleno al nivel h-1,
	 * y el nivel h se completa de izq a der. */
	public boolean completo() {
		boolean esCompleto = true;
		//busco la primer hoja mas a la izquierda, conservo su nivel
		int nivelHoja = 1; //primero creo q la raiz es hoja
		ArbolBinario buscaHoja = this, HI;
		while(!buscaHoja.esHoja() && esCompleto) {			
			HI = buscaHoja.getHijoIzquierdo();
			if(HI!=null) {
				nivelHoja++;	//cuento que paso a otro nivel
				buscaHoja = HI;		//me voy por el hijo izquierdo
			} else {				
				esCompleto = false; //si tiene HD y no HI no es completo
			}
		}
		if (esCompleto && nivelHoja>1) {
			//controlo que sea lleno hasta el nivel n-1
			//y que los nodos de n-1 no tengan mas hijos cuando alguno deje de tener
			boolean encontroHoja = false;
			Cola c = new Cola();
			c.push(null);	//marca de fin de nivel
			int nivel = 1, nivelHasta = nivelHoja -1;
			ArbolBinario aux = this, HD;
			//hago el recorrido por nivel
			while(!c.isEmpty() && esCompleto) {			
				if(aux==null) {
					if(!c.isEmpty()) {
						c.push(aux);	//mantengo la marca de fin de nivel
						aux = (ArbolBinario) c.pop();	//toma al primero del siguiente nivel
						nivel++;
					}
				} else {
					encontroHoja = encontroHoja || aux.esHoja(); 	//si el primero es hoja o ya habia hoja del nivel
																	//anterior, todos seran hojas
					//saco a todos los del mismo nivel			
					while(!c.isEmpty() && esCompleto && aux!=null) {
						if (aux.esHoja()) {	//si encontre una hoja, es lleno si ya tenia hojas
							encontroHoja = true;
							esCompleto = (nivel == nivelHasta) || (nivel == nivelHoja);
						} else if(encontroHoja) {
							esCompleto = false; //si no es hoja pero habia hojas en su nivel no esta lleno
						} else {
							//sino miro sus hijos
							HI = aux.getHijoIzquierdo();
							HD = aux.getHijoDerecho();
							//tengo alguno o los dos
							if(HI==null) {
								esCompleto = false; //no puede tener solo HD
							} else {
								c.push(HI);
								//si tengo HD lo paso a la cola
								//si no tengo, marco que encontre hoja aunque en realidad
								//no lo es, pero preciso que los siguientes del nivel sean
								//hojas para que sea completo
								if(HD!=null) c.push(HD); else encontroHoja = true;
							}
						}
						aux = (ArbolBinario) c.pop();	//toma al siguiente del mismo nivel o null
					}				
				}
			}
		}
		return esCompleto;
	}
	/* devuelve el arbol binario espejo de este arbol*/
	public ArbolBinario espejo() {
		ArbolBinario miEspejo = new ArbolBinario(this.getDatoRaiz());
		if(this.getHijoDerecho() != null) miEspejo.agregarHijoIzquierdo(this.getHijoDerecho().espejo());
		if(this.getHijoIzquierdo() != null) miEspejo.agregarHijoDerecho(this.getHijoIzquierdo().espejo());
		return miEspejo;
	}
	/* Colorea al arbol. Un arbol coloreado es un arbol lleno. La raiz es negra y despues
	 * se intercalan uno blanco y uno negro entre todos los niveles. */
	public boolean colorear() {
		if(this.lleno()) {
			this.getRaiz().setDato("N"); //colorea la raiz
			Cola c = new Cola();
			c.push(this.getHijoIzquierdo());
			c.push(this.getHijoDerecho());
			c.push(null);	//marca de fin de nivel
			String color = "B";
			ArbolBinario aux;
			//hago el recorrido por nivel
			while(!c.isEmpty()) {
				aux = (ArbolBinario) c.pop();
				if(aux==null) {
					if(!c.isEmpty()) c.push(aux);	//mantengo la marca de fin de nivel
				} else {
					aux.getRaiz().setDato(color);
					if(!aux.esHoja()) {
						c.push(aux.getHijoIzquierdo());
						c.push(aux.getHijoDerecho());
					}
				}
				//intercala el color
				if (color.equals("N")) color = "B"; else color = "N";				
			}
			return true;
		} else {
			return false; //no esta lleno no se puede colorear
		}
	}
	
	
	/* Para arboles Min Max -cada nodo tiene por dato un DatoMinMax */
	//devuelve el valor del arbol
	public int valor() {
		int v = ((DatoMinMax) this.getDatoRaiz()).getDato();
		v = this.getMejor(v, this.getHijoIzquierdo());
		v = this.getMejor(v, this.getHijoDerecho());
		return v;
	}
	//devuelve el mejor valor valor entre v y el valor de A segun el criterio de this
	private int getMejor(int v, ArbolBinario A) {
		if(A!=null) {
			int v2 = A.valor();
			if ( ((DatoMinMax) this.getDatoRaiz()).IsMax()) { 
				if(v2>v) v=v2;
			} else {
				if(v2<v) v=v2;
			}
		}
		return v;
	}
	//devuelve una cadena con el recorrido postorden del arbol
	public String postOrden() {
		StringBuffer buff = new StringBuffer();		
		if(this.getHijoDerecho()!=null) buff.append(this.getHijoDerecho().postOrden());
		if(this.getHijoIzquierdo()!=null) buff.append(this.getHijoIzquierdo().postOrden());
		buff.append(this.getDatoRaiz());
		return buff.toString();
	}
}
