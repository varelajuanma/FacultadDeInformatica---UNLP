import arboles.ArbolGeneral;
import arboles.Lista;


public class TestestaContenido {

	public static void main(String[] args) {
		Lista L = new Lista();
		ArbolGeneral A1 = new ArbolGeneral('A');
		ArbolGeneral S1 = new ArbolGeneral('S');
		ArbolGeneral S2 = new ArbolGeneral('S');
		ArbolGeneral A2 = new ArbolGeneral('A');
		ArbolGeneral A3 = new ArbolGeneral('A');
		ArbolGeneral C1 = new ArbolGeneral('C');
		ArbolGeneral C2 = new ArbolGeneral('C');
		ArbolGeneral O1 = new ArbolGeneral('1');
		ArbolGeneral O2 = new ArbolGeneral('2');
		ArbolGeneral O3 = new ArbolGeneral('3');
		ArbolGeneral O4 = new ArbolGeneral('4');
		ArbolGeneral O5 = new ArbolGeneral('5');
		//casa
		L.add('A');
		L.add('S');
		L.add('A');
		L.add('C');
		System.out.println("Lista = " + L);
		//cargo el arbol
		//en este caso no anda como lo hice en el examen
		//porque encuentra la primer ocurrencia de casa
		//por A1,S,A,C,6 pero sale en la C y los hijos no estan vacios
		//devuelve falso
		//deberia volver atras para ver la otra ocurrencia
		A1.agregarHijo(S2);	//         A1
		A1.agregarHijo(O1);	//2     S1     1      S2
		A1.agregarHijo(S1);	//    A2  3           A3
		A1.agregarHijo(O2);	//   4 C1             C2
		S1.agregarHijo(A2); //      5
		S1.agregarHijo(O3);
		S2.agregarHijo(A3);
		A2.agregarHijo(O4);
		A2.agregarHijo(C1);
		C1.agregarHijo(O5);
		A3.agregarHijo(C2);
		
		System.out.println("Arbol = " + A1);
		System.out.println("esta contenida L en A1? " + A1.estaContenido(L));
		
		
	}

}
