
public class baseOctal {

	public static int aBase8(int n) {
		int num = 0;
		int pos = 1;
		while(n>=8) {
			num = num + (n % 8) * pos;
			pos *= 10;
			n = n / 8;
		}
		num = num + n  * pos;
		return num;
	}
	
	public static void main(String[] args) {
		System.out.println("pasando a octal 1: " + aBase8(1) );
		System.out.println("pasando a octal 8: " + aBase8(8) );
		System.out.println("pasando a octal 15: " + aBase8(15) );
		System.out.println("pasando a octal 24: " + aBase8(24) );
		System.out.println("pasando a octal 125: " + aBase8(125) );
	}

}
