
public class Test {
	public static void main(String[] args) {
		Estudiante[] Estuds = new Estudiante[4];
		Estuds[0] = new Estudiante();
		Estuds[0].setNombre("Lucas");
		Estuds[0].setApellido(new String("Capalbo"));
		Estuds[0].setEmail("lucas.capalbo@gmail.com");
		Estuds[0].setComision("AyE");
		System.out.println(Estuds[0].tusDatos());
		
		/* creo al resto */
		for (int i = 1; i < Estuds.length; i++) {
			Estuds[i] = new Estudiante();
			Estuds[i].setNombre("Nombre " + i);
			Estuds[i].setApellido("APELLIDO " + i);
			Estuds[i].setEmail("email" + i + "@home.com");
			Estuds[i].setComision("AyE");
			System.out.println(Estuds[i].tusDatos());
		}
		
		System.out.println("Profesores:");
		Profesor[] Profs = new Profesor[3];		
		for (Profesor p: Profs) {      //for each
			p = new Profesor();
			p.setNombre("Nombre Prof.");
			p.setApellido("APELLIDO PROF.");
			System.out.println("    " + p.getApellido() + ", " + p.getNombre());
		}
		
		
	}
}
