
public class TusDatos {

	public static void main(String[] args) {
	
		String nombre = args[0];
		String apellido = args[1];
		int codigoPostal = 46859;
		String colorFavorito = "Rojo";
		System.out.println("Hola " + nombre +" " + apellido);
		System.out.println("Tu codigo postal es: " + codigoPostal);
		System.out.println("Tu color favorito es: " + colorFavorito);
	}

}
