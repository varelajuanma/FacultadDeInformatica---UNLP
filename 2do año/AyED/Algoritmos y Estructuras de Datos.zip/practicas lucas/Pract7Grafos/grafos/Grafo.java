package grafos;

import arboles.Cola;
import arboles.Lista;
import arboles.Pila;

@SuppressWarnings("unchecked")
public class Grafo {
	protected final int	MAX_CANT_VERTICES = 100;
	protected int 			cantVertices;
	protected Vertice[]	vertices;
	
	public Grafo() {	//constructor
		this.cantVertices = 0;
		this.vertices = new Vertice[MAX_CANT_VERTICES];			
	}
	
	public void agregarVertice(Comparable dato) {
		if(this.cantVertices<MAX_CANT_VERTICES) {
			Vertice nuevoVertice = new Vertice(dato);
			nuevoVertice.setPosicion(this.cantVertices);
			vertices[this.cantVertices] = nuevoVertice;
			this.cantVertices++;
		}
	}
	public void eliminarVertice(Comparable dato) {
		int posicion = this.posicion(dato);
		if(posicion>=0) { //si esta
			//toma el vertice a quitar
			Vertice eliminado = this.vertices[posicion];
			//recorre el arreglo de vertices hasta la ultima posicion usada
			for(int p=0; p<this.cantVertices; p++) {
				//a los de posicion > a posicion los mueve una posicion adelante
				//para eliminar del array al vertice
				if(p>posicion) {
					this.vertices[p-1] = this.vertices[p];
					this.vertices[p-1].setPosicion(p-1);
				}
				//a cada uno le pide q se desconecte del vertice que elimino
				this.vertices[p].desconectar(eliminado);
			}
			this.vertices[this.cantVertices] = null; //ya se copio una posicion antes
			this.cantVertices--;
		}
	}
	public boolean conectar(Comparable unDato, Comparable otroDato) {
		int posicion1 = this.posicion(unDato);
		int posicion2 = this.posicion(otroDato);
		if(posicion1>=0 && posicion2>=0) { //si estaban los dos
			this.vertices[posicion1].conectar(this.vertices[posicion2]);
			return true;
		} else {
			return false; //alguno no estaba -o ninguno-
		}
	}
	public boolean desconectar(Comparable unDato, Comparable otroDato) {
		boolean desconecto = false;
		int posicion1 = this.posicion(unDato);			//N
		if(posicion1>=0) {
			//si los eliminar y agregar devolviesen booleanos...
			//no precisaria posicion2 y evitaria otra N
			//directamente a vertices[posicion1].desconectar(new Vertice(otroDato))
			//sobreescribiendo el equals de Vertice como hice con Arista.
			int posicion2 = this.posicion(otroDato);	//N
			if(posicion2>=0) { //si estaban los dos
				this.vertices[posicion1].desconectar(this.vertices[posicion2]); //Ai
				desconecto = true;
			}
		}
		return desconecto;
	}
	public boolean esAdyacente(Comparable unDato, Comparable otroDato) {
		int posicion1 = this.posicion(unDato);
		int posicion2 = this.posicion(otroDato);
		if(posicion1>=0 && posicion2>=0) { //si estaban los dos
			//el .includes podria recibir(new Arista(vertices[posicion2])
			//pero la Arista saber compararse contra vertices
			return this.vertices[posicion1].getAdyacentes().includes(this.vertices[posicion2]);
		} else {
			return false; //alguno no estaba -o ninguno-
		}		
	}
	public boolean esVacio() {	
		return(cantVertices==0);
	}
	public Lista listaDeVertices() {
		Lista misVertices = new Lista();
		for(int i=0; i<this.cantVertices; i++) {
			misVertices.add(this.vertices[i].getDato());
		}
		return misVertices; //devuelve la lista de datos de los vertices.
							 //el cliente no conoce a los vertices
	}
	public Lista listaDeAdyacentes(Comparable unDato) {
		Lista susAdyacentes = new Lista();
		int posicion1 = this.posicion(unDato);
		if(posicion1>=0) {
			Lista aristas = this.vertices[posicion1].getAdyacentes();
			aristas.begin();
			while(!aristas.end()) {
				susAdyacentes.add( ((Arista) aristas.get()).getDestino().getDato() );
				aristas.next();
			}
		}
		return susAdyacentes; //se devuelven en el rden recerso de como se procesan, pero no importa
	}
	protected int posicion(Comparable unDato) {
		int i;	//busqueda lineal por el arreglo
		for(i=0; i<cantVertices && !vertices[i].getDato().equals(unDato); i++);
		return (i<cantVertices) ? i : -1;
	}
	
	//devuelve una lista de los valores de los nodos segun recorrido 
	//deep first search o por profundidad
	//procesa a un primer vertice y luego a sus adyacentes cuidando de no repetir
	//permite ver todos los vertices alcanzables desde un dado, llegando de modo
	//que requiera menor cantidad de pasos a cada uno.
	//este metodo general recorre a todos los vertices haciendo dfs
	/* T(V,A) = cte + V * (cte + T(dfs)) + V
	 * en total la funcion dfs se llamara una vez para cada vertice, es decir V veces
	 * sea por el for o por llamadas recursivas
	 * cada T(dfs) tiene ademas de un cte, un bucle por la cantidad ai de adyacentes de cada
	 * vertice. Para los V vertices, esto es A. As�
	 *  T(V,A) = cte + A + V = O(V + A)  LINEAL			*/
	public Lista dfs() {										//driver DFS general
		Pila Recorrido = new Pila();
		boolean visitados[] = new boolean[this.cantVertices];
		for(int i = 0; i<this.cantVertices; i++) {
			if(!visitados[i]) this.dfs(this.vertices[i], Recorrido, visitados);
		}
		return Recorrido.popAll();
	}
	public Lista dfs(Comparable unDatoOrigen) {					//DFS desde determinado dato
		Pila Recorrido = new Pila();		
		int posicionDato = this.posicion(unDatoOrigen);
		if(posicionDato>=0) {
			boolean visitados[] = new boolean[this.cantVertices];
			this.dfs(this.vertices[posicionDato], Recorrido, visitados); 
		}
		return Recorrido.popAll();
	}
	protected void dfs(Vertice vOrigen, Pila Recorrido, boolean visitados[]) {	//interno
		visitados[vOrigen.getPosicion()] = true;
		Recorrido.push(vOrigen.getDato());
		Lista aristas = vOrigen.getAdyacentes();
		Vertice auxi;
		aristas.begin();
		while(!aristas.end()) {
			auxi = ((Arista) aristas.get()).getDestino();
			if(!visitados[auxi.getPosicion()]) this.dfs(auxi, Recorrido, visitados);
			aristas.next();
		}
	}
	
	
	//devuelve una lista de los valores de los nodos segun recorrido 
	//broad first search o por amplitud
	//se procesa un nodo, luego sus adyacentes, los adyacentes de sus adyacentes...
	//para lograrlo se utiliza una cola interna, se encola un primer elemento,
	//y se lo marca tomado. Luego mientras no se vacie la cola, se lee de ella
	//el elemento a procesar, se lo procesa y se encolan a todos sus hijos no tomados
	//marcandolos como tomados
	/* T(V,A) = cte + V * cte + V * ai + V
	 *        = cte + (cte+1) V + A
	 *        = O(V + A)   LINEAL						 */
	public Lista bfs() {										//driver BFS general
		Pila Recorrido = new Pila();
		boolean tomados[] = new boolean[this.cantVertices];
		for(int i = 0; i<this.cantVertices; i++) {
			if(!tomados[i]) this.bfs(this.vertices[i], Recorrido, tomados);
		}
		return Recorrido.popAll();
	}
	public Lista bfs(Comparable unDatoOrigen) {					//BFS desde determinado dato
		Pila Recorrido = new Pila();		
		int posicionDato = this.posicion(unDatoOrigen);
		if(posicionDato>=0) {
			boolean tomados[] = new boolean[this.cantVertices];
			this.bfs(this.vertices[posicionDato], Recorrido, tomados); 
		}
		return Recorrido.popAll();
	}
	protected void bfs(Vertice vOrigen, Pila Recorrido, boolean tomados[]) {	//interno
		Cola ordenProcesamiento = new Cola(); //cola auxiliar
		Lista aristas;	//auxiliar
		Vertice auxi;	//auxiliar
		ordenProcesamiento.push(vOrigen);				//encolo el origen
		tomados[vOrigen.getPosicion()] = true;		//y lo marco visitado
		while(!ordenProcesamiento.isEmpty()) {
			vOrigen = (Vertice) ordenProcesamiento.pop();	//saco elemento a procesar			
			Recorrido.push(vOrigen.getDato());				//proceso
			aristas = vOrigen.getAdyacentes();				//recorro adyacentes			
			aristas.begin();								
			while(!aristas.end()) {							
				auxi = ((Arista) aristas.get()).getDestino();
				if(!tomados[auxi.getPosicion()]) {		//a los no visitados, los
					ordenProcesamiento.push(auxi);			//encolo p/ post. proceso
					tomados[auxi.getPosicion()] = true;	//y los marco visitados
				}
				aristas.next();
			}
		}
	}

	//devuelve verdadero o falso segun el grafo tenga o no ciclos
	//lo calcula en base a un dfs segun los tipos de arcos del bosque resultante
	/* el arbol/bosque de expansion de un recorrido dfs puede tener arcos:
	 * - arcos tree: arcos de un vertice a sus hijos en el arbol de expansion.
	 * - arcos fordware: arcos de un vertice a un descendiente indirecto en el
	 *   arbol de expansion
	 * - arcos back: arcos de un vertice a un antecesor en el arbol de expansion
	 * - arcos cross: arcos de un vertice a otro que no es antecesor ni descendiente en el
	 *   arbol de expansion, o a un vertice en otro arbol del bosque
	 * En un grafo no dirigido, cualquier arco que no este en el arbol -arco tree- implica
	 * que el grafo tiene ciclos. En estos grafos, los arcos cross son siempre dentro de un
	 * mismo arbol (imposible que sean a otro arbol del bosque)
	 * En un d�grafo, solo la presencia de un arco back implica un ciclo -excepto los arcos
	 * de un vertice a s� mismo que se consideran tambien arcos back-.
	 * Un arco tree se identifica facilmente porque el vertice adyacente no est� visitado
	 * al procesar la arista. Para el resto de los arcos, se los puede identificar manejando
	 * un contador que numere a los vertices a medida que se los procesa.
	 * Si se tiene una arista a un vertice ya visitado con numeracion mayor es un arco
	 * fordware; si la numeracion es menor, puede ser arco back o cross. Puede distinguirse
	 * segun sea el vertice destino un descendiente o no. Un w es descendiente de v sii:
	 *    numeracion(v) <= numeracion(w) <= numeracion(v) + cant.descendientes(v) 
	 */
	/* T(V,A) = cte + V*cte + V*ai = cte + V*cte + A = O(V + A)  LINEAL (ES UN DFS)	 */
	public boolean tieneCiclo() {
		boolean encontroCiclo = false;
		//vector "visitados" de DFS se puede reemplazar directamente por la numeracion		
		int numeracion[][] = new int[this.cantVertices][2]; //en 0 guardo el numero del vertice
													//en 1 el ult. descendiente
		int contador = 0;
		for(int i = 0; i<this.cantVertices && !encontroCiclo; i++) {
			if(numeracion[i][0]==0) {
				contador = contador + 1;
				encontroCiclo = this.dfsControlCiclos(this.vertices[i], numeracion, contador);
			}
		}		
		return encontroCiclo;
	}
	private boolean dfsControlCiclos(Vertice vOrigen, int numeracion[][], int contador) {
		boolean encontroCiclo = false;
		//numeracion del vertice
		numeracion[vOrigen.getPosicion()][0] = contador;
		//marca que lo va a procesar considerando en principio que sera el antecesor de
		//todos los que faltan revisar - para simplificar distincion back/cross
		numeracion[vOrigen.getPosicion()][1] = this.cantVertices; 
		Lista aristas = vOrigen.getAdyacentes();
		Vertice auxi;
		aristas.begin();
		while(!aristas.end() && !encontroCiclo) {
			auxi = ((Arista) aristas.get()).getDestino();
			//numeracion en 0: no visitado, se hace dfsControlCiclos
			//numeracion > a la de vOrigen: fordware, no afecta
			//numeracion < a la de vOrigen: �cross o back?
			//	si la numeracion de vOrigen es <= al ultimo descendiente de auxi ES BACK Y HAY CICLO
			//  sino es cross y no importa
			if(numeracion[auxi.getPosicion()][0]==0) { //aun no visitado
				contador = contador+1;
				encontroCiclo = this.dfsControlCiclos(auxi, numeracion, contador);
			} else if(numeracion[auxi.getPosicion()][0] < numeracion[vOrigen.getPosicion()][0]) {
				encontroCiclo = (numeracion[vOrigen.getPosicion()][0] <= numeracion[auxi.getPosicion()][1]); 
			}
			aristas.next();
		}
		numeracion[vOrigen.getPosicion()][1] = contador; //completa bien la numeracion de su ultimo hijo
		return encontroCiclo;
	}
	
	
	//devuelve una lista con el sort topologico del grafo
	//es decir, interpretando a las aristas como "pre-requisitos" que dictan el 
	//orden en que se deben visitar los vertices (o en que se deben cumplir ciertas tareas)
	//devuelve una lista con una secuencia correcta para visitar a todos los posibles
	// (si no se puede visitar a alguno es porque hay un ciclo)
	/* T(V,A) = cte + V (cte + ai * cte) + V * cte     + V (cte + ai * cte)
	 *         inic + grados in          + busq grad 0 + while (recorre todos los vertices en el peor caso)
	 *        = cte + V * 3 * cte + 2 * A * cte 
	 *        = O(V + A)  LINEAL 			 */
	public Lista sortTopologico() {
		Pila secuencia = new Pila(); //donde formar la secuencia
		//obtengo los grados de entrada de cada nodo
		//encolo para procesar primero a los que tengan grado 0 -sin dependencias-
		//mientras tenga q procesar
			//desencolo y pongo en mi secuencia de resultado
			//recorro adyacentes decrementando su grado de entrada -tienen una dependencia ya cumplida-
			//si llegan a 0 los encolo
		int[] gradosEntrada = new int[this.cantVertices];
		Cola ordenProcesamiento = new Cola();
		Vertice aux;
		Lista adyacentes;
		int i;
		for(i=0; i<this.cantVertices; i++) {
			adyacentes = this.vertices[i].getAdyacentes();
			adyacentes.begin();
			while(!adyacentes.end()) {
				aux = ((Arista) adyacentes.get()).getDestino();
				gradosEntrada[aux.getPosicion()]++;
				adyacentes.next();
			}
		}
		for(i=0; i<this.cantVertices; i++)
			if(gradosEntrada[i]==0)  ordenProcesamiento.push(this.vertices[i]);		
		while(!ordenProcesamiento.isEmpty()) {
			aux = (Vertice) ordenProcesamiento.pop();
			secuencia.push(aux.getDato());
			adyacentes = aux.getAdyacentes();
			adyacentes.begin();
			while(!adyacentes.end()) {
				aux = ((Arista) adyacentes.get()).getDestino();
				gradosEntrada[aux.getPosicion()]--;
				if(gradosEntrada[aux.getPosicion()]==0) ordenProcesamiento.push(aux);
				adyacentes.next();
			}
		}
		return secuencia.popAll();
	}

	//devuelve verdadero o falso segun el grafo tenga o no ciclos
	//hace un sort topologico, y controla si el tama�o de la respuesta es
	//exactamente la cantidad de nodos del grafo -NO HAY CICLO- o es menor
	//-FALTAN PROCESAR A LOS CICLICOS-
	public boolean tieneCiclo2() {
		return (this.sortTopologico().size() != this.cantVertices);
	}
	
	//devuelve un string con todos los vertices [adyacentes], uno debajo del otro
	public String toString() {
		StringBuffer sb = new StringBuffer();
		Lista vert = this.listaDeVertices();
		vert.begin();
		while(!vert.end()) {			
			sb.append(vert.get());
			sb.append("  ");
			sb.append(this.listaDeAdyacentes((Comparable) vert.get()));
			sb.append("\n");
			vert.next();
		}
		return sb.toString();
	}
}
