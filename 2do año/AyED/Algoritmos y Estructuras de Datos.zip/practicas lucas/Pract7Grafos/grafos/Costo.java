package grafos;

@SuppressWarnings("unchecked")
public class Costo implements Comparable {
	Vertice	vertice, previo;
	int		costo;
	  
	public Costo(Vertice destino, Vertice origen, int costo) {
			this.vertice = destino;
			this.previo = origen;
			this.costo = costo;
	}
	public Costo(Vertice destino, Vertice origen) {
			this.vertice = destino;
			this.previo = origen;
			this.costo = 0;
	}
	public Costo(Vertice destino) {
			this.vertice = destino;
			this.previo = destino;
			this.costo = 0;
	}
	  
	public String toString() {
		  return "De [" + previo.getDato() + "] a [" + vertice.getDato() + "] con costo total: " + this.costo + "\n";  
	}
	public int compareTo(Object Obj) {
		  if(Obj!=null && Obj instanceof Costo) 
			  return (this.costo - ((Costo) Obj).costo);
		  return -1;
	}
  
  
	public Vertice getVertice() {
		return vertice;
	}
	public Vertice getPrevio() {
		return previo;
	}
	public int getCosto() {
		return costo;
	}
	public void setVertice(Vertice vertice) {
		this.vertice = vertice;
	}
	public void setPrevio(Vertice previo) {
		this.previo = previo;
	}
	public void setCosto(int costo) {
		this.costo = costo;
	}
}
