package grafos;

class AristaPesada extends Arista {
	protected int peso;
	
	public AristaPesada(Vertice destino, int peso) {
		super(destino);
		this.peso = peso;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}	
}
