package grafos;

import Heap.Heap;
import arboles.Cola;
import arboles.Lista;
import arboles.Pila;

@SuppressWarnings("unchecked")
public class GrafoPesado extends Grafo {
	
	//un grafo pesado sigue teniendo el metodo conectar
	public boolean conectar(Comparable unDato, Comparable otroDato, int peso) {
		int posicion1 = this.posicion(unDato);
		int posicion2 = this.posicion(otroDato);
		if(posicion1>=0 && posicion2>=0) { //si estaban los dos
			this.vertices[posicion1].conectar(this.vertices[posicion2], peso);
			return true;
		} else {
			return false; //alguno no estaba -o ninguno-
		}		
	}
	
	public int getPeso(Comparable unDato, Comparable otroDato) {
		int posicion1 = this.posicion(unDato);
		int posicion2 = this.posicion(otroDato);
		int peso = -1;
		if(posicion1>=0 && posicion2>=0) { //si estaban los dos
			Lista L = this.vertices[posicion1].getAdyacentes();
			L.begin();
			while(!L.end() && !L.get().equals(this.vertices[posicion2])) {
				L.next();
			}
			if(!L.end()) {
				if(L.get() instanceof AristaPesada) { //controlo porque podria tener una arista simple
					peso = ((AristaPesada) L.get()).getPeso();
				} else {
					peso = -2; //existe conexion pero no tiene peso asignado
				}
			}			
		} 
		return peso;
	}
	
	/* ALGORITMO DE DIJKSTRA PARA CAMINOS DE COSTO MINIMO - GRAFOS PESADOS
	 * (Para grafos sin peso, se hace un BFS con array de previos y distancias)
	 * Los pesos deben ser no negativos para dijkstra. Se usan arrays de previo,
	 * distancia y visitados. Inicialmente, distancias se completa con valores
	 * infinito, salvo para el origen que ser� 0.
	 * En cada iteracion se elige el vertice con menor distancia sin visitar, y se
	 * evalua a todos sus adyacentes no visitados. Si la distancia nueva es menor a la
	 * registrada en distancias, se elige la nueva opcion y se completa el previo.
	 * 
	 * T(V,A) = cte inicializacion + V veces (tomar menor Vi sin visitar y recorrer su ai)
	 *        = cte                + V *     (V + ai)
	 *        = cte                + V^2 + A
	 *        = O(V^2)    CUADRATICO
	 * El componente cuadr�tico se debe a la busqueda del menor Vi sin visitar.
	 * Se podria mejorar utilizando una HEAP que devuelva siempre el menor con tiempo O(1)
	 * y que mantenga su orden con un O(log V). En la heap inicialmente se podria poner 0
	 * asociado al origen e infinito asociado al resto -se obviar�a y no se ponen
	 * directamente. La HEAP es COMPLEMENTARIA, no reemplaza al vector de distancias,
	 * solo permite accederlos ordenadamente. Al obtener una distancia menor para un vertice
	 * se lo debe actualizar en el vector Y en la HEAP -habria que recorrerla para encontrar
	 * el nodo y hacer decrease key (O(V) y O(logV)). Se podria evitar con un hash asociado
	 * que devuelve la posicion del nodo en la heap, o simplemente agregando la nueva distancia
	 * en la heap -se va a leer obviamente antes que la distancia anterior por ser menor-
	 * La lectura de la heap se har�a as� hasta que devuelva un vertice no visitado a�n (ya
	 * que acumularia "basura"). 
	 * Ya utilizando la heap:
	 *  T(V,A) = cte inic. + V veces en w.c. (tomar Vi sin visitar de H y recorrer ai agregando en H)
	 *         = cte + V * (Log(?1?) + ai * Log(?2?))
	 *         = cte + V Log(?1?) + A log(?2?)
	 *  w.c.: "peor caso" seria que el vertice origen sea conexo -podra alcanzar a todos los otros v-
	 *  y que cada nuevo camino que explore resulte en una mejora con lo cual debera insertar en H
	 *  	?1? se refiere a tomar un nuevo vertice aun no procesado de la heap
	 *  	?2? se refiere a la insercion de los elemtos en la heap
	 *  Como la H en el w.c. crecera en relacion a A (se insertaran en el w.c. tantos elementos como
	 *  aristas hay en el grafo) entonces Log(?2?) es Log(A).
	 *  ?1? leera de una H con A elemenos en el w.c. La lectura sera se coste O(Log(A)). Pero tambien
	 *  leera la "basura", que para cada vertice ser� uno menos a la cantidad ai' de aristas que
	 *  llegan al vertice. En total la cant de lecturas sera A (V * vi' : vi' aristas incidentes a vi).
	 *  As� ?1? ser�a A Log(A) (A lecturas, con costo Log(A) en el w.c.  --obvio que es sobreestimacion)
	 *  Resumiendo:
	 *  T(V,A) = cte + A Log(A) + A Log(A)
	 *         = cte + 2 A Log(A)
	 *         = O(A Log(A))               A LOG(A)  ("CASI LINEAL" RESPECTO DE A --algo mayor)
	 *  Como A <= V^2  -->  Log(A) <= 2 Log(V)
	 *  Puede decirse tambien que:
	 *  T(V,A) = O(A Log(V))   con una sobreestimacion > mientras menos denso sea el grafo (a medida que A<<)
	 *  en el peor caso, un grafo DENSO, se tiene:
	 *       A  =  V^2
	 *  y    T(V,A) = O(V^2 Log(V))       V^2 Log(V)  ("CASI" CUADRATICO  --algo mayor)
	 *  EN GRAFOS DENSOS, ser�a conveniente as� la implementacion SIN HEAP.
	 *  Si se considera una estructua HEAP + HASH se podr�a llegar a algo como V log(V) (poco m as que lineal)
	 */
	private Lista dijkstra(Vertice v) { //caminos minimos
		//lista para devolver
		Lista caminoMin = new Lista();
		//estructuras auxiliares para dijkstra
		Heap miHeap = new Heap();		
		int distancias[] = new int[this.cantVertices];
		boolean visitados[] = new boolean[this.cantVertices];
		int previo[] = new int[this.cantVertices];
		//inicializacion: sin previo ni distancias validas, salvo v que parte de el mismo con distancia 0
		for(int i = 0; i < this.cantVertices; i++) {
			previo[i] = -1;
			visitados[i] = false;
			distancias[i] = Integer.MAX_VALUE;
		}
		previo[v.getPosicion()] = v.getPosicion();
		distancias[v.getPosicion()] = 0;
		miHeap.agregar(new Costo(v)); //costo 0 para el vertice de origen
		Costo siguiente;
		Lista aristas;
		AristaPesada arista;
		Vertice adyacente;
		//for(int i = 0; i< this.cantVertices; i++) { ********************************
		while(!miHeap.esVacia() &&  caminoMin.size()<this.cantVertices ) {
			//leo de la heap mientras esten ya tomados y haya que leer
			do {
				siguiente = (Costo) miHeap.tope();
				v = siguiente.getVertice();				
			} while (!miHeap.esVacia() && visitados[v.getPosicion()]);
			//} while (visitados[v.getPosicion()]); **********************************
			if(!visitados[v.getPosicion()]) { //**************************************
				//agrego el costo al camino
				visitados[v.getPosicion()] = true;
				caminoMin.add(siguiente);
				aristas = v.getAdyacentes();
				aristas.begin();
				while(!aristas.end()) {
					arista    = (AristaPesada) aristas.get();
					adyacente = arista.getDestino();
					//si el adyacente no esta visitado
					if(!visitados[adyacente.getPosicion()]) {
						//si puedo lograr una distancia mejor la actualizo
						//if (arista.getPeso()<0) PUEDE DAR RESULTADOS ERRONEOS. SE SUPONE QUE SE USE DIJKSTRA
						//                        CON PESOS POSITIVOS O NULOS
						if(distancias[adyacente.getPosicion()] > distancias[v.getPosicion()] + arista.getPeso()) {
							distancias[adyacente.getPosicion()] = distancias[v.getPosicion()] + arista.getPeso();
							previo[adyacente.getPosicion()] = v.getPosicion();
							miHeap.agregar(new Costo(adyacente, v, distancias[adyacente.getPosicion()]));
						}
					}
					aristas.next();
				}
			}
		}
		/* Nota sobre los "********":  Las lineas que agregue o modifiqu� y marque 
		 * con asteriscos, son correcciones que tuve en cuenta por si el origen v no
		 * es conexo (si hay vertices que nunca podra alcanzar, iterar V veces produce
		 * error al vaciar la heap y pretender seguir iterando). */
		return caminoMin;
	}

  	public Lista dijkstra(Comparable datoOrigen) {
		int posicionOrigen = this.posicion(datoOrigen);		
		if(posicionOrigen<0) return new Lista();
		return this.dijkstra(this.vertices[posicionOrigen]);
  	}
  	
  	public Lista caminoMinimo(Comparable datoOrigen, Comparable datoDestino) {
  		int posicionOrigen = this.posicion(datoOrigen);
  		int posicionDestino = this.posicion(datoDestino);
		if(posicionOrigen<0 || posicionDestino<0) return null;
		Lista cammin = this.dijkstra(vertices[posicionOrigen]);
		return this.construirCaminoEnReversa(vertices[posicionOrigen], vertices[posicionDestino], cammin);
  	}


  	/* CONSIDERANDO QUE PUEDA HABER PESOS NEGATIVOS.............................
  	 * Encolar el v�rtice origen s.
  	 * Procesar la cola:
  	 * 		Desencolar un v�rtice.
  	 * 		(si ya se lo encolo mas de 2*cantvertices es porque hay ciclo negativo)
  	 *		Actualizar la distancia de los adyacentes siguiendo el mismo criterio de Dijkstra.
  	 * 		Si w no est� en la cola, encolarlo.
  	 * Cada vertice se va a encolar en el w.c. tantas veces como aristas incidentes tenga.
  	 * El total de inserciones en la cola ser� A.
  	 */
  	private Lista caminosMinimoConNegativos(Vertice vOrigen) throws Exception  {
		//lista para devolver
		Lista caminoMin = new Lista();
		//estructuras auxiliares 
		Cola c = new Cola();
		int distancias[] = new int[this.cantVertices];
		int cantVisitas[] = new int[this.cantVertices];
		int previo[] = new int[this.cantVertices];
		//inicializacion: sin previo ni distancias validas, salvo v que parte de el mismo con distancia 0
		for(int i = 0; i < this.cantVertices; i++) {
			previo[i] = -1;
			cantVisitas[i] = 0;
			distancias[i] = Integer.MAX_VALUE;
		}		
		previo[vOrigen.getPosicion()] = vOrigen.getPosicion();
		distancias[vOrigen.getPosicion()] = 0;
		cantVisitas[vOrigen.getPosicion()]++;
		c.push(vOrigen); //costo 0 para el vertice de origen
		Lista aristas;
		AristaPesada arista;
		Vertice v, adyacente;
		while(!c.isEmpty()) {
			v = (Vertice) c.pop();
			cantVisitas[v.getPosicion()]++; //sumo uno para que queda par: no esta mas en la cola
			if(cantVisitas[v.getPosicion()] > 2*this.cantVertices) {
				System.out.println("ERROR CICLO NEGATIVO \n");
				throw new Exception("Ciclo negativo detectado");
			}
			
			aristas = v.getAdyacentes();
			aristas.begin();
			while(!aristas.end()) {
				arista    = (AristaPesada) aristas.get();
				adyacente = arista.getDestino();
				//si puedo lograr una distancia mejor la actualizo
				if(distancias[adyacente.getPosicion()] > distancias[v.getPosicion()] + arista.getPeso()) {
					distancias[adyacente.getPosicion()] = distancias[v.getPosicion()] + arista.getPeso();
					previo[adyacente.getPosicion()] = v.getPosicion();
					if(cantVisitas[adyacente.getPosicion()] % 2 == 0) { //si no esta en la cola
						c.push(adyacente);
						cantVisitas[adyacente.getPosicion()]++;
					}
				}
				aristas.next();
			}
		}
		
		//armo las lista de costos para devolver, en el orden adecuado para formar los camino
		//--convendria poner los arrays como vbles de instacia
		Pila p = new Pila();
		c = new Cola();
		c.push(vOrigen);
		while(!c.isEmpty()) {
			v = (Vertice) c.pop();
			caminoMin.add(new Costo(v, vertices[previo[v.getPosicion()]], distancias[v.getPosicion()]));
			//recorro y encolo los que lo tienen de previo
			aristas = v.getAdyacentes();
			aristas.begin();
			while(!aristas.end()) {
				arista    = (AristaPesada) aristas.get();
				adyacente = arista.getDestino();
				//si puedo lograr una distancia mejor la actualizo
				if(previo[adyacente.getPosicion()] == v.getPosicion()) 
					c.push(adyacente);
				aristas.next();
			}
		}
		/*for(int i=0; i< this.cantVertices; i++)
			//si ese vertice se pudo alcanzar desde el origen agrega el costo
			if(previo[i]>=0) caminoMin.add(new Costo(vertices[i], vertices[previo[i]], distancias[i]));*/
		return caminoMin;
	}


  	public Lista caminosMinimoConNegativos(Comparable datoOrigen) throws Exception {
		int posicionOrigen = this.posicion(datoOrigen);		
		if(posicionOrigen<0) return new Lista();
		return this.caminosMinimoConNegativos(this.vertices[posicionOrigen]);
  	}
  	
  	public Lista caminoMinimoConNegativos(Comparable datoOrigen, Comparable datoDestino) throws Exception {
  		int posicionOrigen = this.posicion(datoOrigen);
  		int posicionDestino = this.posicion(datoDestino);
		if(posicionOrigen<0 || posicionDestino<0) return null;
		Lista cammin = this.caminosMinimoConNegativos(vertices[posicionOrigen]);
		return this.construirCaminoEnReversa(vertices[posicionOrigen], vertices[posicionDestino], cammin);
  	}
  	
  	//en base a una lista de costos, reconstruye el camino de un origen a un destino procesando
  	//en revarsa, buscando los previos.
  	private Lista construirCaminoEnReversa(Vertice vOrigen, Vertice vDestino, Lista cammin) {
		cammin.begin();
		Lista resultado = new Lista();
		Costo costoAux;
		while(vDestino!=null && !vDestino.equals(vOrigen)) {
			resultado.add(vDestino.getDato()); //agrego el vertice a la salida
			//tengo q buscar en el cam de disjkstra ese destino y ver de donde se llega
			//el previo se pasara a vert para que sea agregado al resultado
			do {
				costoAux = (Costo) cammin.get();
				cammin.next();
			} while(!cammin.end() && (!costoAux.getVertice().equals(vDestino)));			
			if(costoAux.getVertice().equals(vDestino)) {				
				vDestino = costoAux.getPrevio();
			}else{
				vDestino = null;
			}
		}		
		//agrego el ultimo --o sea el origen
		if(vDestino!=null)	resultado.add(vDestino.getDato());
		return resultado;  		
  	}
}
