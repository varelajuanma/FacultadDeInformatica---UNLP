package grafos;

import arboles.Lista;

@SuppressWarnings("unchecked")
class Vertice {
	protected Comparable dato;
	Lista adyacentes;
	int posicion;
	
	public Vertice(Comparable dato) {	//CONSTRUCTOR
		this.dato = dato;
		this.posicion = 0;
		this.adyacentes = new Lista();
	}
	
	//GETTERS Y SETTERS
	public Comparable getDato() {
		return dato;
	}
	public void setDato(Comparable dato) {
		this.dato = dato;
	}
	

	public Lista getAdyacentes() {
		return adyacentes;
	}
	public void setAdyacentes(Lista adyacentes) {
		this.adyacentes = adyacentes;
	}
	

	public int getPosicion() {
		return posicion;
	}
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}
	
	
	//METODOS DE INSTANCIA
	public void conectar(Vertice vertDestino) {
		this.agregarSinRepeticion(new Arista(vertDestino));
	}
	public void conectar(Vertice vertDestino, int peso) {
		this.agregarSinRepeticion(new AristaPesada(vertDestino, peso));
	}
	private void agregarSinRepeticion(Arista nuevaArista) {
		if(!this.adyacentes.includes(nuevaArista))
			this.adyacentes.add(nuevaArista);
	}
	public void desconectar(Vertice vertDestino) {
		this.adyacentes.remove(new Arista(vertDestino));
	}
}
