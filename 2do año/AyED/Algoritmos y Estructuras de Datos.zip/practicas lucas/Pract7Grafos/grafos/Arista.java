package grafos;

@SuppressWarnings("unchecked")
class Arista {
	Vertice destino;
	
	public Arista(Vertice destino) {
		this.destino = destino;
	}

	public Vertice getDestino() {
		return destino;
	}

	public void setDestino(Vertice destino) {
		this.destino = destino;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Arista && obj!=null) {
			Arista otraArista = (Arista) obj;
			return (this.getDestino().equals(otraArista.getDestino()));
		} else if (obj instanceof Vertice && obj!=null) {
			Vertice unVertice = (Vertice) obj;
			return (this.getDestino().equals(unVertice));
		} else {
			return false;
		}
	}
	
}
