package pruebaGrafos;

import grafos.GrafoPesado;

public class TestDijkstra {
    //SEGUN EJEMPLO DE LAS TRANSPARENCIAS
	public static void main(String[] args) throws Exception  {
		GrafoPesado miGp = new GrafoPesado();
		miGp.agregarVertice(1); //6 vertices
		miGp.agregarVertice(2);
		miGp.agregarVertice(3);
		miGp.agregarVertice(4);
		miGp.agregarVertice(5);
		miGp.agregarVertice(6);
		miGp.agregarVertice(99);		
		miGp.conectar(1,3,40);  //10 aristas
		miGp.conectar(1,5,10);
		miGp.conectar(1,6,5);		
		miGp.conectar(2,4,5);
		miGp.conectar(3,2,10);
		miGp.conectar(3,5,5);
		miGp.conectar(4,3,5);
		miGp.conectar(5,4,20);
		miGp.conectar(6,2,20);
		miGp.conectar(6,5,10);
		System.out.println(miGp);
		System.out.println("\nCamino del algoritmo de DIJKSTRA desde 1\n");
		System.out.println(miGp.dijkstra(1));
		System.out.println("Camino de 1 a 6? " + miGp.caminoMinimoConNegativos(1,6));
		System.out.println("Camino de 1 a 4? " + miGp.caminoMinimoConNegativos(1,4));
		System.out.println("Camino de 1 a 3? " + miGp.caminoMinimoConNegativos(1,3));
	}

}
