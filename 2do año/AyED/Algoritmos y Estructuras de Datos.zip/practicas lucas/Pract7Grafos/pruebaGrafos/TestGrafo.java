package pruebaGrafos;

import grafos.Grafo;
import arboles.Lista;

//la pongo en otro paquete para q no vea ni las aristas ni los vertices
@SuppressWarnings("unchecked")
public class TestGrafo {

	public static void main(String[] args) {
		Grafo miG = new Grafo();
		miG.agregarVertice("lucas");
		miG.agregarVertice("pablo");
		miG.agregarVertice("javier");
		miG.agregarVertice("martin");
		miG.agregarVertice("eloy");
		miG.agregarVertice("pepe");
		//miG.conectar("lucas", "pablo");
		miG.conectar("lucas", "javier");
		miG.conectar("lucas", "martin");
		miG.conectar("lucas", "eloy");
		miG.conectar("lucas", "pepe");
		miG.conectar("javier", "pepe");
		miG.conectar("javier", "lucas");
		miG.conectar("javier", "pablo");
		miG.conectar("pablo", "pepe");
		//miG.conectar("pablo", "lucas");
		miG.conectar("pablo", "javier");
		System.out.println("lucas y martin?" +	miG.esAdyacente("lucas", "martin") );
		System.out.println("lucas y enrique?" +	miG.esAdyacente("lucas", "enrique") );
		System.out.println("pablo y javier?" +	miG.esAdyacente("pablo", "javier") );
		System.out.println("javier y pablo?" +	miG.esAdyacente("javier", "pablo") );
		Lista vert = miG.listaDeVertices();		
		System.out.println("\nLista de datos y relaciones");
		vert.begin();
		while(!vert.end()) {			
			System.out.println(vert.get() + "  " + miG.listaDeAdyacentes((Comparable) vert.get())); 
			vert.next();
		}
		
		System.out.println("\nDFS desde javier -alcanzables desde javier");
		System.out.println(miG.dfs("javier"));

		System.out.println("\nDFS desde eloy -alcanzables desde eloy");
		System.out.println(miG.dfs("eloy"));
		
		System.out.println("\nDFS desde lucas -alcanzables desde lucas");
		System.out.println(miG.dfs("lucas"));
		
		
		System.out.println("\nBFS desde javier -alcanzables desde javier");
		System.out.println(miG.bfs("javier"));

		System.out.println("\nBFS desde eloy -alcanzables desde eloy");
		System.out.println(miG.bfs("eloy"));
		
		System.out.println("\nBFS desde lucas -alcanzables desde lucas");
		System.out.println(miG.bfs("lucas"));
		
		System.out.println("\nSORT TOPOLOGICO");
		System.out.println(miG.sortTopologico());
		System.out.println("tiene ciclos??? DFS: " + miG.tieneCiclo() + "  SORT TOPOLOGICO: " + miG.tieneCiclo2());
		
		System.out.println("\nDESPUES DE BORRARME: Lista de datos y relaciones");
		miG.eliminarVertice("lucas");
		vert = miG.listaDeVertices();
		vert.begin();
		while(!vert.end()) {			
			System.out.println(vert.get() + "  " + miG.listaDeAdyacentes((Comparable) vert.get())); 
			vert.next();
		}
		
		System.out.println("\nSORT TOPOLOGICO");
		System.out.println(miG.sortTopologico());
		System.out.println("tiene ciclos??? DFS: " + miG.tieneCiclo() + "  SORT TOPOLOGICO: " + miG.tieneCiclo2());
		
		miG.desconectar("javier", "pablo");
		System.out.println("\nGrafo al final de todos los cambios:\n" + miG);
		System.out.println("\nSORT TOPOLOGICO");
		System.out.println(miG.sortTopologico());
		System.out.println("tiene ciclos??? DFS: " + miG.tieneCiclo() + "  SORT TOPOLOGICO: " + miG.tieneCiclo2());
	}

}
