package pruebaGrafos;

import grafos.GrafoPesado;

public class TestGrafoPesado {

	public static void main(String[] args) {
		GrafoPesado miGp = new GrafoPesado();
		miGp.agregarVertice("A");
		miGp.agregarVertice("B");
		miGp.agregarVertice("C");
		miGp.agregarVertice("D");
		miGp.conectar("A", "D");
		miGp.conectar("A", "B", 10);
		miGp.conectar("A", "C", 6);
		miGp.conectar("B", "D", 3);
		miGp.conectar("B", "A", 1);
		System.out.println("peso A>B: " + miGp.getPeso("A", "B"));
		System.out.println("peso A>D: " + miGp.getPeso("A", "D"));
		System.out.println("peso A>C: " + miGp.getPeso("A", "C"));
		System.out.println("peso B>D: " + miGp.getPeso("B", "D"));
		System.out.println("peso B>H: " + miGp.getPeso("B", "H"));
		miGp.eliminarVertice("A");
		System.out.println("Ahora que borre a A????");
		System.out.println("peso A>B: " + miGp.getPeso("A", "B"));
		System.out.println("peso A>D: " + miGp.getPeso("A", "D"));
		System.out.println("peso A>C: " + miGp.getPeso("A", "C"));
		System.out.println("peso B>D: " + miGp.getPeso("B", "D"));
		System.out.println("peso B>H: " + miGp.getPeso("B", "H"));
	}

}
