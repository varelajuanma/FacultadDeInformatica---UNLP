package Ejercicios;

class Bloque {
	boolean libre;
	int tamanio;
	int dirComienzo;
	
	public Bloque(int tam, int dirComienzo) { //CONSTRUCTOR ////////////
		this.tamanio		= tam;
		this.dirComienzo	= dirComienzo;
	}

	public boolean GgetLibre() {
		return libre;
	}

	public void setLibre() {
		this.libre = true;
	}
	public void setOcupado() {
		this.libre = false;
	}
}
