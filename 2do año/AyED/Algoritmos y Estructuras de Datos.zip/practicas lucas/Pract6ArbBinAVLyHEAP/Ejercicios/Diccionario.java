package Ejercicios;

import ArbolesBinariosyAVL.ArbolAVL;
import arboles.Cola;

@SuppressWarnings("unchecked")
public class Diccionario {
	//para lograr O(logN) en agregar, reemplazar -buscar- y eliminar
	protected ArbolAVL elementos;
	
	//CONSTRUCTOR ///////////////////////////////////////////////////	
	public Diccionario() {
		this.elementos = new ArbolAVL();
	}
	
	//METODOS PUBLICOS //////////////////////////////////////////////
	//agrega el par clave-valor con clave unica
	public boolean agregar(Comparable clave, Object valor) {
		boolean puedeAgregar = (this.recuperar(clave)==null);
		if(puedeAgregar) {
			entradaDiccionario nuevaEntrada = new entradaDiccionario(clave, valor);
			this.elementos.agregar(nuevaEntrada);
		}
		return puedeAgregar;
	}
	//reemplaza el valor asociado a una clave, si existe
	public boolean reemplazar(Comparable clave, Object valor) {
		//en realidad tendria que eliminaro y agregalo de nuevo en this.elementos
		//el valor de un nodo no deberi apoderse modificar por riesgo de perder
		//el orden en el AVL.		
		entradaDiccionario entrada = this.recuperarEntrada(clave);
		if(entrada!=null) entrada.setValor(valor);
		return (entrada!=null);
	}
	//reemplaza todos los valores de todas las entradas
	public void agregarATodos(Object valor) {
		//recorrido del arbol AVL seteando el valor de c/entrada
		//Lista nodos = this.elemenos.getNodosPreOrden();
		//recorrer nodos haciendo setValor();
		//lastima q no puedo devolver copias as� las modifico y le pongo un reemplazar a AVL
		Cola nodos = this.elementos.getNodosInOrden();
		entradaDiccionario entrada;
		while(!nodos.isEmpty()) {
			entrada = (entradaDiccionario) nodos.pop();
			entrada.setValor(valor);
		}
	}
	//recupera el valor de una clave
	public Object recuperar(Comparable clave) {
		Object valor = null;		
		entradaDiccionario entrada = this.recuperarEntrada(clave);
		if(entrada!=null) valor = entrada.getValor();
		return valor;
	}
	//elimina la entrada de una clave
	public void eliminar(Comparable clave) {
		this.elementos.eliminar(new entradaDiccionario(clave,null));
	}
	//devuelve true/false segun la clave exista o no en el dicc
	public boolean incluye(Comparable clave) {
		entradaDiccionario entrada = this.recuperarEntrada(clave);
		return (entrada!=null);
	}
	
	//METODOS PRIVADOS //////////////////////////////////////////////
	//recupera la entrada asociada a una clave
	//SE AGREGO A LA CLASE ARBOLAVL EL METODO PUBLICO
	//COMPARABLE RECUPERAR(COMPARABLE)
	private entradaDiccionario recuperarEntrada(Comparable clave) {
		entradaDiccionario entrada = new entradaDiccionario(clave, null);
		return (entradaDiccionario) this.elementos.recuperar(entrada);
	}	
		
	public String toString() {
		StringBuffer sb = new StringBuffer(" > Diccionario\n ");
		Cola nodos = this.elementos.getNodosInOrden();
		entradaDiccionario entrada;
		while(!nodos.isEmpty()) {
			entrada = (entradaDiccionario) nodos.pop();
			sb.append(entrada.getClave());
			sb.append(": ");
			sb.append(entrada.getValor());
			sb.append("\n ");
		}
		sb.append("> Total entradas: " + this.elementos.cantidad());
		return sb.toString();
	}
	
	
	//INNER CLASS ///////////////////////////////////////////////////
	private class entradaDiccionario implements Comparable {
		private Comparable clave;
		private Object valor;
		//constructor
		public entradaDiccionario(Comparable clave, Object valor) {
			this.clave = clave;
			this.valor = valor;
		}
		//getters y setters
		//solo lectura (si llega a modificar una ya agregada al
		//				AVL romperia su orden)
		public Comparable getClave() {	
			return clave;
		}
		public Object getValor() {
			return valor;
		}
		public void setValor(Object valor) {
			this.valor = valor;
		}
		public String toString() {
			return this.clave.toString();
		}		
		//interfaz		
		public int compareTo(Object otroObjeto) {
			if (otroObjeto instanceof entradaDiccionario) {
				entradaDiccionario otraEntrada = (entradaDiccionario) otroObjeto;
				return this.getClave().compareTo(otraEntrada.getClave());
			} else {
				System.out.println("ERROR: Solo debe comparar contra entradas del diccionario!");
				return 0;
			}
		}
	}//inner class
	
}//public class
