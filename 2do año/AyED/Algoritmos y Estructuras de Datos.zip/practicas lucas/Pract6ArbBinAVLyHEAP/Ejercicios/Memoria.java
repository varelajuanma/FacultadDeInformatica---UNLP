package Ejercicios;
//TODO

//permite solicitar bloques de memoria o liberarlos, las dos operaciones
//con O(log(N))
//una solucion seria 2 arboles AVL, uno ordenado por tamanio y otro por dir
//de comienzo, pero esa la explica el enunciado como ejemplo, hay q usar otra
//igual para pedir no es log(N), porq propone una lista en cada nodo del
//arbol, y ahi se vuelve lineal. podr�a poner una heap en vez de una lista
//y mantengo el orden logaritmico --considero menor a los libres
//al liberarlo, lo agrego en la heap del tamanio q corresponda
public class Memoria {
	//�?
	
	public Memoria() { //CONTRUCTOR /////////////////////////////////////
	}

	public int pedirBloque(int kilobytes) {	//ASIGNACION DE MEMORIA //
		int dirComienzo = 0;
		return dirComienzo;
	}
	
	public void liberarBloque(int dirComienzo) {	//LIBERACION DE MEM //		
	}
	
}
