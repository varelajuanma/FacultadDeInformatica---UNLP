package Ejercicios;


public class TestDiccionario {

	public static void main(String[] args) {
		Diccionario miDicc = new Diccionario();
		miDicc.agregar("Lucas", "Soy Yo");
		miDicc.agregar("Pablo", "Mi Hermano");
		miDicc.agregar("Javier", "Mi Hermano");
		miDicc.agregar("Martin", "AMigo");
		System.out.println("Lucas? " + miDicc.recuperar("Lucas"));
		System.out.println("Pablo? " + miDicc.recuperar("Pablo"));
		System.out.println("pepe? " + miDicc.recuperar("pepe"));
		System.out.println("Martin? " + miDicc.recuperar("Martin"));
		miDicc.reemplazar("Martin", "Amigo.");
		System.out.println("Martin? " + miDicc.recuperar("Martin"));
		System.out.println(miDicc);
		miDicc.eliminar("Javier");
		miDicc.agregarATodos("alguien");		
		miDicc.agregar("Pyto", "Okupa");
		miDicc.agregar("Dogo", "Okupa");
		miDicc.agregar("Amer", "Okupa");
		miDicc.agregar("Hen", "Okupa");
		miDicc.agregar("Chelo", "Okupa");
		System.out.println(miDicc);
		System.out.println("esta Pyto? " + miDicc.incluye("Pyto"));
		System.out.println("esta Juan Pablo? " + miDicc.incluye("Juan Pablo"));
	}

}
