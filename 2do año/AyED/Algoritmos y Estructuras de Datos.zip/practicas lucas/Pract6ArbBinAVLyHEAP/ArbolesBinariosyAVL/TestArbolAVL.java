package ArbolesBinariosyAVL;

public class TestArbolAVL {
	public static void main(String[] args) {
		ArbolAVL A = new ArbolAVL();
		System.out.println("Ejercicio 1.a Pract 6");
		A.agregar(3);
		System.out.println(A);
		A.agregar(1);
		System.out.println(A);
		A.agregar(4);
		System.out.println(A);
		A.agregar(6);
		System.out.println(A);
		A.agregar(80);
		System.out.println(A);
		A.agregar(2);
		System.out.println(A);
		A.agregar(5);
		System.out.println(A);
		A.agregar(7);
		System.out.println(A);
		System.out.println();
		System.out.println("Est� el 7?? " + A.incluye(7));
		System.out.println("Est� el 2?? " + A.incluye(2));
		System.out.println("Est� el 27?? " + A.incluye(27));
		System.out.println("Est� el 1?? " + A.incluye(1));
		System.out.println("Est� el 8?? " + A.incluye(8));
		System.out.println("Est� el 0?? " + A.incluye(0));
		System.out.println("Est� el 80?? " + A.incluye(80));
		System.out.println();
		System.out.println("Ejercicio 1.b Pract 6 - Elimino al 7");
		A.eliminar(7);		
		System.out.println(A);
		System.out.println("Elimino al 1");
		A.eliminar(1);
		System.out.println(A);
		System.out.println("Elimino al 6");
		A.eliminar(6);
		System.out.println(A);
		
		//otras pruebas para borrar con el mas derecho de los izquierdos
		System.out.println("Agrego algunos mas para probar despues borrar el 80");
		A.agregar(100);
		System.out.println(A);
		A.agregar(6);
		System.out.println(A);
		A.agregar(10);
		System.out.println(A);
		A.agregar(7);
		System.out.println(A);
		A.agregar(8);
		System.out.println(A);
		A.agregar(17);
		System.out.println(A);
		System.out.println("borro el 80");
		A.eliminar(80);
		System.out.println(A);
		System.out.println("Altura de A: " + A.altura() + " y cantidad de nodos: " + A.cantidad());
		System.out.println("es minimal A?? " + A.esMinimal());
		A.eliminar(2);
		A.eliminar(5);
		A.eliminar(8);

		System.out.println(A);
		System.out.println("Altura de A: " + A.altura() + " y cantidad de nodos: " + A.cantidad());
		System.out.println("es minimal A?? " + A.esMinimal());
		
	}

}
