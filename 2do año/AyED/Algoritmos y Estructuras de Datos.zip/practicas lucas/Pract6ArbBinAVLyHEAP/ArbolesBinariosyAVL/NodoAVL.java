package ArbolesBinariosyAVL;

@SuppressWarnings("unchecked")
public class NodoAVL {	
	protected Comparable dato;
	protected NodoAVL hijoIzq, hijoDer;
	protected int altura;
	
	//CONSTRUCTOR INDICANDO EL DATO QUE CONTENDR� EL NODO////////
	public NodoAVL(Comparable dato){
		setDato(dato);
		this.setHijoDerecho(null);
		this.setHijoIzquierdo(null);
		this.setAltura(0);
	}
	
	//GETTERS Y SETTERS /////////////////////////////////////////
	public Comparable getDato() {
		return dato;
	}
	public void setDato(Comparable dato) {
		this.dato = dato;
	}
	
	public NodoAVL getHijoDerecho() {
		return hijoDer;
	}
	public void setHijoDerecho(NodoAVL unHijo) {
		this.hijoDer = unHijo;
	}
	
	public NodoAVL getHijoIzquierdo() {
		return hijoIzq;
	}
	public void setHijoIzquierdo(NodoAVL unHijo) {
		this.hijoIzq = unHijo;
	}
	
	public int getAltura() {
		return altura;
	}
	public void setAltura(int h) {
		this.altura = h;
	}

	//CONVERSION A STRING - AGREGADO PARA FACILITAR PRUEBAS /////
	public String toString() {
		return dato.toString();
	}
}
