package ArbolesBinariosyAVL;

import arboles.Cola;
import arboles.Pila;

/*    ------------------------------------
             ArbolAVL
    ------------------------------------
    - NodoBinario    raiz
    ------------------------------------
    +ArbolAVL()
    +incluye(Comparable dato): boolean
    +agregar(Comparable dato)
    +eliminar(Comparable dato)
    +toString(): String
    +cantidad(): int
    +altura(): int
    +esMinimal(): boolean
    -min(int h): int
    -rotacionSimpleIzquierda(NodoAVL nodo)
    -rotacionSimpleDerecha (NodoAVL nodo)
    -rotacionDobleIzqquierda(NodoAVL nodo)
    -rotacionDobleDerecha (NodoAVL nodo)
    ------------------------------------
*/
//esto para evitar warnings porque Comparable es un tipo Generico y
//recomienda indicar Comparable<tipo>
@SuppressWarnings("unchecked")
public class ArbolAVL {
    protected NodoAVL raiz;
   
    //constructor
    public ArbolAVL(){
        this.raiz = null;
    }

   
    //busca al dato indicado y devuelve verdadero o false segun lo haya encontrado o no
    //EXACTAMENTE IGUAL que el ArbolBinarioDeBusqueda... lo podria pasar a una clase abstracta que lo implemente
    public boolean incluye(Comparable dato) {
        NodoAVL aux = this.raiz;
        boolean encontre = false;
        int comp;
        //mientras tenga donde buscar y no lo haya encontrado
        while(aux!=null && !encontre) {
            //compara
            
        	comp = dato.compareTo((Comparable) aux.getDato());
            if(comp==0) {        //si es igual, lo encontr�
                encontre = true;
            } else if(comp<0) {    //si es menor busca por la izquierda
                aux = aux.getHijoIzquierdo();
            } else {            //sino, por la derecha
                aux = aux.getHijoDerecho();
            }           
        }
        return encontre;
    }

   
    //agrega al dato indicado en la posici�n que le corresponda
    public void agregar(Comparable dato) {
        //crea al nodo
        NodoAVL nuevoNodo = new NodoAVL(dato);
        if(this.raiz==null) {    //si es un arbol nulo lo toma como raiz
            this.raiz = nuevoNodo;
        } else {                //sino busca donde ubicarlo
            NodoAVL aux = this.raiz;
            NodoAVL padre;
            Pila padres = new Pila(); //apilo a todos los nodos del camino que recorra para revisarlos despues
            int comp;
            //mientras tenga donde buscar, busca, apilando cada uno por el que pasa
            do {
                padres.push(aux);
                //compara para ver en que subarbol lo debe agregar
                comp = dato.compareTo((Comparable) aux.getDato());
                if(comp<=0) {        //si es menor o igual, lo pone por la izquierda
                    aux = aux.getHijoIzquierdo();
                } else {            //sino, por la derecha
                    aux = aux.getHijoDerecho();
                }           
            } while(aux!=null);
            //lo agrega en el subarbol que corresponda segun por donde encontro al null           
            padre = (NodoAVL) padres.pop();
            //System.out.println("Para agregar a " + dato + " el padre es: " + padre.getDato());
            if(comp<=0) {
                padre.setHijoIzquierdo(nuevoNodo);
            } else {
                padre.setHijoDerecho(nuevoNodo);
            }           
            //corrige a los nodos del camino que sigui�, hasta que alguno quede
            //con la misma altura que tenia
            int HIh, HDh, Ph;
            boolean corregido = false;
            do {
                //obtengo todas las alturas. Un arbol nulo tiene altura -1.
                HDh = this.alturaNodo(padre.getHijoDerecho());
                HIh = this.alturaNodo(padre.getHijoIzquierdo());
                Ph = padre.getAltura();
                //recalculo la altura, como la altura maxima entre sus subarboles, + 1
                padre.setAltura(Math.max(HIh, HDh)+1);
                if(Math.abs(HIh-HDh)>1) { //si hay que balancear
                    //comparo al padre con el dato agregado para ver que subarbol modific�
                    comp = dato.compareTo((Comparable) padre.getDato());               
                    if(comp<=0) {    //modific� subarbol IZQUIERDO
                        HDh = this.alturaNodo(padre.getHijoIzquierdo().getHijoDerecho());
                        HIh = this.alturaNodo(padre.getHijoIzquierdo().getHijoIzquierdo());
                        if(HIh>HDh) { //si el HI es mas alto... RII
                            this.rotacionSimpleIzquierda(padre);
                        } else {
                            this.rotacionDobleIzquierda(padre);
                        }
                    } else {        //modific� el subarbol DERECHO
                        HDh = this.alturaNodo(padre.getHijoDerecho().getHijoDerecho());
                        HIh = this.alturaNodo(padre.getHijoDerecho().getHijoIzquierdo());                       
                        if(HDh>HIh) { 
                            this.rotacionSimpleDerecha(padre);
                        } else {
                            this.rotacionDobleDerecha(padre);
                        }                           
                    }
                } else if(padre.getAltura()==Ph) {
                    //si la altura de alguno no se modific�,
                    //y no tuvo que balancearlo, de ah� para arriba quedan iguales
                    corregido = true;
                }
                padre = (NodoAVL) padres.pop(); //nodo anterior en el camino
            } while(padre!=null && !corregido);
        }
    }

    //*********************************************************************************************************
    //elimina al dato indicado si es que est� en el arbol
    //reemplazandolo por su hijo �nico, o por el m�s derecho de
    //su subarbol izquierdo (el mayor de los menores)
    //*********************************************************************************************************   
    public void eliminar(Comparable dato) {
        NodoAVL aux = this.raiz;
        Pila padres = new Pila(); //apilo a todos los nodos del camino que recorra para revisarlos despues
        NodoAVL padre = null;
        boolean encontre = false;
        int comp=0;
        //mientras tenga donde buscar y no lo haya encontrado
        while(aux!=null && !encontre) {
            //compara
            comp = dato.compareTo((Comparable) aux.getDato());
            if(comp==0) {        //si es igual, lo encontr�
                encontre = true;
            } else {
                padres.push(aux);
                if(comp<0) {    //si es menor busca por la izquierda
                    aux = aux.getHijoIzquierdo();
                } else {            //sino, por la derecha
                    aux = aux.getHijoDerecho();
                }
            }
        }
        //System.out.println("quiero eliminar a " + dato + " me quede con aux=" + aux + " y padre=" + padre);
        //si lo encontro lo elimina (va a estar en aux)
        if(encontre) {           
            if(aux.getHijoIzquierdo()==null) {
                padre = (NodoAVL) padres.pop();
                if(padre!=null) {
                    //si no tiene HI, lo reemplazo por su HD
                    if(padre.getHijoIzquierdo()==aux) {
                        padre.setHijoIzquierdo(aux.getHijoDerecho());
                    } else {
                        padre.setHijoDerecho(aux.getHijoDerecho());
                    }
                } else {
                    this.raiz = null;
                }
            } else {
                if(aux.getHijoDerecho()==null) {
                    padre = (NodoAVL) padres.pop();
                    if(padre!=null) {
                        //si no tiene HD, lo reemplazo por su HI
                        if(padre.getHijoIzquierdo()==aux) {
                            padre.setHijoIzquierdo(aux.getHijoIzquierdo());
                        } else {
                            padre.setHijoDerecho(aux.getHijoIzquierdo());
                        }
                    } else {
                        this.raiz = null;
                    }
                } else {
                    //lo reemplazo por el mas derecho de su subarbol izquierdo
                    //como el recorrido sigue, apila a aux en padres
                    padres.push(aux);
                    NodoAVL reemplazante = aux.getHijoIzquierdo(); //del sub arbol izquierdo...                   
                    //mientras pueda buscar por la derecha...
                    while(reemplazante.getHijoDerecho()!=null) {
                        padres.push(reemplazante);
                        reemplazante = reemplazante.getHijoDerecho();
                    }
                    //lo reemplaza
                    aux.setDato(reemplazante.getDato());
                    //desreferencia al nodo del reemplazante
                    //si baj� por la derecha del subarbol izq, reemplaza al hijo derecho del padre
                    //si no pudo bajar y solo mira al hijo izquierdo, lo reemplaza
                    padre = (NodoAVL) padres.pop();
                    if(padre==aux) {
                        aux.setHijoIzquierdo(reemplazante.getHijoDerecho());
                    } else {
                        padre.setHijoDerecho(reemplazante.getHijoIzquierdo());
                    }
                }
            }
            //corrige a los nodos del camino que sigui�, hasta que alguno quede
            //con la misma altura que tenia
            int HIh, HDh, Ph;
            boolean corregido = false;
            do {
                //obtengo todas las alturas. Un arbol nulo tiene altura -1.
                HDh = this.alturaNodo(padre.getHijoDerecho());
                HIh = this.alturaNodo(padre.getHijoIzquierdo());
                Ph = padre.getAltura();
                //recalculo la altura, como la altura maxima entre sus subarboles, + 1
                padre.setAltura(Math.max(HIh, HDh)+1);
                if(Math.abs(HIh-HDh)>1) { //si hay que balancear
                    //comparo al padre con el dato eliminado para ver que subarbol modific�
                    //El nodo que se quiso eliminar esta en el recorrido
                    //porque solo se le modific� el dato. En ese caso, se modific� su subarbol izquierdo
                    //no el derecho como pensar�a por la comparaci�n
                    comp = dato.compareTo((Comparable) padre.getDato());               
                    if((comp<=0) || (padre==aux)) {    //elimin� del subarbol izq, CRECIO EL DERECHO
                        HDh = this.alturaNodo(padre.getHijoDerecho().getHijoDerecho());
                        HIh = this.alturaNodo(padre.getHijoDerecho().getHijoIzquierdo());
                        if(HDh>HIh) { 
                            this.rotacionSimpleDerecha(padre);
                        } else {
                            this.rotacionDobleDerecha(padre);
                        }                           
                    } else {                        //elimino del subarbol der., CRECIO EL IZQUIERDO
                        HDh = this.alturaNodo(padre.getHijoIzquierdo().getHijoDerecho());
                        HIh = this.alturaNodo(padre.getHijoIzquierdo().getHijoIzquierdo());
                        if(HIh>HDh) { //si el HI es mas alto... RII
                            this.rotacionSimpleIzquierda(padre);
                        } else {
                            this.rotacionDobleIzquierda(padre);
                        }                       
                    }
                } else if(padre.getAltura()==Ph) {
                    //si la altura de alguno no se modific�, y est� balanceado
                    //de ah� para arriba quedan iguales
                    corregido = true;
                }
                padre = (NodoAVL) padres.pop(); //nodo anterior en el camino
            } while(padre!=null && !corregido);
        }//if(encontre)
    }//eliminar

    //devuelve la altura del nodo, o -1 si es nulo
    private int alturaNodo(NodoAVL unNodo) {
        if(unNodo==null) {
            return -1;
        } else {
            return unNodo.getAltura();
        }
    }

    //recalcula la altura del nodo, como la altura mas grande de sus hijos + 1
    private void recalcularAltura(NodoAVL nodo) {       
        int HIh, HDh;
        //obtengo todas las alturas. Un arbol nulo tiene altura -1.
        if(nodo.getHijoDerecho()==null) HDh=-1; else HDh = nodo.getHijoDerecho().getAltura();
        if(nodo.getHijoIzquierdo()==null) HIh=-1; else HIh = nodo.getHijoIzquierdo().getAltura();
        nodo.setAltura(Math.max(HIh, HDh)+1);       
    }
   
    //intercambia los datos contenidos en dos nodos AVL
    private void intercambiarDatos(NodoAVL unNodo, NodoAVL otroNodo) {
        Comparable data = unNodo.getDato();
        unNodo.setDato(otroNodo.getDato());
        otroNodo.setDato(data);
    }
    /*         (3)                    2
     *       2    .     =>          1   3
     *     1   ..                      ..  .    */
    private void rotacionSimpleIzquierda(NodoAVL nodo) {
        NodoAVL HI = nodo.getHijoIzquierdo();            //ref 2
        nodo.setHijoIzquierdo(HI.getHijoIzquierdo());    //3 HI 1
        HI.setHijoIzquierdo(HI.getHijoDerecho());        //2 HI ..
        HI.setHijoDerecho(nodo.getHijoDerecho());        //2 HD .
        nodo.setHijoDerecho(HI);                        //3 HD 2
        this.intercambiarDatos(nodo,HI);                //intercambio dato entre 3 y 2
        this.recalcularAltura(HI);
        this.recalcularAltura(nodo);
        //System.out.println("RII de " + nodo.getDato());
    }
    /*     (1)                        2
     *    .  2          =>          1   3
     *    ..   3                  .  ..       */   
    private void rotacionSimpleDerecha (NodoAVL nodo) {
        NodoAVL HD = nodo.getHijoDerecho();            //ref 2
        nodo.setHijoDerecho(HD.getHijoDerecho());    //1 HD 3
        HD.setHijoDerecho(HD.getHijoIzquierdo());        //2 HD ..
        HD.setHijoIzquierdo(nodo.getHijoIzquierdo());    //2 HI .
        nodo.setHijoIzquierdo(HD);                        //1 HI 2
        this.intercambiarDatos(nodo,HD);                //intercambio dato entre 1 y 2
        this.recalcularAltura(HD);
        this.recalcularAltura(nodo);
        //System.out.println("RDD de " + nodo.getDato());
    }
    /*          (A)                    (C)
     *       B       1     =>       B       A
     *     2   C                  2   3   4   1
     *        3 4
     */   
    private void rotacionDobleIzquierda(NodoAVL nodo) {
        NodoAVL HI = nodo.getHijoIzquierdo();    //ref a B
        NodoAVL HID = HI.getHijoDerecho();        //ref a C
        HI.setHijoDerecho(HID.getHijoIzquierdo());    //B HD 3
        HID.setHijoIzquierdo(HID.getHijoDerecho());    //C HI 4
        HID.setHijoDerecho(nodo.getHijoDerecho());    //C HD 1
        nodo.setHijoDerecho(HID);                    //A HD C
        this.intercambiarDatos(nodo, HID);            //intercambio datos entre A y C
        this.recalcularAltura(HI);
        this.recalcularAltura(HID);
        this.recalcularAltura(nodo);
        //System.out.println("RID de " + nodo.getDato());
    }
    /*          (A)                    (C)
     *       1       B     =>       A       B
     *            C    2          1  3    4   2
     *           3 4
     */   
    private void rotacionDobleDerecha (NodoAVL nodo){   
        NodoAVL HD = nodo.getHijoDerecho();        //ref a B
        NodoAVL HDI = HD.getHijoIzquierdo();    //ref a C
        HD.setHijoIzquierdo(HDI.getHijoDerecho());        //B HI 4
        HDI.setHijoDerecho(HDI.getHijoIzquierdo());        //C HD 3
        HDI.setHijoIzquierdo(nodo.getHijoIzquierdo());    //C HI 1
        nodo.setHijoIzquierdo(HDI);                        //A HI C
        this.intercambiarDatos(nodo, HDI);                //intercambio datos entre A y C
        this.recalcularAltura(HD);
        this.recalcularAltura(HDI);
        this.recalcularAltura(nodo);
        //System.out.println("RDI de " + nodo.getDato());
    }
   
    //cadena multilinea con recorrido en niveles del arbol
    public String toString() {
        if(this.raiz==null) return "(vac�o)";
        StringBuffer buff = new StringBuffer();       
        Cola c = new Cola();
        c.push(this.raiz);    //el mismo arbol
        c.push(null);        //marca de fin de nivel
        Object elem;
        NodoAVL aux, HI, HD;
        while(!c.isEmpty()) {
            elem = c.pop();           
            if(elem==null) {        //termin� un nivel
                if(!c.isEmpty()) {
                    buff.append("\n");
                    c.push(elem);    //paso la marca al final si queda algo
                }
            } else {
                if(elem instanceof String) {
                    buff.append(elem);                   
                } else {
                    aux = (NodoAVL) elem;
                    buff.append(aux.toString().replace(" ", "_"));
                    int HIh, HDh;
                    if(aux.getHijoDerecho()==null)    HDh=-1; else HDh = aux.getHijoDerecho().getAltura();
                    if(aux.getHijoIzquierdo()==null) HIh=-1; else HIh = aux.getHijoIzquierdo().getAltura();
                    buff.append("(" + Math.abs(HDh-HIh) + ")");
                    HI = aux.getHijoIzquierdo();
                    HD = aux.getHijoDerecho();
                    if(HI!=null) c.push(HI); else c.push(".");
                    if(HD!=null) c.push(HD); else c.push(".");
                }
                buff.append(" ");
            }
        }
        return buff.toString();
    }
   
    //devuelve la cantidad de nodos en el arbol 
    public int cantidad() {
        if(this.raiz==null) return 0;
        int cant = 0;       
        Cola c = new Cola();
        c.push(this.raiz);    //el mismo arbol
        c.push(null);         //marca de fin de nivel
        NodoAVL aux, HI, HD;
        while(!c.isEmpty()) {
            aux = (NodoAVL) c.pop();           
            if(aux==null) {        //termin� un nivel
                if(!c.isEmpty()) {
                    c.push(aux);    //paso la marca al final si queda algo
                }
            } else {
            	cant++; //lo cuento a el
	            HI = aux.getHijoIzquierdo();
	            HD = aux.getHijoDerecho();
	            if(HI!=null) c.push(HI);
	            if(HD!=null) c.push(HD);
            }
        }
        return cant;
    }
    //devuelve la altura del arbol
    public int altura() {
    	if(this.raiz==null) {
    		return -1;
    	} else {
    		return this.raiz.altura;
    	}
    }
    //devuelve la cantidad minima de nodos en un arbol de altura h
    //min(h) es
    //	1 si h==0
    //  2 si h==1
    //  1+min(h-1)+min(h-2) si h>1
    private int min(int h) {
    	if(h==0) {
    		return 1;
    	} else if(h==1) {
    		return 2;
    	} else {
    		int ant2 = 1;
    		int ant1 = 2;    		
    		int minima = 0;
    		for(int j = 2; j<=h; j++) {
    			minima = ant1 + ant2 + 1;
    			ant2 = ant1;
    			ant1 = minima;    			
    		}
    		return minima;
    	}
    }
    //devuelve true si el arbol es minimal, o sea si la cantidad de nodos
    //que posee es la minima para su altura
    public boolean esMinimal() {
    	return (this.cantidad()==this.min(this.altura()));
    }    
    
    //modificacion para poder crear el DICCIONARIO -pract 6 ej 8
    public Comparable recuperar(Comparable dato) {
        NodoAVL aux = this.raiz;
        boolean encontre = false;
        int comp;
        //mientras tenga donde buscar y no lo haya encontrado
        while(aux!=null && !encontre) {
            //compara
            comp = dato.compareTo((Comparable) aux.getDato());
            if(comp==0) {        //si es igual, lo encontr�
                encontre = true;
            } else if(comp<0) {    //si es menor busca por la izquierda
                aux = aux.getHijoIzquierdo();
            } else {            //sino, por la derecha
                aux = aux.getHijoDerecho();
            }           
        }
        if(encontre) {
        	return aux.getDato();
        } else {
        	return null;
        }
    }
    
    public Cola getNodosInOrden() {
    	Cola nodos = new Cola();
        if(this.raiz==null) return nodos;
        Pila p = new Pila();
        p.push(this.raiz);    //el mismo arbol
        Object elem;
        NodoAVL aux, HI, HD;        
        while(!p.isEmpty()) {
        	elem = p.pop();        	
            if(elem instanceof NodoAVL) {	//toma un nodo
            	aux = (NodoAVL) elem;
                HI = aux.getHijoIzquierdo();
                HD = aux.getHijoDerecho();
                if(HD!=null) p.push(HD);	//HD
                p.push(aux.getDato());		//procesara al dato
                if(HI!=null) p.push(HI);	//HI
            } else {						//cuando llego a un dato
            	nodos.push(elem);	//pre orden
            }
        }
        return nodos;
    }
}