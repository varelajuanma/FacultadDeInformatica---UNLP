package Heap;

import arboles.Lista;

@SuppressWarnings("unchecked")
public class Heap {
	protected final int TAM_DEFAULT = 257; //8 niveles mas posicion 0
	protected Comparable[] datos;
	int cantElementos;
	
	//constructores
	//construye heap vacia, con tama�o por defecto
	public Heap() {
		this.datos = new Comparable[TAM_DEFAULT];
		cantElementos = 0;
	}
	//construye heap a partir de elementos de la lista
	/* T(N) = cte + N * Log(N)
	 * 		= tama�o y creacion array + para cada N * agregar   (agregar: logN)
	 * T(N) = O(N log(N))
	 * 
	 * i) si datos[] esta ordenado de < a >
	 * 		T(N) = cte + N * cte   (el percolate entra solo 1 vez a la iteracion)
	 * 		T(N) = O(N)
	 * ii) si datos[] esta ordenado de > a <. Este seria el pero caso
	 * 		porque cada percolate down tendria que hacer todos los cambios
	 * 		posibles. PEOR      LOS CASOS: T(N) = O(N log(N))
	 */
	public Heap(Lista L) {
		int tam = L.size();
		if(L.size()<TAM_DEFAULT) tam = TAM_DEFAULT;
		this.datos = new Comparable[tam+1];
		L.begin();
		while(!L.end()) {
			this.agregar((Comparable) L.get());
			L.next();
		}
	}
	//toma los datos[] tal y como estasn, y los ordena -percolate down-
	//desde el penultimo nivel (pos N/2) filtrando hacia abajo para formar
	//sucesivas heaps mas peque�as y juntandolas luego a medida q recorre los nodos
	/* T(N) = cte + N + N/2 * Log(N)
	 * 		= def + copia + percolate de N/2 elementos
	 * T(N) = O(N log(N))	PEOR DE LOS CASOS -segun carpeta-
	 *  
	 * i) si datos[] esta ordenado de < a >
	 * 		T(N) = cte + N + N/2 * cte	(el percolate solo entra una vez 
	 * 									en la iteracion, ya esta ordenado)
	 * 		T(N) = O(N)
	 * ii) si datos[] esta ordenado de > a <. Este seria el pero caso
	 * 		porque cada percolate down tendria que hacer todos los cambios
	 * 		posibles. PEOR      LOS CASOS: T(N) = O(N log(N))
	 * */
	public Heap(Comparable[] datos) {		
		cantElementos = datos.length; //van a tener igual cantidad de elementos
		this.datos = new Comparable[cantElementos + 1]; //pido uno mas de espacio porque empieza de 0
		//copio los datos salteando la posicion 0 de this.datos[]
		int i = 0;
		for(i=0; i<cantElementos; i++) {
			this.datos[i+1] = datos[i];
		}
		//creo las min heaps mas chicas y las voy uniendo
		for(i=cantElementos/2 ; i>0; i--) {
			this.percolateDown(i);
		}
	}
	//devuelve true/false segun la heap este o no vacia
	public boolean esVacia() {
		return (this.tamanio()==0);
	}
	//agrega el dato comparable a la heap en donde corresponda
	public void agregar(Comparable dato) {
		if(datos.length>cantElementos+1) {
			cantElementos++;			
			this.datos[cantElementos] = dato;	//inserta manteniendo estructura
			this.percolateUp(cantElementos);	//burbujea hasta dejarlo ordenado
		} else {
			System.out.println("ERROR: HEAP LLENA");
		}
	}
	//devuelve el tamanio de la heap
	public int tamanio() {
		return cantElementos;
	}
	//devuelve el valor en el tope de la cola de prioridad
	//-raiz del arbol- quitandolo de la heap
	public Comparable tope() {
		Comparable resultado = null;
		if(this.tamanio()>0) {
			resultado = this.datos[1]; //se devolvera la raiz del arbol
			this.datos[1] = this.datos[cantElementos];	//reemplazo por el ultimo		
			cantElementos--;			//achicando a heap
			this.percolateDown(1);		//burbujeo/filtro hacia abajo para ordenarlo
		}
		return resultado;
	}
	
	//hace un burbujeo o filtrado hacia arriba al nodo de la posicion indicada
	//comparando con su padre (en posicion/2) e intercambiando si es menor
	//itera hasta que no intercambie
	private void percolateUp(int posicion) {		
		Comparable dato = this.datos[posicion];
		this.datos[0] = dato;	//para cortar el while
								//sino tendria q poner tambien padre>0
		int padre = posicion /2;
		while(this.datos[padre].compareTo(dato)>0) {
			this.datos[posicion] = this.datos[padre];
			posicion = padre;
			padre = posicion /2;
		}
		this.datos[posicion] = dato;
	}
	//hace un burbujeo o filtrado hacia abajo al nodo de la posicion indicada
	//comparando con sus hijos (en posicion*2 y posicion*2 +1) e intercambiando
	//con el menor de ellos. Itera hasta que no intercambie o no haya hijos para comparar
	private void percolateDown(int posicion) {
		Comparable dato = this.datos[posicion];
		int hMenor = 0;
		boolean encontreMiPosicion = false;
		//mientras tenga HI y no sepa donde ubicarse
		while(posicion*2<=cantElementos && !encontreMiPosicion) {
			//elige el menor de sus hijos, si tiene los dos. sino, se queda con el HI
			hMenor = posicion*2; //HI
			if (hMenor+1<=cantElementos) { //Si hay HD lo comparo con el HI
				if(this.datos[hMenor+1].compareTo(this.datos[hMenor])<=0) {
					hMenor++;	//HD<HI (el HI estaba en pos*2, y el HD en pos*2+1)
				}
			}
			//si es menor al dato, se asciende al hijo
			if(this.datos[hMenor].compareTo(dato) < 0) {
				this.datos[posicion] = this.datos[hMenor];
				posicion = hMenor;
			} else {
				encontreMiPosicion = true;
			}
		}
		//pone al dato en su ubicacion final
		this.datos[posicion] = dato;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer("[ ");
		for(int pos = 1; pos <= this.tamanio(); pos++) {
			sb.append(this.datos[pos]);
			sb.append(" ");
		}
		sb.append("]");
		return sb.toString();
	}
}
