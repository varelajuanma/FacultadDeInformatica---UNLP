package Heap;

import arboles.Lista;

@SuppressWarnings("unchecked")
public class TestHeap {
	public static void main(String[] args) {
		System.out.println("*** Prueba de los constructores ***");
		Heap H = new Heap();
		H.agregar(20);	//20
		H.agregar(9); 	//9 20
		H.agregar(15);	//9 20 15
		H.agregar(17);	//9 17 15 20
		H.agregar(7);	//7 9  15 20 17		
		H.agregar(8);	//7 9  8  20 17 15
		System.out.println("Tama�o de la Heap: " + H.tamanio() + "  " + H);

		Lista L = new Lista();
		L.add(8);
		L.add(7);
		L.add(17);
		L.add(15);
		L.add(9);
		L.add(20);		
		H = new Heap(L);
		System.out.println("Tama�o de la Heap: " + H.tamanio() + "  " + H);

		Comparable[] miArray = {20, 9, 15, 17, 7, 8};
		H = new Heap(miArray);
		System.out.println("Tama�o de la Heap: " + H.tamanio() + "  " + H);
		
		
		System.out.println("*** Prueba de los lectura ***");
		while(!H.esVacia()) {
			System.out.println("Leo:" + H.tope() + "\tQuedan: " + H.tamanio() + "  " + H);
		}
		
		//prueba hecha en carpeta
		System.out.println("*** Prueba hecha en carpeta ***");
		H.agregar(2);
		H.agregar(4);
		H.agregar(7);
		H.agregar(1);
		H.agregar(10);		
		H.agregar(5); //1 2 5 4 10 7
		System.out.println("Tama�o de la Heap: " + H.tamanio() + "  " + H);
		System.out.println("Leo:" + H.tope() + "\tQuedan: " + H.tamanio() + "  " + H);
		System.out.println("Leo:" + H.tope() + "\tQuedan: " + H.tamanio() + "  " + H);

		
	}

}
