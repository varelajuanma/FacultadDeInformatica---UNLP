package Empresa;

import arboles.ArbolGeneral;
import arboles.Cola;
import arboles.Lista;
import arboles.Pila;


public class Empresa {
	protected ArbolGeneral raiz = null;
	
	//constructor, recibe un empleado y lo hace presidente
	public Empresa(Empleado unPresidente) {
		this.raiz = new ArbolGeneral(unPresidente);
	}
	
	//imprime el �rbol jerarquico de la empresa
	public String toString() {
		return (raiz==null) ? "null" : raiz.toString();
	}
	
	//devuelve al presidente de la empresa
	public Empleado getPresidente() {
		return (raiz==null) ? null : (Empleado) raiz.getDatoRaiz();
	}
	
	//devuelve el empleado a partir del nombre -String-
	public Empleado getEmpleado(String elNombre) {
		ArbolGeneral elEmpleado = raiz.subarbol(elNombre);
		if(elEmpleado==null) {
			return null;
		} else {
			return (Empleado) elEmpleado.getDatoRaiz();
		}
	}
	
	//agrega al subordinado debajo del jefe devolviendo true/false segun lo logre o no
	//NO CONTROLA CICLOS NI UNICIDAD DEL EMPLEADO EN EL ARBOL
	public Empleado agregarSubordinado(Empleado jefe, Empleado subordinado) {
		//obtengo
		ArbolGeneral elJefe = raiz.subarbol(jefe);
		if(elJefe==null) {
			return null;
		} else {
			elJefe.agregarHijo(new ArbolGeneral(subordinado));
			return subordinado;
		}
	}
	
	//devuelve una lista con la cantidad de trabajadores en cada categor�a -nivel del arbol-
	//se hace un recorrido por niveles utilizando una cola auxiliar y se cuentan nodos por nivel
	public Lista trabajadoresPorCategoria() {
		Lista lis = new Lista();
		if(raiz!=null) {
			Pila cantidades = new Pila();
	
			Cola c = new Cola();
			c.push(raiz);	//encolo al presidente que es �nico en su categor�a
			c.push(null);	//marca de fin de categor�a
			int cantidad = 0;
			Lista subordinados;
			ArbolGeneral arbol;
			while(!c.isEmpty()) {
				arbol = (ArbolGeneral) c.pop();
				if(arbol==null) {
					//pongo en la lista la cantidad de empleados de esa categor�a
					cantidades.push(cantidad);
					cantidad = 0;
					//vuelvo a encolar la marca de fin de categ
					if (!c.isEmpty()) c.push(arbol);
				} else {
					//cuento al empleado encolo a sus subordinados
					cantidad++;
					subordinados = arbol.getHijos();
					subordinados.begin();
					while(!subordinados.end()) {
						c.push(subordinados.get());
						subordinados.next();
					}
				}
			}
			//paso de la cola a la lista
			while(!cantidades.isEmpty()) lis.add(cantidades.pop());
		}
		return lis;
	}
	
	//Devuelve un String indicando la categor�a con mayor cantidad de empleados
	public String categoriaConMasTrabajadores() {
		Lista lis = this.trabajadoresPorCategoria();
		int max = -1, categMax = 0, cant, i = 1;
		lis.begin();
		while(!lis.end()) {
			cant = (Integer) lis.get();
			if(cant>max) {
				max = cant;
				categMax = i;
			}
			lis.next();
			i++;
		}
		return "Categor�a " + categMax;
	}

	//devuelve la cantidad total de trabajadores en la empresa, sumando los de todos los niveles
	public int cantidadTotalDeTrabajadores() {
		Lista lis = this.trabajadoresPorCategoria();
		int tot = 0;
		lis.begin();
		while(!lis.end()) {
			tot += (Integer) lis.get();
			lis.next();
		}
		return tot;
	}
	
	//si el presidente deja su funciones, se lo reemplaza por el mas antiguo de sus hijos
	//con quien se aplica el mismo criterio hasta hasta llegar a un ascendido que no tenga	
	//personal a cargo
	public Empleado reemplazarPresidente() {
		ArbolGeneral arbol = raiz, maxSubordinado = null, subordinado = null;
		Empleado max;
		Lista lis;
		//parto desde la ra�z -el presidente-
		//pido la lista de sus hijos -lista de otros arboles-.
		lis = arbol.getHijos();
		//voy a procesar hijos bajando por los niveles hasta llegar a una hoja
		//(que la lista de hijos sea vac�a)
		while(!lis.isEmpty()) {		
				//si tiene hijos, busco al m�s antiguo
				max = null;
				lis.begin();
				while(!lis.end()) {
					subordinado = (ArbolGeneral) lis.get();
					if(max==null || ((Empleado) subordinado.getDatoRaiz()).getAntiguedad() > max.getAntiguedad()) {
						//me quedo con el arbol y con el empleado de su ra�z
						//(guardo el arbol para seguir con la lista de sus hijos despu�s)
						maxSubordinado = subordinado;
						max = (Empleado) maxSubordinado.getDatoRaiz();
					}
					lis.next();
				}
				//ASCENSO DEL SUBORDINADO
				//paso el maximo al dato del padre que deja su funci�n
				((Empleado) arbol.getDatoRaiz()).setAntiguedad(max.getAntiguedad());
				((Empleado) arbol.getDatoRaiz()).setNombre(max.getNombre());
				//AHORA PARA PROCESAR AL ARBOL DEL SUBORDINADO
				//TOMO SUS HIJOS PARA BUSCAR SU PROPIO REEMPLAZANTE				
				lis = maxSubordinado.getHijos();
				if(!lis.isEmpty()) arbol = maxSubordinado;
		}
		//cuando encuentro un arbol sin hijos -nodo hoja, empleado sin subordinados-
		//lo elimino (a lo sumo, ya se habr� copiado arriba porque ascendi�)
		//si no hay ninguno se porque solo estaba el presidente. lo borro.
		if(maxSubordinado==null) {
			this.raiz=null;
		} else {
			arbol.eliminarHijo(maxSubordinado);
		}
		return this.getPresidente();
	}
	
}