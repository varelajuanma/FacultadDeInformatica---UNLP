package Empresa;

//la categor�a es el nivel q ocupa en el arbol
//cada empleado est� en el dato de un nodo
public class Empleado {
	protected String nombre;
	protected int antiguedad;
	
	//constructor
	public Empleado(String nombre, int antiguedad) {
		this.setNombre(nombre);
		this.setAntiguedad(antiguedad);
	}
	
	//getters y setters
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public int getAntiguedad() {
		return antiguedad;
	}
	public void setAntiguedad(int antiguedad) {
		this.antiguedad = antiguedad;
	}	
	
	//si se compara contra un String, controla contra su nombre
	public boolean equals(Object otroEmpleado) {
		if(otroEmpleado instanceof String) {
			return this.getNombre().equals(otroEmpleado);
		} else {
			return super.equals(otroEmpleado);
		}
	}
	public String toString() {
		return this.getNombre().toUpperCase();
	}
}
