package Empresa;

import arboles.Lista;

public class TestEmpresa {
	private static void verEmpleadosPorCateg(Empresa miEmp) {
		System.out.println("Trabajadores por Categor�a");
		Lista lis = miEmp.trabajadoresPorCategoria();
		if(lis.isEmpty()) {
			System.out.println("No hay trabajadores!!!");
		} else {
			int i = 1;
			lis.begin();
			while(!lis.end()) {
				System.out.println("Categ. " + i + ": " + (Integer) lis.get() + " trabajador/es.");
				lis.next();
				i++;
			}		
		}
	}
	
	public static void main(String[] args) {
		//creo la empresa con el omnipresente y todopoderoso presidente Sr.YO, 10 a�os de antig.
		Empresa  miEmp   = new Empresa(new Empleado("Capalbo Lucas PRESIDENTE",10));
		Empleado jefe    = miEmp.getEmpleado("Capalbo Lucas PRESIDENTE");
		Empleado subjefe = miEmp.agregarSubordinado(jefe, new Empleado("Perez Mar�a SUBPRESIDENTE", 9));
		
		Empleado ger = miEmp.agregarSubordinado(subjefe, new Empleado("Cabrera Jorge Luis GERENTE", 8));
		miEmp.agregarSubordinado(ger, new Empleado("Petinatto Roberto", 8));
		miEmp.agregarSubordinado(ger, new Empleado("Pielvitori Mart�n", 9));
		miEmp.agregarSubordinado(ger, new Empleado("Gonz�lez Susana", 4));
		
		ger = miEmp.agregarSubordinado(subjefe, new Empleado("Cort�s Luisa GERENTE", 5));
		miEmp.agregarSubordinado(ger, new Empleado("Dumont Ulises", 2));
		
		ger = miEmp.agregarSubordinado(subjefe, new Empleado("Panuncio Juan Pablo GERENTE", 8));
		miEmp.agregarSubordinado(ger, new Empleado("Gramajo Enrique", 2));
		miEmp.agregarSubordinado(ger, new Empleado("Mu�oz Jos�", 1));
		
		System.out.println(miEmp);
		
		verEmpleadosPorCateg(miEmp);		
		System.out.println("Total de Trabajadores: " +	miEmp.cantidadTotalDeTrabajadores());
		System.out.println("Categor�a con m�s Trabajadores: " +	miEmp.categoriaConMasTrabajadores());
		System.out.println("Presidente actual: " + miEmp.getPresidente().toString());
		//reemplazo al presidente hasta que no quede nadie
		while(miEmp.reemplazarPresidente()!=null) {
			System.out.println("Presidente actual tras renuncia: " + jefe.toString());
			System.out.println(miEmp);
		}
		
		verEmpleadosPorCateg(miEmp);		
		System.out.println("Total de Trabajadores: " +	miEmp.cantidadTotalDeTrabajadores());
		System.out.println("Categor�a con m�s Trabajadores: " +	miEmp.categoriaConMasTrabajadores());		
	}

}
