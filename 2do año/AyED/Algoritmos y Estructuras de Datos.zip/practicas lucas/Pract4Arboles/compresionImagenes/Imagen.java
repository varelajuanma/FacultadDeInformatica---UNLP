package compresionImagenes;

import arboles.ArbolGeneral;
import arboles.Lista;

public class Imagen {
	protected boolean[][] imagen = null;
	protected int orden = 0;
		
	//CONSTRUCTORES
	public Imagen() {} //constructor simple
	public Imagen(boolean colorDefecto, int orden) {
		imagen = new boolean[orden][orden];
		for(boolean[] fila : imagen) //para cada fila de la imagen
			for(@SuppressWarnings("unused") boolean valor : fila)  //para cada valor de la fila
				valor = colorDefecto;		//inicializo al valor por defecto
		this.orden = orden;
	}	
	public Imagen(boolean[][] imagen) {
		this.setImagen(imagen);
	}
	/* crea la imagen como una sub-porci�n de la matriz origen
	 * tomando fils filas y cols columnas desde la posici�n (filOrig, colOrig) */
	public Imagen(boolean[][] origen, int orden, int filOrig, int colOrig) {
		//matriz origen y dimensi�n para la nueva matriz no nulas
		if(origen!=null && orden!=0) { 
			//si la sub-matriz a copiar no sale del rango de la matriz origen
			if ((orden+filOrig)<=origen.length && (orden+colOrig)<=origen[0].length) {
				imagen = new boolean[orden][orden];
				for(int f=0; f<orden; f++) //para cada fila de la imagen
					for(int c=0; c<orden; c++)  //para cada valor de la fila
						//copio en (f,c) el valor de (filOrig+f,colOrig+c)
						imagen[f][c] = origen[filOrig+f][colOrig+c];
				this.orden = orden;
			}
		}
	}
	//reconstruir la imagen
	public Imagen(ArbolGeneral imagenCompresa) {
		if(imagenCompresa!=null) {
			//el orden de la matriz ser� de 2^(altura del arbol)
			//un arbol altura 3, se tuvo que dividir 3 veces
			//cada vez por la mitad, as� que dar� una matriz de orden 2^3=8 
			int altu = imagenCompresa.altura();			
			this.orden = (int) Math.pow(2, altu);
			imagen = new boolean[orden][orden];
			//creado el espacio, descomprimo el �rbol desde (0,0) cubriendo el orden
			//entero de la matriz  (podria no paasr el orden porque le doy el arbol, pero
			//calcular su altura de nuevo seria mucho trabajo)
			this.Descomprimir(imagenCompresa,0,0, this.orden);
		}
	}
	protected void Descomprimir(ArbolGeneral imagenCompresa, int filOrig, int colOrig, int orden) {
			Lista hijos = imagenCompresa.getHijos();
			if(hijos.isEmpty()) {
				if(imagenCompresa.getDatoRaiz() instanceof Boolean) {
					Boolean valorDescompreso = (Boolean) imagenCompresa.getDatoRaiz();
					for(int f = 0; f<orden; f++)
						for(int c = 0; c<orden; c++)
							imagen[filOrig + f][colOrig + c] = valorDescompreso;
				} else {
					System.out.println(" ERROR AL DESCOMPRIMIR IM�GEN: \n" + imagenCompresa.getDatoRaiz() + " NO ES DEL TIPO ESPERADO.\n");
				}
			} else if(hijos.size()!=4) {
				System.out.println(" ERROR AL DESCOMPRIMIR IM�GEN: \nNO SE RECONOCE EL FORMATO (NO ES 4-ARIO).\n");
			} else {
				orden=orden/2;
				hijos.begin();
				this.Descomprimir((ArbolGeneral) hijos.get(),filOrig,colOrig, orden); //1er cuadrante
				hijos.next();
				this.Descomprimir((ArbolGeneral) hijos.get(),filOrig,colOrig+orden, orden);
				hijos.next();
				this.Descomprimir((ArbolGeneral) hijos.get(),filOrig+orden,colOrig, orden);
				hijos.next();
				this.Descomprimir((ArbolGeneral) hijos.get(),filOrig+orden,colOrig+orden, orden);
			}
	}
	
	//GETTERS Y SETTERS
	public void setImagen(boolean[][] imagen) {
		if(imagen!=null)
			if(imagen.length==imagen[0].length)	 {
				this.imagen = imagen;
				orden = imagen.length;		//orden de la matriz -filas y columnas son iguales-
			}
	}
	public boolean[][] getImagen() {
		return imagen;
	}	
	public int getOrden() {	//solo lectura
		return orden;
	}
	
	//M�TODOS ESPEC�FICOS DE LA CLASE
	/* Devuelve -2, -1, 0 o 1 seg�n la matriz no este inicializada, 
	 * sea de colores distintos, toda blanca o toda negra */
	protected int codigoColor() {
		if(imagen==null) {
			return -2; //no inicializada
		} else {
			//tomo el valor de la primer celda
			boolean valor = imagen[0][0];
			boolean iguales = true;
			//Recorro la matriz entera mientras los valores sean todos iguales
			//Si la termino de recorrer el codigo es 1/0 seg�n el valor sea verdadero/false 
			//Si no termino, devuelvo -1 (hay distintos valores)
			int f, c;
			for(f = 0; f<orden && iguales; f++) 
				for(c = 0; c<orden && iguales; c++)
					iguales = (valor==imagen[f][c]);
			return (iguales) ? ((valor)?1:0) : -1; //1,0 o -1: negra, blanca o distintos colores
		}
	}
	// Devuelve true/false seg�n sea toda de un mismo color o no
	public boolean igualColor() {
		return(this.codigoColor()>=0);
	}
	/* Devuelve true/false seg�n sea toda negra o toda blanca
	 * (si no es toda del mismo color, no tiene sentido y devuelve false -blanco-
	 * se podr�a lanzar una excepci�n en este caso) */
	public boolean color() {
		return(this.codigoColor()==1); //si es 1 es negra --> VERDADERO
	}
	/* Devuelve una lista con cuatro im�genes, una para cada cuadrante suyo
	 * si no puede dividirse en cuadrantes porque la imagen no es cuadrada
	 * ni f y c multiplo de dos devuelve null */
	public Lista dividirEnSubImagenes() {
		if(imagen==null || orden%2==1) {
			return null;
		} else {
			Lista lis = new Lista();			
			int newOrden = orden / 2;
			lis.add(new Imagen(this.imagen, newOrden, newOrden,newOrden));	//4to cuadrante
			lis.add(new Imagen(this.imagen, newOrden, newOrden,0));		//3er cuadrante
			lis.add(new Imagen(this.imagen, newOrden, 0,newOrden));		//2do cuadrante
			lis.add(new Imagen(this.imagen, newOrden, 0,0));				//1er cuadrante
			return lis;
		}
	}
	/* Devuelve la compresi�n de la im�gen en el �rbol 4-ario correspondiente.
	 * Si la im�gen no est� inicializada devuelve un arbo nulo -null-.
	 * Si es toda del mismo color, devuelve un �rbol de nodo �nico -raiz- con dicho color.
	 * Si la imagen no es uniforme, devuelve la ra�z indicando false -distinto color- con cuatro
	 * �rboles hijos, cada uno representando cada cuadrante de la im�gen */
	public ArbolGeneral imagenComprimida() {
		int color = this.codigoColor();
		if(color==-2) {
			return null;	//sin im�gen: im�gen no inicializada
		} else {			//sino creo el �rbol a devolver con la ra�z
			ArbolGeneral arbol = new ArbolGeneral(color==1); //V: negra; F:  blanca o distinta			
			//para hacerlo mas f�cil de ver:  pone 1 o 0 o -
			//ArbolGeneral arbol = new ArbolGeneral((color==-1) ? "---\\" : color); //V: negra; F:  blanca o distinta
			if(color==-1) { //si puso F en la ra�z porque eran distintos colores
				//obtengo las im�genes de los cuadrantes 
				Lista cuadrantes = this.dividirEnSubImagenes();
				//las recorro agregando su versi�n compresa como hijos del �rbol de compresi�n
				cuadrantes.begin();
				while(!cuadrantes.end()) {
					arbol.agregarHijo( ((Imagen) cuadrantes.get()).imagenComprimida() );
					cuadrantes.next();
				}
			}
			return arbol;
		}
	}
	/* Sobreescribe el toString para devolver.
	 * "IMAGEN NO INICIALIZADA" - si a�n no esta inicializada.
	 * "IMAGEN DE F x C ..." - con ... una representaci�n de la matriz*/
	public String toString() {
		if(imagen==null) {
			return "IMAGEN NO INICIALIZADA";
		} else {
			StringBuffer buff = new StringBuffer("IMAGEN DE " + this.getOrden() + " x " + this.getOrden() + "\n");
			for(boolean[] fila : this.imagen) {
				for(boolean valor : fila) {
					buff.append((valor) ? "1" : "0");
				}
				buff.append("\n");
			}			
			return buff.toString();
		}		
	}	
}
