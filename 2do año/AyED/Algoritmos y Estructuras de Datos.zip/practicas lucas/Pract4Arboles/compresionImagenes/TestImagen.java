package compresionImagenes;

import arboles.ArbolGeneral;

public class TestImagen {
	final static boolean T = true;
	final static boolean F = false;
	
	public static void main(String[] args) {
		//MATRIZ DEL EJEMPLO
		boolean[][] matriz = {
				{T,T,T,T,F,F,T,T},
				{T,T,T,T,F,F,T,T},
				{T,T,T,T,T,T,F,F},
				{T,T,T,T,F,T,F,F},
				{F,T,F,T,F,F,F,T},
				{T,F,T,F,F,F,T,F},
				{F,F,T,T,T,T,F,F},
				{F,F,T,T,T,T,F,F}
		};
		
		Imagen img = new Imagen(matriz);
		//en este caso se simplifica, lo que mantiene es
		//el patron no la imagen con su tama�o 
		//Imagen img = new Imagen(true,8);
		System.out.println(img);
		ArbolGeneral compri = img.imagenComprimida();
		System.out.println("�rbol de compresi�n:");
		System.out.println("  Altura: " + compri.altura());
		System.out.println("  Ancho: " + compri.ancho() );
		System.out.println(compri.toString());
		System.out.println();
		System.out.println("Generando una nueva im�gen descomprimiendo el �rbol:");
		Imagen img2 = new Imagen(compri);
		System.out.println(img2);
		ArbolGeneral compri2 = img2.imagenComprimida();
		System.out.println("Nueva compresi�n:  Altura: " + compri2.altura());
		System.out.println("                   Ancho: " + compri2.ancho() );
		System.out.println("                   Equiv. al anterior: " + compri.equals(compri2));
		
		boolean[][] matriz1 = {
				{T,T,T,T},
				{T,T,T,T},
				{T,T,F,F},
				{T,T,F,F}
		};
		
		Imagen imga1 = new Imagen(matriz1);
		System.out.println(imga1);
		ArbolGeneral compriIma1 = imga1.imagenComprimida();

		boolean[][] matriz2 = {
				{T,T},
				{T,F}
		};
		
		Imagen imga2 = new Imagen(matriz2);
		System.out.println(imga2);
		ArbolGeneral compriIma2 = imga2.imagenComprimida();
		System.out.println(compriIma1.equals(compriIma2));
	}
}