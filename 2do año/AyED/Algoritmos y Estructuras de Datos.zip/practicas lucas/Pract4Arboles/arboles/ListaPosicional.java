package arboles;

/*  EJERCICIO 5 PRACTICA 3 (b) - Lista posicional extiende lista no posicional
    Implementacion recursiva - Base 0  */

public class ListaPosicional extends Lista {
	//retorna el elemento de la posici�n pos
	public Object get(int pos) {
		NodoLista aux = null;
		if (isValid(pos)) {		
			aux = start;
			int i=0;		
			while (i<pos) {
				aux = aux.getNext();
				i++;
			}
		}
		return ((aux != null) ? aux.getDato() : null);
	}	

	//agrega el elemento elem en la posici�n pos, devolviendo true/false indicando el �xito
	public boolean add(Object elem, int pos) {
		if(isValid(pos) || pos == this.tamLista) {
			NodoLista nuevoNodo;
			nuevoNodo = new NodoLista(elem);
			//si se agrega al principio
			if(pos==0) {
				nuevoNodo.setNext(start);
				start = nuevoNodo;
			} else {
				//sino busco la posici�n, manteniendo el anterior para poder insertar
				NodoLista ante = start;
				int i = 1; //para quedarme con el anterior
				while (i<pos) {
					ante = ante.getNext();
					i++;
				}			
				nuevoNodo.setNext(ante.getNext());
				ante.setNext(nuevoNodo);
			}
			//cuento al nuevo elemento
			tamLista++;
			return true;
		} else {
			return false;
		}
	}
	
	//elimina elemento de posici�n pos
	public void remove(int pos) {
		if (isValid(pos)) {
			//si se borra al primero
			if(pos==0) {
				if ((currentPosition == start) && currentPosition!=null) currentPosition = currentPosition.getNext();
				start = start.getNext();				
			} else {
				//sino busco la posici�n, manteniendo el anterior para poder insertar
				NodoLista ante = start, nodoObjetivo = start.getNext();
				int i = 1;
				while (i<pos) {
					ante = nodoObjetivo;
					nodoObjetivo = nodoObjetivo.getNext();
					i++;
				}		
				//lo desreferencio
				ante.setNext( nodoObjetivo.getNext() );
				//corrijo currentPosition
				if (nodoObjetivo==currentPosition) {
					if (currentPosition.getNext()==null) { //es el �ltimo
						currentPosition = ante;
					} else {
						currentPosition = currentPosition.getNext();
					}	
				}				
			}
			//descuento el elemento.
			this.tamLista--;
		}
	}
}