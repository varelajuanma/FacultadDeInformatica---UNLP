package arboles;

//Lista en base al ejercicio Pract 3 Ej 5 (a)
//Implementaci�n recursiva

public class Lista {
	protected int tamLista;
	protected NodoLista start, currentPosition; //referencias
	
	//devuelve True o False seg�n la posici�n sea v�lida
	protected boolean isValid(int position) {
		return ((position>=0) && (position<tamLista));
	}
	
	//constructor -- no se indica void en la signature
	public Lista() {
		start = null;
		currentPosition = null;
		tamLista = 0;
	}

	//se prepara para recorrerla desde el comienzo
	public void begin() {
		currentPosition = start;
	}
	
	//avanza al pr�ximo elem de la lista
	public void next() {
		if (currentPosition != null) currentPosition = currentPosition.getNext();
	}
	
	//determina si lleg� al final de la lista
	public boolean end() {
		return (currentPosition == null);
	}

	//retorna el elemento actual
	public Object get() {
		return ((currentPosition != null) ? currentPosition.getDato() : null);
	}

	public void add(Object elem) {
		NodoLista nuevoNodo;
		nuevoNodo = new NodoLista(elem);
		//si no hay posici�n actual -o es el start- se agrega al principio
		if(currentPosition==null || currentPosition==start) {
			nuevoNodo.setNext(start);
			start = nuevoNodo;
		} else {
			//sino se agrega en la posici�n actual
			//me quedo en ante con el anterior a la posici�n buscada
			NodoLista ante = start;
			while (ante.getNext() != currentPosition) {
				ante = ante.getNext();
			}			
			nuevoNodo.setNext(currentPosition);
			ante.setNext(nuevoNodo);
		}
		//cuento al nuevo elemento
		tamLista++;
	}
	
	//elimina elemento actual
	public void remove() {
		if(currentPosition!=null) {
			//si es el start
			if (currentPosition == start) {
				start = start.getNext();
				currentPosition = start;
			} else {
				NodoLista ante;				
				ante = start; //preciso mantener el anterior para corregir referencias
				while ((ante.getNext() != currentPosition)) {
					ante = ante.getNext();
				}
				//lo desreferencio
				ante.setNext(currentPosition.getNext());
				//si era el �ltimo me quedo en su anterior
				if (currentPosition.getNext()==null) {
					currentPosition = ante;
				} else {
					currentPosition = currentPosition.getNext();
				}	
			}
			//corrijo el tama�o
			tamLista--;			
		}
	}

	//elimina la primer coincidencia de elem
	public void remove(Object elem) {
		if(!this.isEmpty()) {
			//si es el primero
			if(start.getDato().equals(elem)) {
				if (currentPosition == start) currentPosition = start.getNext();
				start = start.getNext();
				//corrijo el tama�o
				tamLista--;	
			} else {
				//busco manteniendo al anterior para corregir referencias
				NodoLista ante, nodo = start;				
				do {
					ante = nodo;
					nodo = nodo.getNext();
				} while(nodo!=null && !nodo.getDato().equals(elem));
				//si lo encontr�
				if(nodo!=null) {
					//lo desreferencio
					ante.setNext(nodo.getNext());
					//si era el actual
					if(nodo==currentPosition) {
						if (currentPosition.getNext()==null) { //era el ultimo
							currentPosition = ante;
						} else {
							currentPosition = currentPosition.getNext();
						}
					}
					//corrijo el tama�o
					tamLista--;						
				}
			}
		}
	}
	
	//retorna True si elem est� dentro de la lista; False en caso contrario
	public boolean includes(Object elem) {
		if (this.isEmpty()) {
			return false;
		} else {
			NodoLista nodo = start;
			while ((nodo != null) && (!nodo.getDato().equals(elem))) { nodo = nodo.getNext(); }
			return (nodo != null);
		}
	}
	
	//retorna True si la lista est� vac�a. False en caso contrario.
	public boolean isEmpty() {
		return (start == null);
	}
	
	//retorna la longitud de la lista
	public int size() {
		return tamLista;
	}
	
	public String toString() {
		if(this.isEmpty()) {
			return "";
		} else {
			StringBuffer sb = new StringBuffer("[ ");
			NodoLista aux = start;
			while (aux!=null) {
				sb.append(aux.getDato());
				sb.append(" ");
				aux = aux.getNext();
			}
			sb.append("](");
			sb.append(this.size());
			sb.append(" items).");
			return sb.toString();
		}
	}
}