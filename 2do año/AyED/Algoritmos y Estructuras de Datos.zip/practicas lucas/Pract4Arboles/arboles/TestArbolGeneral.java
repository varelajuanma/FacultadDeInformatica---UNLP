package arboles;

public class TestArbolGeneral {

	public static void main(String[] args) {
		Lista hijos = new Lista();
		hijos.add(new ArbolGeneral("B"));
		hijos.add(new ArbolGeneral("C"));
		hijos.add(new ArbolGeneral("D"));
		ArbolGeneral miArbol = new ArbolGeneral("A", hijos);
		ArbolGeneral arbolAux;
		
		System.out.println(miArbol.getDatoRaiz());
		hijos = miArbol.getHijos();
		hijos.begin();
		while(!hijos.end()) {
			arbolAux = (ArbolGeneral) hijos.get();
			System.out.print(arbolAux.getDatoRaiz());
			hijos.next();
		}
		System.out.println();
		System.out.println("Altura de A: " + miArbol.altura());
		System.out.println("Anchura de A: " + miArbol.ancho());
		System.out.println("Nivel de A: " + miArbol.nivel("A"));
		System.out.println("Nivel de B: " + miArbol.nivel("B"));
		System.out.println("Nivel de D: " + miArbol.nivel("D"));
		System.out.println("Nivel de J: " + miArbol.nivel("J"));
		
		System.out.println("D: " + miArbol.subarbol("D").getDatoRaiz());
		System.out.println("A ancestro de D?: " + miArbol.esAncestro("A","D"));
		System.out.println("D ancestro de A?: " + miArbol.esAncestro("D","A"));
		System.out.println("A ancestro de J?: " + miArbol.esAncestro("A","J"));
		System.out.println("A ancestro de B?: " + miArbol.esAncestro("A","B"));
		System.out.println("B ancestro de D?: " + miArbol.esAncestro("B","D"));
		System.out.println("D ancestro de B?: " + miArbol.esAncestro("D","B"));
		
		System.out.println("Similar A y A?: " + miArbol.equals(miArbol));
		System.out.println("Similar A y B?: " + miArbol.equals(miArbol.subarbol("B")));
		System.out.println("Similar B y C?: " + miArbol.subarbol("B").equals(miArbol.subarbol("C")));
	}

}
