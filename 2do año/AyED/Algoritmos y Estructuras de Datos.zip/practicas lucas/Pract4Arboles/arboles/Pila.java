package arboles;

public class Pila {
	protected ListaPosicional myList = new ListaPosicional();
	
	public int size() {
		return myList.size();
	}
	
	public boolean isEmpty() {
		return myList.isEmpty();
	}
	
	//para hacer una pila con la lista:
	// - push: agrega 
	// - pop: devuelve el elem en el comienzo
	//como la posici�n 0 se accede directamente el orden es constante (implementaci�n Recursiva)
	//en implementaci�n de arreglos ser�a constante si agrego y leo de size()-1
	public void push(Object elem) {
		myList.add(elem, 0);
	}
	public Object pop() {
		Object buff = myList.get(0);
		myList.remove(0);
		return buff;
	}
	
	//permite apilar una serie de elementos desde una lista
	public void pushAll(Lista list) {
		list.begin();
		while(!list.end()) {
			this.push(list.get());
			list.next();
		}
	}
	//devuelve todos los elementos de la pila en una lista
	public Lista popAll() {
		Lista L = new Lista();
		while(!this.isEmpty()) L.add(this.pop());
		return L;
	}
	
	public String toString() {
		return myList.toString();
	}
}
