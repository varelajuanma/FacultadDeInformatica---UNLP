package arboles;

//en realidad s�lo la usa ListaDeStringRecursiva...
//podr�a haber hecho una inner class
public class NodoLista {
	private Object dato;
	private NodoLista nextNode;
	
	public NodoLista(Object dato) {
		this.setDato(dato);
		setNext(null);
	}
	public Object getDato() {
		return dato;
	}
	public NodoLista getNext() {
		return nextNode;
	}
	public void setDato(Object dato) {
		this.dato = dato;
	}
	public void setNext(NodoLista nextNode) {
		this.nextNode = nextNode;
	}
}
