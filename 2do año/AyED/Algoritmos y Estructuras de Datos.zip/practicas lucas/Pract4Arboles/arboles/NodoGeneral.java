package arboles;

//nodos del �rbol - representaci�n interna, lo que se exporta para que usen
//los clientes es ArbolGeneral y Lista
class NodoGeneral {
	protected Object dato;			//dato que almacena
	protected Lista listaHijos;	//lista de NodoGeneral
	
	/* constructor: pone al dato como dato interno del nodo, 
	   e inicializa la lista de hijos */
	public NodoGeneral(Object dato) {
		this.setDato(dato);
		listaHijos = new Lista();
	}
	
	public Object getDato() {
		return dato;
	}
	public void setDato(Object dato) {
		this.dato = dato;
	}
	
	public Lista getHijos() { //devuelve la lista de NodoGeneral que son hijos suyos
		return listaHijos;
	}
	public void setHijos(Lista hijos) {
		this.listaHijos = hijos;
	}
}
