package arboles;

public class ArbolGeneral {
	protected NodoGeneral raiz;
	
	//constructores *************************************************
	public ArbolGeneral(){
		raiz = null;
	}
	//recibe el dato a incluir en la ra�z
	public ArbolGeneral(Object dato){
		raiz = new NodoGeneral(dato);
	}
	/* recibe el dato a incluir en la ra�z y 
	   la lista de �rboles que ser�n sus hijos */
	public ArbolGeneral(Object dato, Lista hijos){
		this(dato); //invoca al otro constructor
		Lista nodosHijos = new Lista();
		ArbolGeneral hijo;
		hijos.begin();	//recorro los �rboles armando la lista de nodos hijos
		while(!hijos.end()) {
			hijo = (ArbolGeneral) hijos.get();
			nodosHijos.add(hijo.getRaiz());
			hijos.next();
		}
		raiz.setHijos(nodosHijos);		
	}	
	//constructor privado
	protected ArbolGeneral(NodoGeneral nodo){
		raiz = nodo;
	}
	
	
	
	//getters y m�todos de instancia *********************************
	//devuelve la ra�z del �rbol
	protected NodoGeneral getRaiz(){
		return raiz;
	}
	//devueve el dato de la ra�z	
	public Object getDatoRaiz(){
		return ((raiz == null)  ? null : raiz.getDato());
	}
	//devuelve una lista con los �rboles hijos del actual
	public Lista getHijos() {
		if(raiz==null) return null;		
		Lista buff = new Lista(); //lista de �rboles hijos a devolver 
		Lista hijos = raiz.getHijos();
		hijos.begin();
		NodoGeneral nodo;
		while(!hijos.end()) {
			nodo = (NodoGeneral) hijos.get();
			buff.add(new ArbolGeneral(nodo));
			hijos.next();
		}
		return buff;
	}
	//agrega la raiz de unHijo en la lista de hijos propia
	public void agregarHijo(ArbolGeneral unHijo) {
		if(raiz!=null) raiz.getHijos().add(unHijo.getRaiz());
	}
	//elimina unHijo de la lista de hijos (si est�) 
	public void eliminarHijo(ArbolGeneral unHijo) {
		if(raiz!=null) raiz.getHijos().remove(unHijo.getRaiz());
	}
	

	
	//devuelve la altura del �rbol
	public int altura() {
		int miAltura = -1;
		Lista misHijos = this.getHijos();
		if(!misHijos.isEmpty()) {
			misHijos.begin();
			//busca altura m�xima de entre los hijos
			int alturaHijo;
			while(!misHijos.end()) {
				alturaHijo = ((ArbolGeneral) misHijos.get()).altura();
				if(alturaHijo>miAltura) miAltura = alturaHijo;
				misHijos.next();
			}
		}
		return ++miAltura;
	}
	//devuelve true si el dato corresponde al arbol
	//cada calse que se use como datos en los nodos del arbol
	//deber�an sobreescribir equals para permitir buscarlas
	//no tanto a partir de ellas mismas sino a desde un String, int o algun tipo usado para su clave
	public boolean include(Object dato) {
		return( raiz.getDato().equals(dato) );
	}
	//devuelve el nivel en que se encuentra el dato
	public int nivel(Object dato) {
		if (this.include(dato)) {
			return 0;
		} else {
			Lista hijos = this.getHijos();
			hijos.begin();
			while(!hijos.end() && !(((ArbolGeneral) hijos.get()).include(dato)) ) {
				hijos.next();
			}
			if(hijos.end()) {
				//a cada uno le pregunto el nivel hasta ancontrarlo
				int nivel=-1;
				hijos.begin();
				while(!hijos.end() && nivel==-1 ) {
					nivel = ((ArbolGeneral) hijos.get()).nivel(dato);
					hijos.next();
				}
				return nivel;
			} else {
				return 1;
			}			
		}
	}
	//devuelve el ancho del arbol (la cant de nodos en el nivel con mas nodos)
	public int ancho() {
		int miAncho = -1; //voy a buscar el m�ximo de nodos por nivel
		Cola c = new Cola();
		c.push(this);	//encolo al arbol principal que es �nico nodo de su nivel
		c.push(null);	//marca de fin de nivel
		int anchoNivelActual = 0;
		Lista lis;
		ArbolGeneral arbol;
		while(!c.isEmpty()) {
			arbol = (ArbolGeneral) c.pop();
			if(arbol==null) {
				//veo si es el maximo
				if(anchoNivelActual>miAncho) miAncho = anchoNivelActual;
				anchoNivelActual = 0;
				//vuelvo a encolar la marca de fin de nivel si hay algo por qu� seguir
				if (!c.isEmpty()) c.push(null);
			} else {
				//cuento al arbol y encolo a sus hijo
				anchoNivelActual++;
				lis = arbol.getHijos();
				lis.begin();
				while(!lis.end()) {
					c.push(lis.get());
					lis.next();
				}
			}
		}
		return miAncho;
	}
	//devuelve el subarbol que tiene como ra�z al nodo con el dato indicado
	public ArbolGeneral subarbol(Object dato) {
		if (this.include(dato)) {
			return this;
		} else {
			Lista hijos = this.getHijos();
			ArbolGeneral aux = null;
			hijos.begin();
			//mientras no termine de recorrer y no encuentre lo que busca
			while(!hijos.end() && aux==null) {
				aux = ((ArbolGeneral) hijos.get()).subarbol(dato);
				hijos.next();
			}
			return aux;		
		}
	}	
	//devuelve true/false seg�n el �rbol con dato1 como ra�z sea ancestro del de dato2
	public boolean esAncestro(Object dato1, Object dato2) {
		ArbolGeneral origen = this.subarbol(dato1);
		if(origen!=null) {
			return (origen.subarbol(dato2)!=null);
		} else {
			return false;
		}
	}
	//determina si el arbol es equivalente al pasado otroArbol -igual estructura no valores-
	public boolean equals(ArbolGeneral otroArbol) {
		boolean iguales = true;
		Cola c1 = new Cola();
		Cola c2 = new Cola();
		c1.push(this);	//encolo al arbol principal 
		c1.push(null);	//marca de fin de nivel
		c2.push(otroArbol);	//encolo al arbol principal 
		c2.push(null);	    //marca de fin de nivel

		Lista lis1, lis2;
		ArbolGeneral arbol1, arbol2;
		while(iguales && !c1.isEmpty() && !c2.isEmpty()) {
			arbol1 = (ArbolGeneral) c1.pop();
			arbol2 = (ArbolGeneral) c2.pop();
			if(arbol1==null) {
				iguales = (arbol2==null);
				//vuelvo a encolar la marca de fin de nivel si hay algo por qu� seguir
				if (!c1.isEmpty()) c1.push(arbol1);
				if (iguales && !c2.isEmpty()) c2.push(arbol2);
			} else if(arbol2==null) {
				iguales = false;
			} else {
				lis1 = arbol1.getHijos();
				lis2 = arbol2.getHijos();
				iguales = (lis1.size()==lis2.size());
				if(iguales) {
					c1.pushAll(lis1);
					c2.pushAll(lis2);
				}
			}
		}
		return (iguales && (c1.isEmpty()==c2.isEmpty()));
	}

	//sobreescribe el toString mostrando la estructura del �rbol
	public String toString() {
		StringBuffer sb = new StringBuffer();
		this.toString("",sb);
		return sb.toString();
	}
	//devuelve en un String la estructura y contenido del �rbol para imprimirse
	public void toString(String margen, StringBuffer sb) {		
		sb.append(margen);
		sb.append(this.getDatoRaiz().toString());
		sb.append("\n");			
		margen=margen+"|  ";
		Lista hijos = this.getHijos();
		hijos.begin();
		while(!hijos.end()) {
			((ArbolGeneral) hijos.get()).toString(margen,sb);
			hijos.next();
		}		
	}
	
	//devuelve true/false seg�n el �rbol sea hoja o no
	public boolean esHoja() {
		return (raiz==null) ? true : raiz.getHijos().isEmpty();
	}
	
	//ejercicio del examen parcial
	//si recibe una lista con C A S A  -todos chars-, revisa si el arbol actual
	//tiene algun camino desde una hoja hasta la raiz con esa secuencia de caracteres
	//(la raiz tiene que tener la A, y la hoja ser la C	
	public boolean estaContenido(Lista unaLista) {
		if(unaLista.isEmpty()) return (this.getRaiz()==null);
		//primero paso la lista a una pila para leer en el mismo orden que en el arbol
		Pila p = new Pila();
		unaLista.begin();
		while(!unaLista.end()) {
			p.push(unaLista.get());
			unaLista.next();
		}
		//vars para lecturas
		char cPila, cArbol;
		//vars auxiilares y para hacer el backtracking
		NodoGeneral aux = this.getRaiz();
		Pila BUFF = new Pila(), BUFF2 = new Pila(); /* LAS CREE EN EL IF(BUSCO), DARIA ERROR COMPIL PORQ PODRIA NO INIIALIZARSE*/
		Lista hijos;
		cPila = (Character) p.pop(); //yo puse (char) en vez de la clase wrapper!!!
		cArbol = (Character) aux.getDato();
		boolean busco = (cPila == cArbol);
		if(busco) {
			hijos = aux.getHijos();
			hijos.begin();
			BUFF.push(hijos); //apila los hijos para empezar desde ellos y el sig char de p
		}
		while(busco && !p.isEmpty()) {
			cPila = (Character) p.pop(); //yo puse (char) en vez de la clase wrapper!!!
			hijos = (Lista) BUFF.pop(); //saca la lista de la pila, por donde iba
			//busca si algun hijo restante tiene el char cPila
			do {
				aux = (NodoGeneral) hijos.get();
				hijos.next();
			} while(!hijos.end() && ((Character) aux.getDato())!=cPila );
			/* ACA ME NO ME DI CUENTA DEL AUX==NULL || */
			if(aux==null || ((Character) aux.getDato())!=cPila) { //termine los hijos y no lo encontre
				//vuelve atras si hay con que
				if(BUFF.isEmpty()) {
					busco = false;
				} else {
					p.push(cPila);
					p.push(BUFF2.pop());
				}
			} else {
				//aux tiene el Character buscado, sigo con sus  hijos y el prox Character
				/* A ESTE IF LO PUSE AFUERA.... ACA SOLO PUSE SU ELSE */
				if(p.isEmpty() && !aux.getHijos().isEmpty()) {
					//vuelve atras si hay con que ***** lo mismo que arriba
					if(BUFF.isEmpty()) {	 //ESTO
						busco = false;  	 //NO
					} else {				 //LO
						p.push(cPila);	 	 //PUSE
						p.push(BUFF2.pop()); //ACA    IGUAL CONVENDRIA UNA VAR BOOL deboVolver, ME FIJO LAS 2 COND Y VUELVO O SIGO
					}
				} else {
					BUFF.push(hijos); //guardo por donde iba
					BUFF2.push(cPila);
					hijos = aux.getHijos();
					hijos.begin();
					BUFF.push(hijos);
				}
			}
		}
		//salgo del mientras
		return busco;
		//si sigo buscando es porq vacie la pila y encontre todo
		/* A ESTO LO PUSE ACA PERO IRIA DENTRO DEL WHILE DONDE ESTA AHORA
		 * PORQUE PUEDO ENCONTRAR TODO Y NO TERMINAR EN UNA HOJA, PERO TENGO
		 * QUE SEGUIR MIRANDO POR SI ESTA OTRA VEZ */
		/*if(!busco) {
			return false;
		} else {
			//si sali porq vacie la pila, me fijo si termine en una hoja
			return (aux.getHijos().isEmpty());
		}*/
	}
}
