package Directorios;

import arboles.ArbolGeneral;
import arboles.Lista;

public class SistemaDeDirectorios {
	protected ArbolGeneral raiz = null;
	
	//constructor - recibe el nombre para el directorio ra�z
	public SistemaDeDirectorios(String nombreRaiz) {
		Directorio raiz = new Directorio(nombreRaiz);
		this.raiz = new ArbolGeneral(raiz);
	}
	
	//devuelve el subdirectorio con el nombre que se le indique
	public ArbolGeneral getSubdirectorio(String nombreSubdirectorio) {
		if (raiz==null) {	//si no hay ra�z
			return null;
		} else {			//sino busca en el arbol. Cada dato es un Directorio que entiende el mensaje equals(object)
			return raiz.subarbol(nombreSubdirectorio);
		}
	}	
	
	//devuelve la lista de archivos en el subdirectorio indicado
	//si no hay hijos, devuelve lista vac�a
	public Lista archivos(String directorio) {
		//busco el subdirectorio
		ArbolGeneral arbol = getSubdirectorio(directorio);
		if (arbol==null) { //no existe el directorio
			return null;
		} else {			//existe, le pido los archivos
			Directorio subdirectorio = (Directorio) arbol.getDatoRaiz();
			return subdirectorio.getListaDeArchivos();
		}
	}
	public Lista subdirectorios(String directorio) {
		//busco el subdirectorio
		ArbolGeneral arbol = getSubdirectorio(directorio);
		if (arbol==null) { //no existe el directorio
			return null;
		} else {			//existe
			Lista listaSubdirectorios = new Lista();
			Lista hijos = arbol.getHijos();
			hijos.begin();
			while(!hijos.end()) {	//armo la lista de directorios
				listaSubdirectorios.add(((ArbolGeneral) hijos.get()).getDatoRaiz());
				hijos.next();
			}
			return listaSubdirectorios;
		}
	}
	//devuelve el tama�o de los archivos en un subdirectorio
	public int tama�o(String directorio) {
		int tam = 0;
		Lista archivos = this.archivos(directorio);
		if(archivos!=null) {
			archivos.begin();
			while(!archivos.end()) {
				tam += ((Archivo) archivos.get()).getTama�o();
				archivos.next();
			}
		}
		return tam;
	}
	
	private String pathMax(ArbolGeneral A) {
		if(A==null) {
			return "";
		} else {
			Lista L = A.getHijos();
			L.begin();
			String path = "", pathM = "";
			while(!L.end()) {
				path = pathMax((ArbolGeneral) L.get());
				if(path.length()>=pathM.length()) {
					pathM = path;
				}
				L.next();
			}
			return ( ((Directorio) A.getDatoRaiz()) .getNombre().toString() + "\\" + pathM);
		}
	}
	
	public String pathMasLargo() {
		String maxPath = pathMax(raiz);
		return maxPath;
	}
	
	
	
	

}
