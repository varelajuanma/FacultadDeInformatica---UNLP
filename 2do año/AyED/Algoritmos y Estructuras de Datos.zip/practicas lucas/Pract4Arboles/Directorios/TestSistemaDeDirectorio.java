package Directorios;

import arboles.ArbolGeneral;
import arboles.Lista;

public class TestSistemaDeDirectorio {
	public static void main(String arg[]) { //PRUEBA
		SistemaDeDirectorios S = new SistemaDeDirectorios("raiz");
		ArbolGeneral raiz = S.getSubdirectorio("raiz");		
		raiz.agregarHijo(new ArbolGeneral(new Directorio("temp")));
		raiz.agregarHijo(new ArbolGeneral(new Directorio("temporal")));
		raiz.agregarHijo(new ArbolGeneral(new Directorio("tempo")));
		
		raiz = S.getSubdirectorio("tempo");
		raiz.agregarHijo(new ArbolGeneral(new Directorio("Lucas")));
		Directorio D = ((Directorio) raiz.getDatoRaiz());
		D.getListaDeArchivos().add(  new Archivo("Lucas.txt",10) );
		D.getListaDeArchivos().add(  new Archivo("mis cosas.txt",30) );
		D.getListaDeArchivos().add(  new Archivo("diego torres.mp3",4110) );
		D.getListaDeArchivos().add(  new Archivo("ver.txt",1) );
		
		System.out.println(S.pathMasLargo());
		
		System.out.println("\nSubdirectorios del ra�z:");   
		Lista L = S.subdirectorios("raiz");
		L.begin();
		while(!L.end()) {
			System.out.println(   ((Directorio) L.get()).getNombre()  );
			L.next();
		}

		System.out.println("\nArchivos tempo:");   
		L = S.archivos("tempo");
		L.begin();
		while(!L.end()) {
			System.out.println(   ((Archivo) L.get()).getNombre()  );
			L.next();
		}
	}
}
