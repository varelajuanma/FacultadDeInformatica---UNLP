package Directorios;

public class Archivo {
	protected String nombre = null;
	protected int tama�o = 0;
	
	//constructor
	public Archivo(String nombre, int tama�o) {
		this.setNombre(nombre);
		this.setTama�o(tama�o);
	}
	
	//getters y setters
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public int getTama�o() {
		return tama�o;
	}
	public void setTama�o(int tama�o) {
		this.tama�o = tama�o;
	}
	
	//otras...
	public String toString() {
		return nombre + " (" + tama�o + " Kb)";
	}
	
}
