package Directorios;

import arboles.Lista;

//los Directorios ser�n almacenados como dato de cada NodoGeneral
public class Directorio {
	protected String nombre = null;
	protected Lista listaDeArchivos = null;
	
	//constructores
	public Directorio(String nombre) {
		this.setNombre(nombre);
		this.listaDeArchivos = new Lista();
	}
	public Directorio(String nombre, Lista listaDeArchivos) {
		this.setNombre(nombre);
		this.setListaDeArchivos(listaDeArchivos);
	}
	
	//getters y setters
	public Lista getListaDeArchivos() {
		return listaDeArchivos;
	}
	public void setListaDeArchivos(Lista listaDeArchivos) {
		this.listaDeArchivos = listaDeArchivos;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	//otras...
	public String toString() {
		return nombre;// + " (" + listaDeArchivos.size() + " archivos).";
	}
	//igualdad contra string --> si es el nombre del directorio
	public boolean equals(Object otroObjeto)  {
		if (otroObjeto instanceof String) {
			return (this.getNombre().equals(nombre));
		} else {
			return super.equals(otroObjeto);
		}
	}
}
