public int altura(){
		if(this.raiz==null){
			return -1;
		}else{
			if(this.getHijos()==null){
				return 0;
			}else{
				int max=0;
				int alturaHijo=0;
				Lista hijos=this.getHijos();
				hijos.comenzar();
				while(!hijos.fin()){
					ArbolGeneral hijo=(ArbolGeneral)hijos.elemento();
					alturaHijo=hijo.altura();
					max=Math.max(max,alturaHijo);
					hijos.proximo();
				}
				return max+1;
			}
		}
	}