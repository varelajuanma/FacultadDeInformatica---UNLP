public class Grafo{
	
	public boolean conectar(Strin dato1, String dato2) {
		int posicion1 = this.posicion(dato1);
		int posicion2 = this.posicion(dato2);
		if(posicion1>=0 && posicion2>=0) { //si estaban los dos
			this.vertices[posicion1].conectar(this.vertices[posicion2]);
			this.vertices[posicion2].conectar(this.vertices[posicion2]);
			//esto si no es dirigido
			return true;
		} else {
			return false; //alguno no estaba -o ninguno-
		}
	}
	
	//recorrido DFS (recursivo)
	//en profundidad se le llama, bajo todo lo que puedo y dsp tomo otro
	//al volver no me tiene que quedar marcado el vertice (para tomar todos los caminos poseibles desde a hacia b)
	/* T(V,A) = cte + V * (cte + T(dfs)) + V
	 * en total la funcion dfs se llamara una vez para cada vertice, es decir V veces
	 * sea por el for o por llamadas recursivas
	 * cada T(dfs) tiene ademas de un cte, un bucle por la cantidad ai de adyacentes de cada
	 * vertice. Para los V vertices, esto es A. Así
	 *  T(V,A) = cte + A + V = O(V + A)  LINEAL
	 */
	public Lista dfs(){
		boolean[] visitados=new boolean[cantVertices];
		Lista lista=new Lista();
		//inicializar vector en false
		
		for(int i=0;i<cantVertices;i++){
			if(! visitados[i]){
				dfs(i,visitados,lista);
			}
		}
		return lista;	
	}
	
	private void dfs(int i, boolean[] visitados, Lista lista){
		visitados[i]=true;
		lista.agregar(vertices[i].getDato());
		//lista de aristas :
		Lista adyacentes=vertices[i].getAdyacentes();
		adyacentes.comenzar();
		while(! adyacentes.fin() ){
			Arista a=(Arista)adyacentes.elemento();
			if(! visitados[a.getDestino().getPosicion()]){
				dfs(a.getDestino().getPosicion(), visitados, lista);
			}
			adyacentes.proximo();
		}
	
	}
	
	//bfs recorrido en amplitud
	//de un vertice recorro todos los adyacentes (como el recorrido por niveles de un arbol)
	/*/* T(V,A) = cte + V * cte + V * ai + V
	 *        = cte + (cte+1) V + A
	 *        = O(V + A)   LINEAL
	 */
	public Lista bfs() {										
		Lista l=new Lista();
		boolean visitados[] = new boolean[cantVertices];
		for(int i = 0; i<cantVertices; i++) {
			if(!tomados[i]){
				bfs(i, visitados, l);
			}
		}
		return l;
	}
	
	private void bfs(int i, boolean[] visitados, Lista l){
		Cola c=new Cola() //cola para recorrido por niveles
		visitados[i]=true;
		Lista ady; //lista auxiliar
		Arista a; //arista auxiliar
		Vertice v; //vertice auxiliar
		c.encolear(vertices[i]); //encolo el primer elemento
		while(!c.fin()){
			v=(Vertice)c.desencolar(); //trato el elemnto
			l.agregar(v.getDato()); //agrego en la lista que devuelvo arriba
			ady=v.getAdyacentes();
			ady.comenzar();
			while(!ady.fin()){
				a=(Arista)ady.elemento();
				int pos=a.getDestino().getPosicion();
				if(!visitados[pos]){
					c.encolar(a.getDestino()); //encolo el proximo vertice
					visitados[pos]=true; //lo marco visitado ahora para no encolarlo de nuevo dsp
				}
				ady.proximo();
			}
		}
	}	
	
	//si es un grafo no dirigido, tengo que tener en cuenta que la cantidad de arista sea <=3 (ciclo minimo)
	public boolean tieneCiclo(){
		boolean encontroCiclo = false;
		//vector "visitados" de DFS se puede reemplazar directamente por la numeracion		
		int numeracion[][] = new int[this.cantVertices][2]; //en 0 guardo el numero del vertice
								    //en 1 el ult. descendiente
		int contador = 0;
		for(int i = 0; i<this.cantVertices && !encontroCiclo; i++) {
			if(numeracion[i][0]==0) {
				contador = contador++;
				encontroCiclo = this.dfsControlCiclos(this.vertices[i], numeracion, contador);
			}
		}		
		return encontroCiclo;
	}
	
	private boolean dfsControlCiclos(Vertice vOrigen, int numeracion[][], int contador){
		boolean encontroCiclo = false;
		//numeracion del vertice
		numeracion[vOrigen.getPosicion()][0] = contador;
		//marca que lo va a procesar considerando en principio que sera el antecesor de
		//todos los que faltan revisar - para simplificar distincion back/cross
		numeracion[vOrigen.getPosicion()][1] = this.cantVertices; 
		Lista aristas = vOrigen.getAdyacentes();
		Vertice auxi;
		aristas.begin();
		while(!aristas.end() && !encontroCiclo) {
			auxi = ((Arista) aristas.get()).getDestino();
			//numeracion en 0: no visitado, se hace dfsControlCiclos
			//numeracion > a la de vOrigen: fordware, no afecta
			//numeracion < a la de vOrigen: ¿cross o back?
			//	si la numeracion de vOrigen es <= al ultimo descendiente de auxi ES BACK Y HAY CICLO
			//  sino es cross y no importa
			if(numeracion[auxi.getPosicion()][0]==0) { //aun no visitado
				contador = contador++;
				encontroCiclo = this.dfsControlCiclos(auxi, numeracion, contador);
			} else if(numeracion[auxi.getPosicion()][0] < numeracion[vOrigen.getPosicion()][0]) {
				encontroCiclo = (numeracion[vOrigen.getPosicion()][0] <= numeracion[auxi.getPosicion()][1]); 
			}
			aristas.next();
		}
		numeracion[vOrigen.getPosicion()][1] = contador; //completa bien la numeracion de su ultimo hijo
		return encontroCiclo;
	}




	//hacer punto 4 y 5 de la practica completos
	
	public boolean esAdyacente(String dato1, String dato2){
	
		int pos1=this.posicion(dato1);
		if(pos1!=-1){
			int pos2=this.posicion(dato2);
			if(pos2!=-1){
				Vertice v=vertices[pos1];
				Lista l=v.getAdyacentes();
				//Arista a=new Arista();
				return (l.includes(vertices[pos2]));
				
			}
		}
		return false;
		
	}
	
	/* ALGORITMO DE DIJKSTRA PARA CAMINOS DE COSTO MINIMO - GRAFOS PESADOS
	 * (Para grafos sin peso, se hace un BFS con array de previos y distancias)
	 * Los pesos deben ser no negativos para dijkstra. Se usan arrays de previo,
	 * distancia y visitados. Inicialmente, distancias se completa con valores
	 * infinito, salvo para el origen que será 0.
	 * En cada iteracion se elige el vertice con menor distancia sin visitar, y se
	 * evalua a todos sus adyacentes no visitados. Si la distancia nueva es menor a la
	 * registrada en distancias, se elige la nueva opcion y se completa el previo.
	 * 
	 * T(V,A) = cte inicializacion + V veces (tomar menor Vi sin visitar y recorrer su ai)
	 *        = cte                + V *     (V + ai)
	 *        = cte                + V^2 + A
	 *        = O(V^2)    CUADRATICO
	 * El componente cuadrático se debe a la busqueda del menor Vi sin visitar.
	 * Se podria mejorar utilizando una HEAP que devuelva siempre el menor con tiempo O(1)
	 * y que mantenga su orden con un O(log V). En la heap inicialmente se podria poner 0
	 * asociado al origen e infinito asociado al resto -se obviaría y no se ponen
	 * directamente. La HEAP es COMPLEMENTARIA, no reemplaza al vector de distancias,
	 * solo permite accederlos ordenadamente. Al obtener una distancia menor para un vertice
	 * se lo debe actualizar en el vector Y en la HEAP -habria que recorrerla para encontrar
	 * el nodo y hacer decrease key (O(V) y O(logV)). Se podria evitar con un hash asociado
	 * que devuelve la posicion del nodo en la heap, o simplemente agregando la nueva distancia
	 * en la heap -se va a leer obviamente antes que la distancia anterior por ser menor-
	 * La lectura de la heap se haría así hasta que devuelva un vertice no visitado aún (ya
	 * que acumularia "basura"). 
	 * Ya utilizando la heap:
	 *  T(V,A) = cte inic. + V veces en w.c. (tomar Vi sin visitar de H y recorrer ai agregando en H)
	 *         = cte + V * (Log(?1?) + ai * Log(?2?))
	 *         = cte + V Log(?1?) + A log(?2?)
	 *  w.c.: "peor caso" seria que el vertice origen sea conexo -podra alcanzar a todos los otros v-
	 *  y que cada nuevo camino que explore resulte en una mejora con lo cual debera insertar en H
	 *  	?1? se refiere a tomar un nuevo vertice aun no procesado de la heap
	 *  	?2? se refiere a la insercion de los elemtos en la heap
	 *  Como la H en el w.c. crecera en relacion a A (se insertaran en el w.c. tantos elementos como
	 *  aristas hay en el grafo) entonces Log(?2?) es Log(A).
	 *  ?1? leera de una H con A elemenos en el w.c. La lectura sera se coste O(Log(A)). Pero tambien
	 *  leera la "basura", que para cada vertice será uno menos a la cantidad ai' de aristas que
	 *  llegan al vertice. En total la cant de lecturas sera A (V * vi' : vi' aristas incidentes a vi).
	 *  Así ?1? sería A Log(A) (A lecturas, con costo Log(A) en el w.c.  --obvio que es sobreestimacion)
	 *  Resumiendo:
	 *  T(V,A) = cte + A Log(A) + A Log(A)
	 *         = cte + 2 A Log(A)
	 *         = O(A Log(A))               A LOG(A)  ("CASI LINEAL" RESPECTO DE A --algo mayor)
	 *  Como A <= V^2  -->  Log(A) <= 2 Log(V)
	 *  Puede decirse tambien que:
	 *  T(V,A) = O(A Log(V))   con una sobreestimacion > mientras menos denso sea el grafo (a medida que A<<)
	 *  en el peor caso, un grafo DENSO, se tiene:
	 *       A  =  V^2
	 *  y    T(V,A) = O(V^2 Log(V))       V^2 Log(V)  ("CASI" CUADRATICO  --algo mayor)
	 *  EN GRAFOS DENSOS, sería conveniente así la implementacion SIN HEAP.
	 *  Si se considera una estructua HEAP + HASH se podría llegar a algo como V log(V) (poco m as que lineal)
	 */
	private Lista dijkstra(Vertice v) { //caminos minimos
		//lista para devolver
		Lista caminoMin = new Lista();
		//estructuras auxiliares para dijkstra
		Heap miHeap = new Heap();		
		int distancias[] = new int[this.cantVertices];
		boolean visitados[] = new boolean[this.cantVertices];
		int previo[] = new int[this.cantVertices];
		//inicializacion: sin previo ni distancias validas, salvo v que parte de el mismo con distancia 0
		for(int i = 0; i < this.cantVertices; i++) {
			previo[i] = -1;
			visitados[i] = false;
			distancias[i] = Integer.MAX_VALUE;
		}
		previo[v.getPosicion()] = v.getPosicion();
		distancias[v.getPosicion()] = 0;
		miHeap.agregar(new Costo(v)); //costo 0 para el vertice de origen
		Costo siguiente;
		Lista aristas;
		AristaPesada arista;
		Vertice adyacente;
		//for(int i = 0; i< this.cantVertices; i++) { ********************************
		while(!miHeap.esVacia() &&  caminoMin.size()<this.cantVertices ) {
			//leo de la heap mientras esten ya tomados y haya que leer
			do {
				siguiente = (Costo) miHeap.tope();
				v = siguiente.getVertice();				
			} while (!miHeap.esVacia() && visitados[v.getPosicion()]);
			//} while (visitados[v.getPosicion()]); **********************************
			if(!visitados[v.getPosicion()]) { //**************************************
				//agrego el costo al camino
				visitados[v.getPosicion()] = true;
				caminoMin.add(siguiente);
				aristas = v.getAdyacentes();
				aristas.begin();
				while(!aristas.end()) {
					arista    = (AristaPesada) aristas.get();
					adyacente = arista.getDestino();
					//si el adyacente no esta visitado
					if(!visitados[adyacente.getPosicion()]) {
						//si puedo lograr una distancia mejor la actualizo
						//if (arista.getPeso()<0) PUEDE DAR RESULTADOS ERRONEOS. SE SUPONE QUE SE 							USE DIJKSTRA
						//                        CON PESOS POSITIVOS O NULOS
						if(distancias[adyacente.getPosicion()] > distancias[v.getPosicion()] + arista.getPeso()) {
							distancias[adyacente.getPosicion()] = distancias[v.getPosicion()] + arista.getPeso();
							previo[adyacente.getPosicion()] = v.getPosicion();
							miHeap.agregar(new Costo(adyacente, v, distancias[adyacente.getPosicion()]));
						}
					}
					aristas.next();
				}
			}
		}
		/* Nota sobre los "********":  Las lineas que agregue o modifiqué y marque 
		 * con asteriscos, son correcciones que tuve en cuenta por si el origen v no
		 * es conexo (si hay vertices que nunca podra alcanzar, iterar V veces produce
		 * error al vaciar la heap y pretender seguir iterando). */
		return caminoMin;
	}

  	public Lista dijkstra(Comparable datoOrigen) {
		int posicionOrigen = this.posicion(datoOrigen);		
		if(posicionOrigen<0) return new Lista();
		return this.dijkstra(this.vertices[posicionOrigen]);
  	}

}
