public int nivel(Object dato){
			if(this.raiz.getDato()==dato){
				return 0;
			}else{
				int niv=0;
				if(this.includes(dato)){
					return niv++;
				}else{
					//niv++;
					Lista aux=this.getHijos();
					if(!(aux==null)){
						aux.comenzar();
						while(!aux.fin()){
							niv=((ArbolGeneral)aux.elemento()).nivel(dato)+1;
							aux.proximo();
						}
					}
				}
				return niv;
			}