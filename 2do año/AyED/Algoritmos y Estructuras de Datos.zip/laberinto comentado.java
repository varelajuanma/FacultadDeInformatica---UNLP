//main basico para resolucion de grafos tipo: Grafo no dirigido conexo
//la estrategia en este ejercicio es muy simple, solo armar los posibles
// caminos, comparar cual es mas corto y devolver el tama�o del mismo.
public class Laberinto {

	//asumimos que recivimos el vertice de entrada y salida, sino podemos buscarlo
	//como en los otros ejercicios (ej: mafia).
	public int laberinto(Grafo<Encrucijada> grafo,
			Vertice<Encrucijada> entrada, Vertice<Encrucijada> salida) {
			//preparamos las variables de siempre.
			//arreglo de visitados
		boolean[] visitados = new boolean[grafo.listaDeVertices().tamanio()];
		//listas de mejor camino y camino actual
		ListaEnlazadaGenerica<Vertice<Encrucijada>> caminoActual = new ListaEnlazadaGenerica<Vertice<Encrucijada>>();
		ListaEnlazadaGenerica<Vertice<Encrucijada>> mejorCamino = new ListaEnlazadaGenerica<Vertice<Encrucijada>>();
		//en este caso no necesitamos ningun contador ya que nos interesa solo el tama�o de las listas.
		dfs(grafo, visitados, caminoActual, mejorCamino, entrada, salida);
		//devolvemos el tamanio del mejor camino
		return mejorCamino.tamanio();
	}

	public void dfs(Grafo<Encrucijada> grafo, boolean[] visi,
			ListaEnlazadaGenerica<Vertice<Encrucijada>> camAct,
			ListaEnlazadaGenerica<Vertice<Encrucijada>> mejCam,
			Vertice<Encrucijada> act, Vertice<Encrucijada> sal) {
			//si la encrucijada actual no es igual a la salida
		if (act != sal) {
			//marcamos actual como visitado
			visi[act.getPosicion()] = true;
			//agregamos "actual" al camino actial
			camAct.agregar(act, camAct.tamanio());
			//tomamos la lista de adyacentes de la encrucijada actual.
			//ACLARACION: No se si la arista debe ser de tipo Encrucijada
			//				o podria ser de tipo T (generico).
			//				De cualquier forma no nos afecta para este ejercicio.
			ListaGenerica<Arista<Encrucijada>> ady = grafo.listaDeAdyacentes(act);
			//nos hubicamos en el comienzo de la lista de adyacentes.
			ady.comenzar();
			//mientras no lleguemos al final de la lista
			while (!ady.fin()) {
				//si el vertice destino de la arista actual no esta visitado
				if (!visi[ady.elemento().getVerticeDestino().getPosicion()]) {
					//llamamos recursivamente al dfs pero ahora el vertice actual sera
					//	el vertice destino de la arista
					dfs(grafo, visi, camAct, mejCam, ady.elemento().getVerticeDestino(), sal);
					//cuando volvemos de la recursion removemos el vertice actual del camino actual
					camAct.eliminar(camAct.tamanio() - 1);
					//y marcamos como no visitado en el arreglo de visitados.
					visi[act.getPosicion()] = false;
				}
				//avanzamos a la proxima arista
				ady.proximo();
			}
		//si llegamos a la salida
		} else {
			//preguntamos si la lista es vacia por la primera vez que entre.
			if (mejCam.esVacia()) {
				//asignamos camino actual a mejor camino
				mejCam = ((ListaEnlazadaGenerica<Vertice<Encrucijada>>) camAct).clone();
			//si no es vacia preguntamos si el camino actual es mas corto que el mejor camino
			} else if (camAct.tamanio() < mejCam.tamanio()) {
				//y asignamos camino actual a mejor camino
				mejCam = ((ListaEnlazadaGenerica<Vertice<Encrucijada>>) camAct).clone();
			}
		}
	}

}
public class Encrucijada {
	int posicion
	string nombre
}