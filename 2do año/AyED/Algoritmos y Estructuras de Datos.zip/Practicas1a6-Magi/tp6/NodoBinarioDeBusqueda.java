package tp6;

public class NodoBinarioDeBusqueda {
	private Comparable dato;
	private NodoBinarioDeBusqueda hijoIzquierdo;
	private NodoBinarioDeBusqueda hijoDerecho;
	
	public NodoBinarioDeBusqueda(Comparable dato){
		this.dato=dato;
		hijoIzquierdo=null;
		hijoDerecho=null;
	}
	
	public Comparable getDato(){
		return dato;
	}
	
	public NodoBinarioDeBusqueda getHijoIzquierdo(){
		return hijoIzquierdo;
	}
	
	public NodoBinarioDeBusqueda getHijoDerecho(){
		return hijoDerecho;
	}
	
	public void setDato(Comparable dato){
		this.dato=dato;
	}
	
	public void setHijoIzquierdo(NodoBinarioDeBusqueda unHijo){
		hijoIzquierdo=unHijo;
	}
	
	public void setHijoDerecho(NodoBinarioDeBusqueda unHijo){
		hijoDerecho=unHijo;
	}
	
}
