package tp6;

public class ArbolBinarioDeBusqueda {
	private NodoBinarioDeBusqueda raiz;
	
	public ArbolBinarioDeBusqueda(){
		raiz=null;
	}
	
	public ArbolBinarioDeBusqueda(Comparable dato){
		raiz=new NodoBinarioDeBusqueda(dato);
	}
	
	private ArbolBinarioDeBusqueda(NodoBinarioDeBusqueda nodo){
		this();
		raiz=nodo;
	}
	
	public Comparable getDatoRaiz(){
		return raiz.getDato(); 
	}
	
	private NodoBinarioDeBusqueda getRaiz(){
		return raiz; 
	}
	
	public void setHijoDerecho(ArbolBinarioDeBusqueda unHijo){
		NodoBinarioDeBusqueda N= unHijo.getRaiz();
		raiz.setHijoDerecho(N);
	}
	
	public void setHijoIzquierdo(ArbolBinarioDeBusqueda unHijo){
		NodoBinarioDeBusqueda N= unHijo.getRaiz();
		raiz.setHijoIzquierdo(N);
	}
	
	public ArbolBinarioDeBusqueda getHijoIzquierdo(){
		NodoBinarioDeBusqueda N= raiz.getHijoIzquierdo();
		return new ArbolBinarioDeBusqueda(N);
	}

public ArbolBinarioDeBusqueda getHijoDerecho(){
	NodoBinarioDeBusqueda N= raiz.getHijoDerecho();
	return new ArbolBinarioDeBusqueda(N);
}
	
	@SuppressWarnings("unchecked")
	public void agregar (Comparable dato){
		if(raiz ==null){
			raiz= new NodoBinarioDeBusqueda(dato);
			setHijoIzquierdo(null);
			setHijoDerecho(null);
		}
		else{
			if(dato.compareTo(getDatoRaiz())<0){
				ArbolBinarioDeBusqueda I= getHijoIzquierdo();
				I.agregar(dato);
			}
			else{
				ArbolBinarioDeBusqueda D= getHijoIzquierdo();
				D.agregar(dato);
			}
		}
	}
	
	
	
}
