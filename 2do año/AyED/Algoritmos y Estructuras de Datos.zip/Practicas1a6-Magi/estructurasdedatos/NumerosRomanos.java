
package estructurasdedatos;
public class NumerosRomanos {

	public static void main(String[] args) {
		int num= Integer.parseInt(args[0]);
		System.out.print(num+" --> ");
		String Result= romanos(num,0);
		System.out.println(Result);
	}
	
	public static String romanos(int n, int pos){
		String S;
		if(n>0)
			S= romanos(n/10,pos+1)+convertir(n%10,pos);
		else
			S="";
		return S;
	}
	
	public static String convertir(int n,int pos){
		String a=null;
		String b=null;
		String c=null;
		String S=null;
		switch (pos){
			case 0:{
				a="I";
				b="V";
				c="X";}
			break;
			case 1:{
				a="X";
				b="L";
				c="C";}
			break;
			case 2:{
				a="C";
				b="D";
				c="M";}
			break;
			case 3:{
				a="M";}
			break;}
	switch (n){
		case 0:
			S="";
		break;
		case 1:{
			S=a;}
		break;
		case 2:{
			S=a+a;}
		break;
		case 3:{
			S=a+a+a;}
		break;
		case 4:{
			S=a+b;}
		break;
		case 5:{
			S=b;}
		break;
		case 6:{
			S=b+a;}
		break;
		case 7:{
			S=b+a+a;}
		break;
		case 8:{
			S=b+a+a+a;}
		break;
		case 9:{
			S=a+c;}
		break;}
	
	return S;	
}
}


