
package estructurasdedatos;
public class Bucles {
	public static void uno (int n){
		int i,j,k;
		int[][]a,b,c;
		a = new int[n][n];
		b = new int[n][n];
		c = new int[n][n];
		for(i=1;i<=n-1;i++){
			for(j=i+1;j<=n;j++){
				for(k=1;k<=j;k++){
					c[i][j]=c[i][j]+ a[i][j]* b[i][j];	
				}
			}
		}
	}
	
	public static void dos (int n){
		int i,j,x,y;
		x=0;
		y=0;
		for(i=1;i<=n-1;i++){
			if (n%2 == 1){
				for(j=i;j<=n;j++){
					x=x+1;	
				}
				for(j=1;j<=i;j++){
					y=y+1;
				}
			}
		}
	}
	
	public static void tres (int n){
		int i,j,k,sum;
		sum=0;
		for(i=1;i<=n;i++){
			for(j=1;j<=i*i;j++){
				for(k=1;k<=j;k++){
					sum=sum+1;
				}
			}
		}		
	}	
	
}
