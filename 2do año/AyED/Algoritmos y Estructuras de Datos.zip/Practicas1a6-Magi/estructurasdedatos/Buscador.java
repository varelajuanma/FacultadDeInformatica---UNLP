
package estructurasdedatos;
public class Buscador {
	static int n;
	static int[][]elementosOrdenados= new int[n][n];
	
	public static boolean Buscar(int x){
		int i,j;
		boolean ok= false;
		i=1;
		while (i<=n && !ok){
			j=1;
			while(j<n && elementosOrdenados[i][j]<x){
				j++;}			
			ok= elementosOrdenados[i][j]==x;
			i++;
		}
		return ok;
	}
/* bucle:
 * for(int i=1;i<=n;i++){
 * 	for(int j=1;j<=n;j++){
 * 		if(elementosOrdenados==x){
 * 			ok=true;
 * 			break bucle;
 * 		}
 * 	}
 * }
 * return ok;*/	 

	public static boolean Buscar2(int x){
		int i=1;
		boolean ok=false;
		while (i<=n && !ok){
			if (!( x > elementosOrdenados[i][n])){
				if (x == elementosOrdenados[i][n])
					ok= true;
				else{
					 int pri=1;
					 int ult=n;
					 int med;
					 while (pri<=ult && !ok){
						med=(pri+ult)/2;
					    ok=elementosOrdenados[i][med]==x;
					    if (!ok){
					    	if(x < elementosOrdenados[i][med])
					    		pri=med+1;
					    	else
					    		ult=med-1;		 
					    }				
					}	
				}
					
			}
			i++;	
		}
		return ok;
	}

}
