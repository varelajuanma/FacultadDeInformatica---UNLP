
package estructurasdedatos;

public class VectorBinario {
	static int n;
	static int[] elementosBinarios;
	
	public static void main(String[] args){
		int []a={1,1,1,0,0,1,0,1,1,0,1,0,1,0,0,1,0};
		System.out.print("Vector original: ");
		for(int i=0;i<=a.length-1;i++)
			System.out.print(a[i]+" ");
		ordenar(a);
		System.out.print("Vector ordenado: ");
		for(int i=0;i<=a.length-1;i++)
			System.out.print(a[i]+" ");
	}		
	
	public static void ordenar(int [] eB){
		int pri,ult;
		pri=0;
		ult= eB.length-1;
		while (pri<=ult){
			if(eB[pri]==1 && eB[ult]==0){
				swap(eB,pri,ult);
				pri++;
				ult--;
			}
			else{
				if (eB[pri]==eB[ult]){
					if (eB[pri]==1)
						ult--;
					else
						pri++;
				}
				else{
					pri++;
					ult--;
				}
			}		
					
		}
	}		
	public static void swap(int[]eB, int a, int b){
		int aux;
		aux=eB[a];
		eB[a]=eB[b];
		eB[b]=aux;	
	}

}
