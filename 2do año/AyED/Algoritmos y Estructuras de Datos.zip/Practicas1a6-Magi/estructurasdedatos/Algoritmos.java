
package estructurasdedatos;
public class Algoritmos {
	public static void randomUno(int n){
		int i,x;
		int []a= new int[n];		
		for (i=1;i<=n;i++){
			int k = 0;
			do{
				k++;
				x= ran_int(1,n);}				            
			while (x == a[k] &&  k<i);	
			a[i]=x;					
		}
	}

	public static void randomDos(int n){
		int i,x;
		int a[];
		boolean used[];
		a=new int[n];
		used= new boolean[n]; 
		for (i=1;i<=n;i++){
			used[i]=false;	
		}
		for(i=1;1<=n;i++){
			do
				x=ran_int(1,n);
			while (used[x] != false);
			a[i]=x;
			used[x]=true;			
		}
	}

	public static void randomTres(int n){
		int i;
		int a[]= null;
		for (i=1;i<=n;i++){
			a[i]=i;
		}
		for(i=2;i<=n;i++){
			swap(a,i,ran_int(1,i));
		}
	}

	public static void swap(int a[],int i,int j){
		int aux;
		aux=a[i];
		a[i]=a[j];
		a[j]=aux;
	}

	private static int ran_int(int i, int n) {
		// TODO Auto-generated method stub
		return 0;
	}

}
