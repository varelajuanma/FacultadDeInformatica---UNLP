
package estructurasdedatos;

public class OrdenArreglo {
	
	public static void main(String [] args){
		int []a= {3,6,7,2,1,5,8,4};
		System.out.print("Vector original: ");
		for(int i =0; i< a.length;i++)
			System.out.print(a[i]+" ");
		System.out.print("\n");
		mergesort(a);
		System.out.print("Vector ordenado: ");
		for(int i =0; i< a.length;i++)
			System.out.print(a[i]+" ");
		System.out.print("\n");
	}
	
	public static void mergesort(int a[]){
		int pri=0;
		int ult=a.length-1;
		mergesort(a,pri,ult);		
	}
		
	private static void mergesort(int []a,int pri,int ult){
		int[]b = new int[a.length];
		if (pri < ult){
			int med= (pri + ult)/2;
			mergesort(a,pri,med);
			mergesort(a,med+1,ult);
			merge(a,pri,med,ult,b);
		}
	}
	private static void merge(int[]a,int pri,int med,int ult,int []b){
		int aux = med +1;
		int i=pri;
		int j=pri;
		while(pri <= med && aux <= ult){
			if (a[pri] < a[aux])
				b[i++]=a[pri++];
			else
				b[i++]= a[aux++];	
		}
		if (pri > med){
			while (aux <= ult)
				b[i++]=a[aux++];	
		}
		else{
			while(pri <= med)
				b[i++]=a[pri++];
		}	
		for(int k=j;k<=ult;k++)
			a[k]=b[k];
	}   
}
