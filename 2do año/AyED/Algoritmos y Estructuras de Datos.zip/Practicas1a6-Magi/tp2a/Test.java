package tp2a;


/*
 * Created on 20/04/2008
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author Sebi
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Test {

	public static void main(String[] args) {
	 Estudiante[] alumnos = new Estudiante[5];
	 Profesor[] profesores= new Profesor[4];
	 for( int i = 0;i<=4;i++){
	 	alumnos[i]= new Estudiante();
	 	alumnos[i].setNombre("Germ�n");
	 	alumnos[i].setApellido("Aquino");
	 	alumnos[i].setComision(2);
	 	alumnos[i].setDireccion("115 e/88 y 89");
	 	alumnos[i].setEmail("geraq07@hotmail.com");
	 }
	 for(int i=0;i<=3;i++){
	 	profesores[i]= new Profesor();
	 	profesores[i].setApellido("Schiavoni");
	 	profesores[i].setCatedra("Algoritmos y Estructuras de Datos");
	 	profesores[i].setFacultad("Facultad de Inform�tica");
	 	profesores[i].setNombre("Alejandra");
	 	profesores[i].setTitulo("Licenciada en Inform�tica");
	 	profesores[i].setEmail("?");
	 	profesores[i].setEdad(0);
	 }
	 for( int i = 0;i<=4;i++){
			 String N= alumnos[i].getNombre();
			 String A =alumnos[i].getApellido();
			 int C = alumnos[i].getComision();
			 String D = alumnos[i].getDireccion();
			 String E = alumnos[i].getEmail();
			 System.out.println(N+" "+A+" "+C+" "+D+" "+E);
		  }
		for(int i=0;i<=3;i++){
			String A =profesores[i].getApellido();
			String C =profesores[i].getCatedra();
			String F =profesores[i].getFacultad();
			String N =profesores[i].getNombre();
			String T =profesores[i].getTitulo();
			String E =profesores[i].getEmail();
			int e =profesores[i].getEdad();
			System.out.println(N+" "+A+" "+e+" "+E+" "+T+" "+F+" "+C);
			 }		
 	}
}
