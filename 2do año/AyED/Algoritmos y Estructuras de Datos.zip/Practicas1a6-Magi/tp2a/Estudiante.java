package tp2a;
/*
 * Created on 20/04/2008
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author Sebi
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Estudiante {
	String nombre;
	String apellido;
	int comision;
	String email;
	String direccion;
		
	public void setNombre(String N){
		nombre= N;	 
	}
	
	public void setApellido(String A){
		apellido = A;
	}
	
	public void setEmail(String E){
			email= E;	 
		}
	public void setDireccion(String D){
		direccion= D;	 
	}
	
	public void setComision(int C){
	comision = C;	 
	}

	public String getNombre(){
		return nombre;
	}		
	
	public String getApellido(){
			return apellido;
		}		
	
		
	public String getEmail(){
			return email;
		}		
	public String getDireccion(){
			return direccion;
		}			
	public int getComision(){
		return comision;
	}
	public String TusDatos(){
		String Datos = this.getNombre() + this.getApellido() + this.getEmail() + this.getDireccion() + this.getComision();
		return Datos;
	}
	
}
		

