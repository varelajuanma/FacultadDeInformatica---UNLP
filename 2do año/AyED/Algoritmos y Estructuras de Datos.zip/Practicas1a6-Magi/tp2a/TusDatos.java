package tp2a;
/*
 * Created on 20/04/2008
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author Sebi
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TusDatos {

	public static void main(String[] args) {
	
		String nombre = args[0];
		String apellido = args[1];
		int codigopostal = 46859;
		String colorFavorito = "Rojo";
		System.out.println("Hola " + nombre +" " + apellido);
		System.out.println("Tu codigo postal es: " + codigopostal);
		System.out.println("Tu color favorito es: " + colorFavorito);
	}

}
