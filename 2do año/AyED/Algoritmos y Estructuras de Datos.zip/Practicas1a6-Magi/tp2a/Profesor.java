package tp2a;
/*
 * Created on 20/04/2008
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author Sebi
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Profesor {
	String Nombre;
	String Apellido;
	int Edad;	
	String Email;
	String Catedra;
	String Titulo;
	String Facultad;
	
	public void setNombre(String N){
		Nombre= N;
	}
	public void setApellido(String A){
			Apellido= A;
		}
	public void setCatedra(String C){
			Catedra= C;
		}
	public void setEmail(String E){
			Email= E;
		}
	public void setTitulo(String T){
			Titulo= T;
		}
	public void setFacultad(String F){
			Facultad= F;
		}
	public void setEdad(int E){
		Edad= E;
	}
	
	public String getNombre(){
		return Nombre;
	}
	public String getApellido(){
			return Apellido;
	}
	public String getEmail(){
			return Email;
		}
	public String getCatedra(){
			return Catedra;
		}
	public String getFacultad(){
			return Facultad;
		}
	public String getTitulo(){
			return Titulo;
		}
	public int getEdad(){
			return Edad;
		}	
	public String TusDatos(){
			String Datos = this.getNombre() + this.getApellido() + this.getEdad() + this.getTitulo()+ this.getEmail() + this.getCatedra() + this.getFacultad();
			return Datos;

}
}