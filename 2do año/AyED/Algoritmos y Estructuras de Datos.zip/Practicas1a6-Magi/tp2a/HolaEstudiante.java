package tp2a;
/*
 * Created on 20/04/2008
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author Germ�n
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class HolaEstudiante {

	public static void main(String[] args) {
		System.out.print("Hola Estudiante "+ args[0] +" "+args[1]);
	}
}
