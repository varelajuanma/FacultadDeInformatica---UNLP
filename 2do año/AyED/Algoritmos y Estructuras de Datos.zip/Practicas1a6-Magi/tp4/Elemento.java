
package tp4;


class Elemento {
	private Object dato;
		private Elemento siguiente=null;
	
		public Object get(){
			return dato;
		}
	
		public Elemento next(){
			return siguiente;
		}
	
		public void set (Object elem){
			dato=elem;
		}
	
		public void setnext(Elemento E){
			siguiente=E;
		}
}
