package tp4;
//http://java.sun.com/j2se/1.4.2/docs/api/ 

public class Empresa {
private ArbolGeneral raiz;

private void contar(ArbolGeneral A, int[] n,int nivel){
	if (A!=null){
		n[nivel]++;
		Lista Hijos= A.getHijos();
		Hijos.begin();
		while(! Hijos.end()){
			ArbolGeneral H= (ArbolGeneral)Hijos.get();
			contar(H,n,nivel+1);
			Hijos.next();
		}
		
	}
}

public Lista trabajadoresPorCategoria(){
	Lista L= new Lista();
	int altura=raiz.altura();
	int nivel=0;
	int []n= new int [altura];
	contar(raiz,n,nivel);
	for (int i=0;i<altura;i++){
		L.add(new Integer(n[i]));
	}
	return L;
	
}

public String categoriaConMasTrabajadores(){
	Lista L= trabajadoresPorCategoria();
	int max= -1;
	L.begin();
	while (!L.end()){
		Integer a= (Integer)L.get();
		int n= a.intValue();
		if (n> max)
			max=n;
		L.next();
	}
	return Integer.toString(max);
}

public int cantidadTotalDeTrabajadores(){
	Lista L= trabajadoresPorCategoria();
	int total=0;
	L.begin();
	while(! L.end()){
		Integer a= (Integer)L.get();
		int n= a.intValue();
		total +=n;
		L.next();
	}
	return total;
}

public void reemplazar(ArbolGeneral A){
	Lista L= A.getHijos();
	if(L != null){
		ArbolGeneral MaxHijo= null;	
		int max=-1;
		L.begin();
		while (! L.end()){
			ArbolGeneral H= (ArbolGeneral)L.get();
			Empleado E= (Empleado)H.getDatoRaiz();
			if(E.getAntiguedad() > max)
				MaxHijo=H;
			L.next();
		}
		Empleado E= (Empleado)MaxHijo.getDatoRaiz();
		A.setDatoRaiz(E);
		reemplazar(MaxHijo);
	}
	else
		A=null;
}

public void reemplazarPresidente(){
	reemplazar(raiz);	
}
}
