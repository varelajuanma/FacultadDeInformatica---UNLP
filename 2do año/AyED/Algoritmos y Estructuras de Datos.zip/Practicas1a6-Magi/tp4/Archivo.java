package tp4;

public class Archivo {
private int tama�o;

public int getTama�o(){
	return tama�o;
}

public void setTama�o(int tama�o) {
	this.tama�o = tama�o;
}





}
