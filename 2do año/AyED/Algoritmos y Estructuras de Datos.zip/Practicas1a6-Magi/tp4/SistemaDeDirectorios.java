package tp4;

public class SistemaDeDirectorios {
private ArbolGeneral raiz;

public Lista archivos(String directorio){
	Lista L= null;
	Directorio Dir= new Directorio(directorio);
	NodoGeneral Nodo= new NodoGeneral(Dir);
	ArbolGeneral Sub= raiz.subArbol(Nodo);
	if (Sub != null){
		Nodo= (NodoGeneral)Sub.getDatoRaiz();
		Dir=(Directorio)Nodo.getDato();
		L= Dir.getArchivos();
	}
	return L;
}

public Lista subdirectorios(String directorio){
	Lista L= null;
	Directorio Dir= new Directorio(directorio);
	NodoGeneral Nodo= new NodoGeneral(Dir);
	ArbolGeneral Sub= raiz.subArbol(Nodo);
	if (Sub != null){
		Nodo= (NodoGeneral)Sub.getDatoRaiz();
		L= Nodo.getHijos();
	}
	return L;
	}

public int tama�o(String directorio){
	int Total=0;
	Lista L= archivos(directorio);
	L.begin();
	while(! L.end()){
		Archivo A= (Archivo)L.get();
		Total+=A.getTama�o();
	}
	return Total;
}

private String BuscarMayorPath(NodoGeneral N,String MaxPath){
	if (N!= null){
		Lista L= N.getHijos();
		Directorio Dir= (Directorio)N.getDato();
		L.begin();
		while (! L.end() ){
			NodoGeneral nodo=(NodoGeneral)L.get();
			String Path= Dir.getNombre()+ BuscarMayorPath(nodo,MaxPath);
			if(Path.length() > MaxPath.length())
				MaxPath=Path;
		}
		return MaxPath;
	}
	else
		return "";
}

public String pathMasLargo(){
	String MaxPath="";
	NodoGeneral N= (NodoGeneral)raiz.getDatoRaiz();
	MaxPath=BuscarMayorPath(N,MaxPath);
	return MaxPath;
}
}