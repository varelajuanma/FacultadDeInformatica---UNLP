package tp4;

public class Cola {
	private ListaPosicional2 Cola= new ListaPosicional2();
	
	public void push(Object elem){
		Cola.add(elem,Cola.size());
	}

	public Object pop(){
		Object elem=Cola.get(0);
		Cola.remove(0);
		return elem;
	}
	
	public int size(){
		return Cola.size();
	}
	
	public boolean isEmpty(){
		return Cola.isEmpty();
	}
	
	public Object top(){
		return Cola.get(0);
	}
	
	public Object bottom(){
		int ultimo = Cola.size()-1;
		return Cola.get(ultimo);
	}
}
