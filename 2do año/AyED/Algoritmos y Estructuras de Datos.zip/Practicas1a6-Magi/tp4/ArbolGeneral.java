
package tp4;
public class ArbolGeneral {
	private NodoGeneral raiz;
	
	public ArbolGeneral(){
		raiz=null;
	}
	
	public ArbolGeneral(Object dato){
		raiz= new NodoGeneral(dato);
	}
	
	public ArbolGeneral(Object dato, Lista hijos){
		raiz=new NodoGeneral(dato);
		Lista L = raiz.getHijos();
		hijos.begin();
		while(! hijos.end()){
			ArbolGeneral A= (ArbolGeneral)hijos.get();
			NodoGeneral nodo= A.getRaiz();
			L.add(nodo);
			hijos.next();			
		}
		raiz.setHijos(L);
	}
	
	private ArbolGeneral(NodoGeneral nodo){
		raiz=nodo;
	}
	
	private NodoGeneral getRaiz(){
		return raiz;
	}
	
	public Object getDatoRaiz(){
		return raiz.getDato(); 
	}
	
	public void setDatoRaiz(Object dato){
		raiz.setDato(dato);
	}
	
	public Lista getHijos(){
		Lista L= new Lista();
		Lista Hijos = raiz.getHijos();
		Hijos.begin();
		while(!Hijos.end()){
			NodoGeneral nodo= (NodoGeneral)Hijos.get();
			ArbolGeneral A=new ArbolGeneral(nodo);
			L.add(A);
			Hijos.next();
		}
		return L;
	}
	
	public void agregarHijo(ArbolGeneral unHijo){
		NodoGeneral nodo= unHijo.getRaiz(); 
		Lista L= raiz.getHijos();
		L.add(nodo);
		raiz.setHijos(L);
	}
	
	public void eliminarHijo(ArbolGeneral unHijo){ 
		NodoGeneral nodo= unHijo.getRaiz();
		Lista L= raiz.getHijos();
		L.remove(nodo);
		raiz.setHijos(L);
	}
	
	private int altura(NodoGeneral nodo){
		if (nodo== null)
			return -1;
		else{
			int max= -1;
			Lista L= nodo.getHijos();
			L.begin();
			while (! L.end()){
				NodoGeneral N= (NodoGeneral)L.get();
				int aux = altura(N);
				if (aux > max)
					max=aux;
				L.next(); 
			}
			return max+1;
		}
	}
	
	public int altura(){
		NodoGeneral nodo= getRaiz();
		return altura(nodo);	
	}
	
	private boolean includes(NodoGeneral nodo,Object O){		
		if (nodo==null || O== null)
			return false;
		else{
		if (nodo.getDato().equals(O))
			return true;
		else{
			Lista L= nodo.getHijos();
			boolean ok= false;
			L.begin();
			while(!L.end() && !ok){
				NodoGeneral N= (NodoGeneral) L.get();
				ok= includes(N,O);
				L.next();
			}
			return ok;
			}
		}
	}
			
	public boolean includes(Object O){
		if(this != null){
		if (O != null){
			NodoGeneral N= getRaiz();
			return includes(N,O);	
		}
		else
			return false;		
	}
		else
			return false; 
	}
	
	private int nivel(NodoGeneral N, Object O){
		if(N.getDato().equals(O))
			return 0;
		else{ 
			Lista L= N.getHijos();
			L.begin();
			boolean ok= false;
			int niv=-1;
			while(! L.end() && !ok){
				NodoGeneral nodo= (NodoGeneral)L.get();
				if(includes(nodo,O)){
					niv= nivel(nodo,O)+1;
					ok=true;
				}
				else
					L.next();
			}
			return niv;
	}
}	
	public int nivel(Object O){
		if (this != null){
			NodoGeneral nodo= getRaiz();
			if(nodo== null || O==null)
			return -1;
			else
				return nivel(nodo,O);
		}
		return -1;
	}
	
	private void ContarNodosPorNivel(NodoGeneral nodo, int[] CantNodos,int Nivel){
	if (nodo != null){
		Lista L= nodo.getHijos();
		L.begin();
		while(!L.end()){
			NodoGeneral N= (NodoGeneral)L.get();
			CantNodos[Nivel+1]++;
			ContarNodosPorNivel(N,CantNodos,Nivel+1);
			L.next();
		}
	}
	}
	
	private int Max(int []a){
		int maximo=-1;
		for(int i=0; i< a.length;i++){
			if (a[i]>maximo)
				maximo=a[i];
	    }
		return maximo;
	}	
	
	public int ancho (){
		if (this!= null){
		NodoGeneral Raiz= getRaiz();
		int niveles = altura(Raiz);
		if(Raiz == null)
			return 0;
		else{
			int [] CantNodos= new int[niveles];
			CantNodos[0]=1;
			for(int i=1; i<= niveles;i++){
				CantNodos[i]=0;
			}
			ContarNodosPorNivel(Raiz,CantNodos,0);
			return Max(CantNodos);
		}
		}
		else
			return 0;
	}
	
	public ArbolGeneral subArbol(Object dato){
		NodoGeneral Nodo= getRaiz();
		return subArbol(Nodo,dato);
	}
	
	private ArbolGeneral subArbol(NodoGeneral N,Object dato){
	ArbolGeneral A= null;
	if (N != null){	
		if (N.getDato().equals(dato))
			A= new ArbolGeneral(N);
		else{
			Lista L= N.getHijos();
			L.begin();
			boolean ok = false;
			while (! L.end()&& !ok){
				NodoGeneral nodo = (NodoGeneral)L.get();
				if (includes(nodo,dato)){
					A = subArbol(nodo,dato);
					ok= true;
				}	
				else
					L.next();
			}
			
		}	
	}
	 return A;  	  
	}

	public boolean esAncestro(Object dato1, Object dato2){
		NodoGeneral Raiz= getRaiz();
		ArbolGeneral A= subArbol(Raiz,dato1);
		return A.includes(dato2);
	}
	
	private boolean recorrer(NodoGeneral Nodo1, NodoGeneral Nodo2){
		if(Nodo1 != null){
			if(Nodo2==null)
				return false;
			else{
				Lista L1= Nodo1.getHijos();
				Lista L2= Nodo2.getHijos();
				int long1=L1.size();
				int long2=L2.size();
				if(long1 != long2)
					return false;
				else{
					L1.begin();
					L2.begin();
					boolean ok= true;
					while(! L1.end() && !L2.end() && ok){
						NodoGeneral n1= (NodoGeneral)L1.get();
						NodoGeneral n2= (NodoGeneral)L2.get();
						ok= recorrer(n1,n2);
						if (ok){
							L1.next();
							L2.next();
						}					
					}
					return ok;
				}
			}
		}
		return (Nodo2==null);
	}
	
	public boolean equals(ArbolGeneral otroArbol){
		if(this != null){ 
			if (otroArbol == null)
				return false;
			else{
				NodoGeneral Nodo1= getRaiz();
				NodoGeneral Nodo2= otroArbol.getRaiz();
				return recorrer(Nodo1,Nodo2);
			}
	   }
		else{
			return (otroArbol==null);
		}
	}
}	

	
					
	
	


