
package tp4;
class NodoGeneral {
	private Object dato;
	private Lista listaHijos;
	
	public NodoGeneral(Object dato){
		this.dato= dato;
		listaHijos=null;
	}
	
	public Object getDato(){
		return dato;
	}
	
	public void setDato(Object dato){
		this.dato=dato;
	}
	
	public Lista getHijos(){
		return listaHijos;
	}
	
	public void setHijos(Lista hijos){
		listaHijos=hijos;
	}
}
