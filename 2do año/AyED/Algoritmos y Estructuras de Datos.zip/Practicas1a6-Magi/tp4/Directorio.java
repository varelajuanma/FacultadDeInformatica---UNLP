package tp4;

public class Directorio {
	private String nombre;
	private Lista listaDeArchivos;
	
	public Directorio(String unNombre){
		nombre=unNombre;
		listaDeArchivos=null;
	}
	
	public String getNombre(){
		return nombre;
	}
	
	public void setNombre(String unNombre){
		nombre= unNombre; 
	}
	
	public Lista getArchivos(){
		return listaDeArchivos;
	}
	
	public void setArchivos(Lista Archivos){
		listaDeArchivos= Archivos;
	}
	
}
