package tp4;

public class Imagen {
	private boolean [][]imagen;
	private int length;

	private Imagen(boolean [][] matriz){
		imagen=matriz;
		length= matriz.length;
	}
	
	public Imagen(){
		
	}
	
	private boolean igualcolor(int FilInic,int FilFin,int ColInic,int ColFin){
		boolean ok;
		if(FilInic == FilFin -1){
			if (imagen[FilInic][FilFin]==imagen[ColInic][FilFin]==imagen[FilInic][ColFin]==imagen[ColInic][ColFin])
				return true;
			else
				return false;
		}
		else{
			ok= igualcolor(FilInic, FilFin/2,ColInic,ColFin/2);
			if (ok){
				ok= igualcolor(FilInic, FilFin/2,ColFin/2+1, ColFin);
				if (ok){
					ok= igualcolor(FilFin/2+1, FilFin,ColInic,ColFin/2);
					if (ok)
						ok= igualcolor(FilFin/2+1, FilFin,ColFin/2+1, ColFin);
				}
			}
			return ok;
		}
	}
	
	public boolean igualcolor(){
		boolean ok;
		int n= imagen.length;	
		if(n>1)
			ok= igualcolor(0,n-1,0,n-1);
		else
			ok=true;
		return ok; 
	}

	public boolean color(){
		return imagen[0][0];
	}
	
	private void copiar(boolean[][]matriz, int IniFil,int FinFil,int IniCol,int FinCol){
		for(int i=IniFil;i<=FinFil;i++){
			for(int j= IniCol; j<= FinCol;j++)
				matriz[i][j]= imagen[i][j];
		}
	}
	
	public Lista dividirEnSubImagenes(){
		boolean[][] matriz;
		Lista L= new Lista();
		Imagen I;
		if(length>1){
			matriz= new boolean[length/2][length/2];			
			copiar(matriz,0,length/2-1,0,length/2-1);
			I= new Imagen(matriz);
			L.add(I);
			copiar(matriz,0,length/2-1,length/2,length-1);
			I= new Imagen(matriz);
			L.add(I);
			copiar(matriz,length/2-1,length-1,0,length/2-1);
			I= new Imagen(matriz);
			L.add(I);
			copiar(matriz,length/2,length-1,length/2-1,length-1);
			I= new Imagen(matriz);
			L.add(I);
		}
		return L;
	}
	
	private void imagenComprimida(ArbolGeneral A){
		ArbolGeneral B;
		Lista L= dividirEnSubImagenes();
		L.begin();
		while (!L.end()){
			Imagen I = (Imagen)L.get();
			if (igualcolor()){
				int a;			
				boolean color= color();			
				if (color)
					a = 1;
				else
					a=0;
				B=new ArbolGeneral(new Integer(a));
			}
			else
				B=I.imagenComprimida();
			A.agregarHijo(B);			
		}		
	}
	
	public ArbolGeneral imagenComprimida(){		
		ArbolGeneral A;
		int a;
		if (igualcolor()){
			boolean color= color();			
			if (color)
				a = 1;
			else
				a=0;
			A=new ArbolGeneral(new Integer(a));			
		}
		else{
			a=-1;
			 A=new ArbolGeneral(new Integer(a));
			imagenComprimida(A);
		}
		return A;
	}
}	