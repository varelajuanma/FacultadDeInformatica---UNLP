package tp4;

public class Empleado {

private String nombre;
private int antiguedad;

public String getNombre(){
	return nombre;
}

public void setNombre(String unNombre){
	nombre= unNombre;
}

public int getAntiguedad(){
	return antiguedad;
}

public void setAntiguedad(int unaAntiguedad){
	antiguedad=unaAntiguedad;
}


}
