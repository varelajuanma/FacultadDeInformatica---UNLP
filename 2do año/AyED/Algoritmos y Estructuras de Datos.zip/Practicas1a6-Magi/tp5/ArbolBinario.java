
package tp5;
import tp4.*;

public class ArbolBinario {
	private NodoBinario raiz;
	
	public ArbolBinario(){	
		raiz=null;
	}
	
	public ArbolBinario(Object dato){		
		raiz= new NodoBinario(dato);
	}
	
	private ArbolBinario(NodoBinario nodo){
		this();
		raiz=nodo;
	}
	
	private NodoBinario getRaiz(){
		return raiz;	
	}
	
	public Object getDatoRaiz(){
		return raiz.getDato(); 
	}
	
	public void setDatoRaiz(Object dato){
		raiz.setDato(dato);
	}
	
	public ArbolBinario getHijoIzquierdo(){
			NodoBinario N= raiz.getHijoIzquierdo();
			return new ArbolBinario(N);
		}
	
	public ArbolBinario getHijoDerecho(){
		NodoBinario N= raiz.getHijoDerecho();
		return new ArbolBinario(N);
	}
	
	public void agregarHijoIzquierdo(ArbolBinario unHijo){
		NodoBinario N= unHijo.getRaiz();
		raiz.setHijoIzquierdo(N);
	}
	
	public void agregarHijoDerecho(ArbolBinario unHijo){
		NodoBinario N= unHijo.getRaiz();
		raiz.setHijoDerecho(N);
	}
	
	public void eliminarHijoIzquierdo(){
		NodoBinario N= null;
		raiz.setHijoIzquierdo(N);
	}
	
	public void eliminarHijoDerecho(){
			NodoBinario N= null;
			raiz.setHijoDerecho(N);
		}
	
	public boolean esHoja(){
		return raiz.esHoja();
	}
	
	//-------------------------------------------------//
	
	private NodoBinario M(ArbolGeneral unArbol,Lista Hijos){
		if(Hijos.end()){
			Object dato= unArbol.getDatoRaiz();
			NodoBinario A= new NodoBinario(dato);
			return A;
		}
		else{
			ArbolGeneral G= (ArbolGeneral)Hijos.get();
			Hijos.next();
			NodoBinario B= new NodoBinario(null);
			Lista L= G.getHijos();
			B.setHijoIzquierdo(M(G,L));
			B.setHijoDerecho(M(unArbol,Hijos));
			return B;
		}
		
	}
	
	public ArbolBinario(ArbolGeneral unArbol){
		Lista L= unArbol.getHijos();
		if(L.isEmpty()){
			Object dato=unArbol.getDatoRaiz();
			raiz=new NodoBinario(dato);			
		}
		else{
			L.begin();
			raiz=M(unArbol,L);
		}
	}
	
	private void recorrer(NodoBinario N,Lista L){
		if(N!= null){
			if(N.esHoja())
				L.add(N.getDato());
			else{
				recorrer(N.getHijoIzquierdo(),L);
				recorrer(N.getHijoDerecho(),L);
			}
		}
	}
	
	public Lista frontera(){
		Lista L=new Lista();
		recorrer(raiz,L);
		return L;
	}
	
	public boolean esIgual(ArbolBinario unArbol){
		if(unArbol != null){
			if(getRaiz()!= null){
				if(unArbol.getRaiz()!= null){
					boolean ok= getDatoRaiz()== unArbol.getDatoRaiz();
					if(ok){
						ok= getHijoIzquierdo().esIgual(unArbol.getHijoIzquierdo());
						if (ok)
							ok= getHijoDerecho().esIgual(unArbol.getHijoDerecho());	   
					}
					return ok;
				}
				else
					return false;
			}
			else
				return (unArbol.getRaiz()==null);
		}
		else
			return false;
	}
	
	public boolean esMenor(ArbolBinario unArbol){
		if(getDatoRaiz()==unArbol.getDatoRaiz()){
			ArbolBinario A= getHijoIzquierdo();
			ArbolBinario B= getHijoDerecho();
			if(A.esIgual(B)){
				A= getHijoIzquierdo();
				B= getHijoDerecho();
				return A.esMenor(B);
			}
			else
				return A.esMenor(B);
		}
		else{
			Integer a= (Integer)getDatoRaiz();
			Integer b=(Integer)unArbol.getDatoRaiz();	
			return (a.intValue()< b.intValue());
		}
	}
	
	private boolean zigzag(boolean dir){
		if(getHijoIzquierdo()==null){
			if(getHijoDerecho()==null)
				return true;
			else{
				if(dir)	/*IZQUIERDA*/
					return getHijoDerecho().zigzag(!dir);
				else
					return false;
			}
		}
		else{
			if(getHijoDerecho()!=null)
				return false;
			else{
				if (!dir)/*DERECHA*/
					return getHijoIzquierdo().zigzag(!dir);
				else
					return false;	
			}
		}
	}
	
	public boolean zigzag(){		//izquierda = true
		boolean dir;				//derecha = false
		if(getHijoDerecho()==null){
			if(getHijoDerecho()==null)
				return false;
			else{
				dir=false;
				return getHijoDerecho().zigzag(!dir);
			}
		}
		else{
			if(getHijoDerecho()!=null)
				return false;
			else{
				dir=true;
				return getHijoIzquierdo().zigzag(!dir);
			}
		}
	}
	
	public void espejo(ArbolBinario A){
		Object dato;
		ArbolBinario I=getHijoIzquierdo();		
		if(I!=null){
			dato= I.getDatoRaiz();
			A.agregarHijoDerecho(new ArbolBinario(dato));
			if(!I.esHoja())
				I.espejo(A.getHijoDerecho());
		}
		ArbolBinario D=getHijoDerecho();		
		if(D!=null){
			dato= D.getDatoRaiz();
			A.agregarHijoIzquierdo(new ArbolBinario(dato));
			if(!D.esHoja())
				D.espejo(A.getHijoIzquierdo());
		}
	}
	
	public ArbolBinario espejo(){
		Object dato=getDatoRaiz();
		ArbolBinario A= new ArbolBinario(dato);
		if (!esHoja())
			espejo(A);
		return A;
	}
	
	private void colorear(boolean color){
		String A,B;
		if(color){	/*NEGRO*/
			A="Blanco";
			B="Negro";
		}
		else{		/*BLANCO*/
			A="Negro";
			B="Blanco";
		}
		ArbolBinario I= getHijoIzquierdo();
		ArbolBinario D= getHijoDerecho();
		if(I != null){
			I.setDatoRaiz(A);
			if(!I.esHoja())
				I.colorear(!color);
		}
		if(D != null){
			D.setDatoRaiz(B);
			if(!D.esHoja())
				D.colorear(!color);
		}
	}
	
	public void colorear(){
		setDatoRaiz(new String("Negro"));  //Negro = true
		if(!esHoja()){					   //Blanco = false
			boolean color=true;
			colorear(!color);
		}
	}
}

