package tp5;

public class ArbolDeExpresion extends ArbolBinario{
	private int pos;
	
	public ArbolDeExpresion (String dato){
		super(dato);
	}
	
	private void convertir(String exp){
		char I,D;
		D=exp.charAt(pos--);
		ArbolDeExpresion Der= new ArbolDeExpresion(Character.toString(D));
		switch(D){
		case '+':
		case '-':
		case '*':
		case '/':
		Der.convertir(exp);	
		}
		I=exp.charAt(pos--);
		ArbolDeExpresion Izq= new ArbolDeExpresion(Character.toString(I));
		switch(I){
		case '+':
		case '-':
		case '*':
		case '/':
		Izq.convertir(exp);	
		}
		agregarHijoDerecho(Der);
		agregarHijoIzquierdo(Izq);		
	}
	
	public ArbolDeExpresion convertirPostFija(String exp){
		pos=exp.length();
		char c= exp.charAt(pos);
		ArbolDeExpresion A= new ArbolDeExpresion( Character.toString(c));
		switch(c){
			case '+':
			case '-':
			case '*':
			case '/':
				convertir(exp);
			break;
		}
		return A;
	}
}
