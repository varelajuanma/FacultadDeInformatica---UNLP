package tp5;

public class DatoMinMax {
	private boolean max;
	private int valor;
	
	public int getValor(){
		return valor;
	}
	
	public void setValor(int valor){
		this.valor=valor;
	}
	
	public boolean esMax(){
		return max;
	}
	
	public void setMax(boolean max){
		this.max=max;
	}
	
	public DatoMinMax(){
	
	}
	
	public DatoMinMax(int valor,boolean max){
		this.valor=valor;
		this.max=max;
	}
}
