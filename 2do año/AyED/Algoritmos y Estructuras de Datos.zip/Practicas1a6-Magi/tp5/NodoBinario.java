
package tp5;


class NodoBinario {
	private Object dato;
	private NodoBinario hijoIzquierdo;
	private NodoBinario hijoDerecho;
	
	public NodoBinario(Object dato){
		this.dato=dato;
		hijoIzquierdo= null;
		hijoDerecho=null;
	}
	
	public NodoBinario getHijoIzquierdo(){
		return hijoIzquierdo;
	}
	
	public NodoBinario getHijoDerecho(){
			return hijoDerecho;
	}
	
	public void setDato(Object dato){
		this.dato=dato;
	}
	
	public void setHijoIzquierdo(NodoBinario unHijo){
			hijoIzquierdo=unHijo;
	}
	
	public void setHijoDerecho(NodoBinario unHijo){
		hijoDerecho=unHijo;
	}
	
	public Object getDato(){
		return dato;
	}
	
	public boolean esHoja(){
		return (getHijoDerecho()==null && getHijoIzquierdo()==null);
	}
}
