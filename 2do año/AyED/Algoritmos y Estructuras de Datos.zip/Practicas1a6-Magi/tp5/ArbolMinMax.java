package tp5;

public class ArbolMinMax {
	private ArbolBinario A;
	
	public int evaluar(){
		return evaluar(A);
	}
	
	private int min(int []a){
		int min=Integer.MAX_VALUE; 
		for (int i:a)
			if (i< min)
				min=i;
		 return min;
	}
	
	private int max(int []a){
		int max=Integer.MIN_VALUE; 
		for (int i:a)
			if (i>max)
				max=i;
		 return max;
	}
	
	private int evaluar(ArbolBinario A){
		DatoMinMax dato=(DatoMinMax)A.getDatoRaiz();
		int valor= dato.getValor();
		if(A.esHoja())
			return valor;
		else{
			int IValor,DValor;
			ArbolBinario I,D;
			I=A.getHijoIzquierdo();
			D=A.getHijoDerecho();
			if(I != null){
				IValor= evaluar(I);
				if(D!=null){
					DValor= evaluar(D);
					int []a= {valor,IValor,DValor};
					if(dato.esMax())		
						return max(a);
					else
						return min(a);
				}
				else{
					int []a= {valor,IValor};
					if(dato.esMax())
						return max(a);
					else
						return min(a);
					}
			}
			else{
				DValor=evaluar(D);
				int []a= {valor,DValor};
				if(dato.esMax())
					return max(a);
				else
					return min(a);
				}
			}
		}
	}

