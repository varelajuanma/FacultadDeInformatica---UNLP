
package tp3;
public class ListaDeStrings2 {
	protected Elemento pri= null;
	protected Elemento ult= null;
	protected Elemento actual;
	protected int longitud=0;
	
	public void begin(){
		actual=pri;
	}
	
	public void next(){
		actual=actual.next();
	}
	
	public boolean end(){
		return actual==null;		
	}
	
	public String get(){
		return actual.get();
	}
	
	public int size(){
			return longitud;
		}
		
	public boolean isEmpty(){
		return pri==null;
	}
	
	public void remove(){
		Elemento Act=pri;
		Elemento Ant=null;
		while(Act!=actual){
			Ant=Act;
			Act=Act.next();
		}
		if(Ant != null)
			Ant.setnext(Act.next());
		else
			pri=Act.next();
		longitud--;
	}
	
	public  boolean includes (String elem){
		boolean ok=false;
		Elemento E=pri;
		while(E!= null && !ok){
			ok=E.get()==elem;
			if(!ok)
				E= E.next();
		}
		return ok;
	}
		
	public void remove(String elem){
		Elemento Act=pri;
		Elemento Ant=null;
		boolean esta=false;
		while(Act!= null && !esta){
			esta=Act.get()==elem;
			if(!esta){
				Ant=Act;
				Act=Act.next();
			}
		}
		if(esta){
			if(Ant !=null)
				Ant.setnext(Act.next());
			else
				pri=Act.next();
			longitud--;
			actual=Act.next();
		}
	}
	
	public void add(String elem){
		Elemento Act=pri;
		Elemento Ant= null;
		while(Act!=actual){
			Ant=Act;
			Act=Act.next();
		}
		Elemento E=new Elemento();
		E.set(elem);
		E.setnext(Act);
		if (Ant != null)
			Ant.setnext(E);
		else
			pri=E;
		longitud++;
		actual=E;
	}
}
