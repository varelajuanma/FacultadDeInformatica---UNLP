
package tp3;
class Elemento {
	String dato;
	Elemento siguiente=null;
	
	public String get(){
		return dato;
	}
	
	public Elemento next(){
		return siguiente;
	}
	
	public void set (String elem){
		dato=elem;
	}
	
	public void setnext(Elemento E){
		siguiente=E;
	}
}
