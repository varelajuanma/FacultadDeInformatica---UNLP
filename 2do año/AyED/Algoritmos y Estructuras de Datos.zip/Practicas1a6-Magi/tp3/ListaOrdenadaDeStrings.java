
package tp3;

public class ListaOrdenadaDeStrings extends ListaDeStrings{

	public boolean includes(String elem){
		int i=0;
		while (i<longitud && Lista[i].compareTo(elem)<0)
			i++;
		if(i<longitud && Lista[i]==elem)
			return true;
		else
			return false;
	}
	
	public void add(String elem){
		if(longitud < Lista.length){
			int i=0;
			while(i < longitud && Lista[i].compareTo(elem)<0)
				i++;
			longitud++;
			for(int j=longitud-1;j>i;j--)
				Lista[j]=Lista[j-1];
			Lista[i]=elem;
		}
	}
	
	public boolean equals(Object O){
		boolean ok=false;
		if (O!=null && O instanceof ListaOrdenadaDeStrings){
			ListaOrdenadaDeStrings L= (ListaOrdenadaDeStrings)O;
			if(this.longitud == L.longitud){
				int i=0;
				while(i< this.longitud && this.Lista[i].equals(L.Lista[i]))
					i++;
				ok= i == this.longitud;	
			}
		}
		return ok;
	}
	public String toString(){
		String Str="";
		for(int i=0;i<longitud;i++)
			Str += Lista[i]+" ";
		return Str;
	}
}
