package tp3;

public class TestBalanceo {
	public static void main(String [] args){		
		boolean ok;
		String Str=args[0];
		System.out.println("String original : "+Str);
		ok= EstaBalanceado(Str);
		if (ok)
			System.out.println("El String est� balanceado.");
		else
			System.out.println("El String no est� balanceado.");
	}
	
	public static boolean EstaBalanceado(String Str){
		PilaDeStrings Pila= new PilaDeStrings();
		boolean ok=true;
		int i=0;
		while(i< Str.length() && ok){
			char C=Str.charAt(i);
			if(C=='(' || C=='[' || C=='{'){
				String S= Character.toString(C);
				Pila.push(S);
			}
			else{
				switch(C){
					case ')': if(Pila.isEmpty() || !Pila.pop().equals("("))
						ok=false;
					break;
					case ']': if(Pila.isEmpty() || !Pila.pop().equals("["))
						ok=false;
					break;
					case '}': if(Pila.isEmpty() || !Pila.pop().equals("{"))
						ok=false;
					break;
				}
			}
			i++;
		}
		return ok && Pila.isEmpty();
		}
}

