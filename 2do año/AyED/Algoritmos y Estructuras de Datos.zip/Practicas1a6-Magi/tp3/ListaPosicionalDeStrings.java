
package tp3;
public class ListaPosicionalDeStrings {
	private String []Lista = new String[100];
	private int actual;
	private int longitud =0;
	
	public void begin(){
		actual=0;
	}
	
	public void next(){
		actual++;
	}
	
	public boolean end(){
		return actual==longitud;
	}
	
	public String get(){
		return Lista[actual];
	}
	
	public String get(int pos){
		return Lista[pos];
	}
	
	public boolean isEmpty(){
		return longitud==0;
	}
	
	public int size(){
		return longitud;
	}
	
	public boolean add(String elem, int pos){
		if(longitud ==Lista.length || pos <0 || pos > longitud)
			return false;
		else{
			longitud++;
			for(int i=longitud-1; i>pos; i--)
				Lista[i]=Lista[i-1];
			Lista[pos]= elem;
			return true;
		}
	}
	
	public void remove (int pos){
		for(int i=pos ; i <= longitud-1;i++)
			Lista[i]=Lista[i+1];
		longitud--;
	}
	
	public void remove(){
		remove(actual);
	}
	
	public boolean includes(String elem){
		boolean ok=false;
		int i=0;
		while (i<=longitud-1 && !ok){
			if(Lista[i]== elem)
				ok=true;
			else
				i++;
		}
		return ok;		
	}
}

