
package tp3;
public class ListaOrdenadaDeStrings2 extends ListaDeStrings2{


	public boolean includes(String elem){
		Elemento E= pri;
		while(E!= null && E.get().compareTo(elem)<0)
			E=E.next();
		if(E!=null && E.get().equals(elem))
			return true;
		else
			return false;
	}
	
	public void add (String elem){
		Elemento Act=pri;
		Elemento Ant=null;
		while(Act != null && Act.get().compareTo(elem)<0){
			Ant=Act;
			Act=Act.next();
		}
		Elemento E= new Elemento();
		E.set(elem);
		E.setnext(Act);
		if (Ant != null)
			Ant.setnext(E);
		else
			pri=E;
		longitud++;
		actual=E;
	}
	
	public boolean equals(Object O){
		boolean ok=false;
		if(O != null&& O instanceof ListaOrdenadaDeStrings2){
			ListaOrdenadaDeStrings2 L= (ListaOrdenadaDeStrings2)O;
			if(longitud == L.longitud){
				Elemento a= this.pri;
				Elemento b= L.pri;
				while(a!= null && b!= null && a.get().equals(b.get())){
					a=a.next();
					b=b.next();
				}
				ok= a==null;
			}
			
		}
		return ok;
	}
	
	public String toString(){
		String Str="";
		Elemento E=pri;
		while(E!= null){
			Str+=E.get()+" ";
			E=E.next();
		}
		return Str;
	}
}
