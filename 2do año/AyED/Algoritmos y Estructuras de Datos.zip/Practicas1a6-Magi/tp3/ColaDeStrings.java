
package tp3;
public class ColaDeStrings {
	private ListaPosicionalDeStrings Cola=new ListaPosicionalDeStrings();
	
	public void push(String elem){
		Cola.add(elem,Cola.size());
	}

	public String pop(){
		String elem=Cola.get(0);
		Cola.remove(0);
		return elem;
	}
	
	public int size(){
		return Cola.size();
	}
	
	public boolean isEmpty(){
		return Cola.isEmpty();
	}
	
	public String top(){
		return Cola.get(0);
	}
	
	public String bottom(){
		int ultimo = Cola.size()-1;
		return Cola.get(ultimo);
	}
}
