
package tp3;
public class PilaMin extends PilaDeStrings{
	PilaDeStrings Min= new PilaDeStrings();
	
	public void push(String elem){
		super.push(elem);
		if (Min.isEmpty() || elem.compareTo(Min.top())<0)
			Min.push(elem); 
	}
	
	public String min(){
		return Min.top();
	}
	
	public String pop(){
		String elem;
		elem= super.pop();
		if (elem == Min.top())
			Min.pop();
		return elem;
	}
}
