
package tp3;
public class ListaPosicionalDeStrings2 {
	private Elemento pri= null;
	private Elemento actual;
	private int longitud=0;
	
	public void begin(){
		actual=pri;
	}
	
	public void next(){
		actual=actual.next();
	}
	
	public boolean end(){
		return actual==null;		
	}
	
	public String get(){
		return actual.get();
	}
	
	public String get(int pos){
		int num=0;
		Elemento E=pri;
		while(num <pos){
			E=E.next();
			num++;
		}
		return E.get();
	}
	
	public boolean add(String elem,int pos){
		if (pos <0 || pos > longitud)
			return false;
		else{
			int num=0;
			Elemento Act= pri;
			Elemento Ant= null;
			while (num <pos){
				Ant=Act;
				Act=Act.next();
				num++;
			}
			Elemento E= new Elemento();
			E.set(elem);
			E.setnext(Act);
			if (Ant != null)
				Ant.setnext(E);
			else
				pri=E;
			longitud++;
			return true;
		}
	}
	
	public void remove(){
		Elemento Act= pri;
		Elemento Ant=null;
		while(Act!=actual){
			Ant=Act;
			Act=Act.next();
		}
		if (Ant!= null)
			Ant.setnext(Act.next());
		else
			pri= Act.next();
		longitud--;
	}
	
	public int size(){
		return longitud;
	}
	
	public void remove(int pos){
		int num=0;
		Elemento Act=pri;
		Elemento Ant=null;
		while(num < pos){
			Ant=Act;
			Act=Act.next();
			num++;		
		}
		if (Ant!=null)
			Ant.setnext(Act.next());
		else
			pri=Act.next();
			longitud--;
	}
	public boolean includes(String elem){
		boolean ok = false;
		Elemento E=pri;
		while(E!=null && !ok){
			ok=E.get()==elem;
			if (!ok)
				E=E.next();
		}
		return ok;
	}
	
	public boolean isEmpty(){
		return pri==null;
	}
}
