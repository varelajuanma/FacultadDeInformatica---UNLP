
package tp3;
public class TestPila {

	public static void main(String[] args) {
		PilaDeStrings p1,p2;
		String valor2;
		p1=new PilaDeStrings();
		p1.push("1");
		p1.push("2");
		p2=p1;
		valor2=p2.pop();
		System.out.println("El valor del tope de la pila es: "+p1.pop());	
	
	/*ListaPosicionalDeStrings2 a= new ListaPosicionalDeStrings2();
	for(int i=0; i<=3;i++)
		a.add(Integer.toString(i+1),i);
	a.begin();
	for(int i=0; i<=3;i++)
		System.out.print( a.get(i)+" ");
	if(!a.isEmpty())
		System.out.println("Todavia tiene");
	a.begin();
	a.next();
	a.remove();
	a.begin();
	while(!a.end()){
		System.out.print( a.get()+" ");
		a.next();
	}	
	}	*/
}
}