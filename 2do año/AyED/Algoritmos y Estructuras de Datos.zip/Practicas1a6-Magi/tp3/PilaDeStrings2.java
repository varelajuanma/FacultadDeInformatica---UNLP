package tp3;

public class PilaDeStrings2 {
	private ListaPosicionalDeStrings Pila=new ListaPosicionalDeStrings();
    //private ListaPosicionalDeStrings2 Pila=new ListaPosicionalDeStrings2();
	
	public void push(String elem){
		Pila.add(elem,0);
	}
	
	public String pop(){
		String elem = Pila.get(0);
		Pila.remove(0);
		return elem;
	}
	
	public int size(){
		return Pila.size();
	}
	
	public boolean isEmpty(){
		return Pila.isEmpty();
	}
	
	public String top(){
		return Pila.get(0);
	}
}


