
package tp3;
public class ListaDeStrings {
	protected String []Lista = new String[100];
	protected int actual;
	protected int longitud =0;
	
	public void begin(){
			actual=0;
	}
	
	public void next(){
		actual++;
	}
	
	public boolean end(){
		return actual==longitud;
	}
	
	public String get(){
		return Lista[actual];
	}
	
	public boolean isEmpty(){
		return longitud==0;
	}
	
	public int size(){
		return longitud;
	}
	
	public boolean includes(String elem){
		boolean ok=false;
		int i=0;
		while (i<longitud && !ok){
			ok= Lista[i]== elem;
			if(!ok)
				i++;
		}
		return ok;		
	}
	
	public void remove(){
		for(int i = actual; i<longitud-1;i++)
			Lista[i]= Lista[i+1];
		longitud--;	
	}
	
	public void remove(String elem){
		int i=0;
		boolean esta=false;
		while(i<longitud-1 && !esta){
			esta= Lista[i]==elem;
			if(!esta)
				i++;
		}
		if(esta){
			for(int j=i;j<longitud-1;j++)
				Lista[j]=Lista[j+1];
			longitud--;
		}
	}
	
	public void add(String elem){
		if(longitud < Lista.length){
			longitud++;
			for(int i=longitud-1;i>actual;i--)
				Lista[i]=Lista[i-1];
			Lista[actual]=elem;
		}
	}
}

