
package tp3;
public class PilaDeStrings {
	private ListaPosicionalDeStrings Pila=new ListaPosicionalDeStrings();
    //private ListaPosicionalDeStrings2 Pila=new ListaPosicionalDeStrings2();
	
	public void push(String elem){
		Pila.add(elem,Pila.size());
	}
	
	public String pop(){
		int ultimo=Pila.size()-1;
		String elem = Pila.get(ultimo);
		Pila.remove(ultimo);
		return elem;
	}
	
	public int size(){
		return Pila.size();
	}
	
	public boolean isEmpty(){
		return Pila.isEmpty();
	}
	
	public String top(){
		int ultimo= Pila.size()-1;
		return Pila.get(ultimo);
	}
}
