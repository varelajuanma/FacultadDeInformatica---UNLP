package tp3;

public class TestListaOrdenada {
	
	public static void main(String [] args){
		ListaOrdenadaDeStrings2 L1= new ListaOrdenadaDeStrings2();
		L1.add("Programaci�n");
		L1.add("Organizaci�n");
		L1.add("Matem�tica II");
		L1.add("Arquitectura");
		L1.add("Ingl�s");
		L1.add("Matem�tica I");
		L1.add("Seminario de Lenguajes");
		L1.add("Introducci�n a las Bases de Datos");
		L1.add("Algoritmos y Estructuras de Datos");
		L1.add("Matem�tica III");
		L1.begin();
		for(int i=1;i<= L1.size();i++){
			System.out.println(L1.get());
			L1.next();
		}
		L1.begin();
		ListaOrdenadaDeStrings2 L2= new ListaOrdenadaDeStrings2();
		L2.add("Programaci�n");
		L2.add("Organizaci�n");
		L2.add("Matem�tica II");
		L2.add("Arquitectura");
		L2.add("Ingl�s");
		L2.add("Matem�tica I");
		L2.add("Seminario de Lenguajes");
		L2.add("Introducci�n a las Bases de Datos");
		L2.add("Algoritmos y Estructuras de Datos");
		L2.add("Matem�tica III");
		L2.begin();
		if (L1.equals(L2))
			System.out.println("Son iguales");
		else
			System.out.println("No son iguales");
		System.out.println(L1);
		System.out.println(L2);
		
	}	
}
