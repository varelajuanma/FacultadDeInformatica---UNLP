public class ArbolBinario<T>{
  public boolean esVacio(){
    return this.getRaiz()==null; 
  }
  public boolean tieneHijoIzquierdo(){
    return this.getHijoIzquierdo != null;
  }
  public boolean tieneHijoDerecho(){
    return this.getHijoDerecho !=null;
  }
  public boolean esHoja(){
    return ((!tieneHijoIzquierdo)&&(!tieneHijoDerecho));
  }
}

public class Pos{
  private String pregunta;
  private int resultado;
  private int posicion;
  
  public int getResultado(){
    return resultado;
  }
  public int getPosicion(){
    return posicion;
  }
} 

public class Examen{
   public ListaEnlazadaGenerica<int> ejercicioDos(ListaEnlazadaGenerica<ArbolBinario<Pos>> camino,ArbolBinario<Pos> arbol){
    if(arbol.esVacio()){
	  return null;
	}
    ArbolBinario<Pos> aux = new ArbolBinario<Pos>();
    aux = camino.elemento(camino.tamanio()-1); //en aux me quedo con el subArbol que tiene como raiz el ultimo elemento de camino
    ListaEnlazadaGenerica<ArbolBinario<Pos>> lista = new ListaEnlazadaGenerica<ArbolBinario<Pos>>();
    armarLista (aux,lista);  //carga en lista todas las hojas del subArbol aux
    MaxHeap heap = new MaxHeap(lista); //creo una MaxHeap a la que le paso la lista de hojas del SubArbol
    ListaEnlazadaGenerica<int> listaDev = new ListaEnlazadaGenerica<int>(); //creo la lista a devolver
    for (int i=1, i<=3, i++){
	   listaDev.agregar(heap.eliminar().getDatoRaiz().getPosicion(),listaDev.tamanio()); // agrego a listaDev las tres primeras posiciones 
	}
    return listaDev;	
   }
   
   private void armarLista (ArbolBinario<Pos> aux,ListaEnlazadaGenerica<ArbolBinario<Pos>> lista){
     if(aux.esHoja()){
	    lista.agregar(aux);
	 }
	 if(aux.tieneHijoIzquierdo()){
	    armarLista(aux.getHijoIzquierdo(),lista);
	 }
	 if(aux.tieneHijoDerecho()){
	   armarLista(aux.getHijoDerecho(),lista);
	 }
   }
}
