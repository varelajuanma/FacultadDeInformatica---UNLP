public ListaGenerica <Vertice <T>> caminoLargo (grafo <t> grafo){
int maximo=-1;
int aux=0;
ListaGenerica<Vertice <T> > actual=new ListaGenerica<Vertice <T>>;
ListaGenerica<Vertice <T> > largo=new ListaGenerica<Vertice <T>>;
boolean [] marca =new boolean marca[grafo.listaDeVertices.tamanio];
for (int i=0 ; i <grafo.ListaDeVertices().tamanio(); i++)
{ if (!marca[i]){
     marca[i]=true;
	 actual=null; //colocamos la lista y el contador de vertices en null y 0 respectivamente para cada llamada al dfs.
	 aux=0;
     dfs (i,grafo,largo,actual,aux,maximo,marca)
	 marca[i]=false;}
}
return largo
}

private void dfs ( int i , Grafo <t> grafo, ListaGenerica <vertice <T>> largo,  ListaGenerica <vertice <T>> actual, int aux,int maximo, boolean [] marca){
vertice <v> V= grafo.ListaDeVertices().Elemento(i);
ListaGenerica<aristas <T> ady= grafo.ListaDeAdyacentes (v);
ady.comenzar ()
aux ++;
actual.agregar (v);
while(!ady.fin()){
   int j=ady.elemento().getVerticeDestino()
   if (!marca[j]){
      marca[j]=true;
	  dfs(j,grafo,largo,actual,aux,maximo,marca)
	  aux--;
	  actual.eliminar (v) // se elimina el ultimo elemento que agrego.
	  marca[j]=false;
   }  
   ady.proximo();
}
if (aux >max){
    max=aux;
    largo=actual;	
}
}
 

	 