//main basico para resolucion de grafos tipo: Grafo no dirigido conexo pesado
public ListaEnlazadaGenerica<Vertice<Sitios>> Mafia(Grafo G){	
	 boolean[] visitados = new boolean[grafo.listaDeVertices().tamanio()];
		//preparar camino actual y minimo de tipo LuistaEnlazadaGenerica de vertices que, en este caso, son de Sitios.	
		ListaEnlazadaGenerica<Vertice<Sitios>> caminoActual = new ListaEnlazadaGenerica<Vertice<Sitios>>();
		ListaEnlazadaGenerica<Vertice<Sitios>> caminoAdevolver = new ListaEnlazadaGenerica<Vertice<Sitios>>();
		
		//En caso de ser necesario se inicializan los contadores actual y minimo/maximo
		//por si tienen peso las arista y/o vertices.
		//los contadores conviene armarlos con un arreglo de 1 posicion para poder 
		//pasarlos como referencia (peque�a ma�a de java).
		int[] actual= {0};
		int[] minimo={9999};
		
		//Creamos los vertices de partida y destino los buscamos con la funcion
		//buscarVertice, enviandole le grafo y el identificador del vertice en cuestion.
		//Si nos proporcionan los vertices d partida y destino solo los asignamos.
		Vertice<Sitios> casadelintendente = buscarVertice(grafo,"Casa del Intendente");
		Vertice<Sitios> municipalidad = buscarVertice(grafo,"Municipalidad");
		
		//Teniendo todo listo llamamos a la funcion encargada de resolver el problema
		//problema: buscar camino minimo, menos peso, etc...
		//sobra aclarar que la funcion encargada, en este caso dfs, no devuelve nada ya que estamos manipulando
		//objetos, y son alterados dentro de la memoria heap, manteniendo los cambios realizados al regresar.
		dfs (visitados,caminoActual,caminoAdevolver,actual,minimo,casadelintendente,municipalidad,grafo);
		
		//una vez que nuestra funcion termine, devolvemos el resultado.
		return caminoAdevolver;
}

//Buscamos en la lista de vertices del grafo, el vertice que nos interese pasandole el grafo entero 
//y el identificador que buscamos.
private Vertice<Sitios> buscarVertice (Grafo<Sitios> grafo, String lugar){
	//Guardamos en una variable la lista de vertices del grafo y nos paramos al comienzo de la misma.
	ListaGenerica<Vertice<Sitios>> vertices = grafo.listaDeVertices();
	vertices.comenzar();
	
	//mientras no encontremos el vertice en cuestion, avanzamos en la lista
	//una vez encontrado retornamos dicho vertice.
	//si no existe devolvemos null
	while (!vertices.fin()){
		Vertice<Sitios> v = vertices.elemento();
		if(v.getDato().getNombre().equals(lugar))
	    return v;
		vertices.proximo(); 	   
	}
	return null;
}

public class Sitio{
	public String nombre;
	public int mafia;
	//asumimos que los getters y settest estan creados.
}

//Funcion encargada de laburar.
//Recive por parametro todo lo que preparamos en el comienzo.
private void dfs (boolean[] visi,ListaEnlazadaGenerica<Vertice<Sitios>> camAct,ListaEnlazadaGenerica<Vertice<Sitios>> camAdevol,
					int[] act,int[] min,Vertice<Sitios> posAct,Vertice<Sitios> destino,Grafo<Sitios> grafo){
		
		//Si no estamos en el vertice destino:
	  if (posAct != destino){
		//marcamos como visitado el vertice actual.
		visi[posAct.getPosicion()]=true;
		//incrementamos el contador actual con el peso del vertice actual.
		act[0]=act[0] + posAct.getDato().getMafia();
		//agregamos al camino actual en la ultima posici�n el vertice en el que estamos
		camAct.agregar(posAct,camAct.tamanio());
		//Creamos una lista de las aristas que tiene el vertice actual.
		//y nos paramos al principio de esta
		ListaGenerica<Arista<Sitios>> ady = grafo.listaDeAdyacentes(posAct);
		ady.comenzar();
		//mientras no lleguemos al fin de esta lista de aristas, avanzamos sobre la misma.
		while(!ady.fin()){
		   //si el vertice al que apunta esta arista no esta visitado entramos.
		   if(!visi[ady.elemento().getVerticeDestino().getPosicion()]){
			//incrementamos el contador actual con el peso de la arista actual.
		   act[0]=act[0] + ady.elemento().getPeso();
				//llamamos recursivamente a DFS con todos los parametros que recivimos, cambiando posAct por el 
				//vertice destino de la arista en la que nos encontramos.
			 dfs(visi,camAct,camMin,act,min,ady.elemento().getVerticeDestino(),muni,grafo);
			 
				//una vez que regresamos de la recursion, deshacemos los cambios que hicimos antes
				//restamos al contador actual el peso de la arista y del vertice (por si tenian mafia).
			 act[0]=act[0] - ady.elemento().getPeso();
			 act[0]=act[0] - posAct.getDato().getMafia();
				//lo ponemos como "no visitado".
			 visi[posAct.getPosicion()]=false;
			 //y lo eliminamos del camino actual (asumiendo que esta en la ultima posici�n)
			 camAct.eliminar(camAct.tamanio()-1);		 
		   }
		   //proxima arista.
		   ady.proximo();
		}
	 }
	 //Si llegamos al vertice destino
	  else{
			//Agregamos el vertice en el que estamos al camino actual.
		  camAct.agregar(posAct,camAct.tamanio());

		   
		   //Si el contador actual es menos al minimo
		   //(si el camino actual tiene menos mafias que el camino a devolver
			if(act[0]<min[0]){
			//actualizamos contador
			  min[0]=act[0];
			  //Clonamos el camino actual y lo guardamos en camino a devolver
			  camAdevol=(ListaEnlazadaGenerica<Vertice<Sitios>>) camAct.clone();			  
			  
			  
			//como no sabemos usar el clone esta es una forma de clonarlo.
			
			//  while(!camAdevol.esVacia()){
			//	  camAdevol.eliminar(camAdevol.tamanio()-1);
			//  }
			//  camAct.comenzar();
			//  while(!camAct.fin()){
			//	  camAdevol.agregar(camAct.elemento(), camAdevol.tamanio());
			//	  camAct.proximo();
			// }
		
			  
			}
		  }
}