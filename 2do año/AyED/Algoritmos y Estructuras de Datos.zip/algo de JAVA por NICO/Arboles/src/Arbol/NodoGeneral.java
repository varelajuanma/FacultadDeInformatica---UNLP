package Arbol;
import ListaGeneral.Lista;
public class NodoGeneral {

private Object dato;
private Lista listahijos;

    public NodoGeneral(Object dato){
    	this.setDato(dato);
    }

	public void setDato(Object o) {
		dato = o;
	}
	
	public Object getDato() {
		return dato;
	}
	
	public Lista getHijos(){
		return this.listahijos;
	}
	
	public void setHijos(Lista hij){
		this.listahijos.setInicial(hij.getInicial());
	}

	public int altura(){
		if (this.getHijos().isEmpty()){
			return 0;
		}else{
			int h;
			int max=0;
			this.listahijos.begin();
			while(!this.listahijos.end()){
				NodoGeneral n = (NodoGeneral) this.listahijos.get();
				h = n.altura();
				if (max < h)
					max=h;
				this.listahijos.next();
			}
			return max +1;
		}
	}
	//arreglar include, termina el el primer nivel
	public boolean include(Object o){
		if (this.getHijos().isEmpty()){
			return false;
		}else{
			boolean encontre=false;
			this.listahijos.begin();
			while((!this.listahijos.end())&&(!encontre)){
				NodoGeneral n = (NodoGeneral) this.listahijos.get();
				encontre = (n.getDato()== o);
				this.listahijos.next();
			}
			return encontre;
		}
	}
	
	
//*	public int nivel(){
//		if (this.getHijos().isEmpty()){
//			return -1;
//		}else{
//			int niv;
//			int max=0;
//			this.listahijos.begin();
//			if (!this.listahijos.end()) do{
//				NodoGeneral n = (NodoGeneral) this.listahijos.get();
//				niv = n.nivel();
//				if (max < h)
//					max=h;
//				this.listahijos.next();
//			}while((!this.listahijos.end())&& ) );
//			return max +1;
//		}
	}
	

