package Arbol;

public class NodoArbol {
		private Object dato;
		private NodoArbol hder,hizq;
		public Object getDato() {
			return dato;
		}
		public NodoArbol getHder() {
			return hder;
		}
		public NodoArbol getHizq() {
			return hizq;
		}
		public void setDato(Object o) {
			dato = o;
		}
		public void setHder(NodoArbol der) {
			hder = der;
		}
		public void setHizq(NodoArbol izq) {
			hizq = izq;
		}
		
	}

