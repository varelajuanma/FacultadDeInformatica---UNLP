package Arbol;
import ListaGeneral.Lista;

public class ArbolGeneral {
	private NodoGeneral raiz;
	
	public ArbolGeneral(){
		this.raiz=null;
	}
	
	public ArbolGeneral(Object dato){
		this.raiz=new NodoGeneral(dato);
	}
	
	/*public ArbolGeneral(Object dat, Lista hijos){
		this.raiz=new NodoGeneral(dat);
		ArbolGeneral aux;
		hijos.begin();
		while (!hijos.end()) {
			aux = (ArbolGeneral) hijos.get();	
			this.getRaiz().getHijos().add(aux.getRaiz());
			hijos.next();
		}
		}
	*/

	private NodoGeneral getRaiz(){
		return raiz;
	}
	
	public Object getDatoRaiz(){
		return this.raiz.getDato();
	}
	
	public Lista getHijos(){
		return raiz.getHijos();
	}
	
	/*public void agregarHijo(ArbolGeneral unHijo){
		this.getRaiz().getHijos().add(unHijo);
	}
	
	public void eliminarHijo(ArbolGeneral unHijo){
		this.getRaiz().getHijos().remove(unHijo.getRaiz());
	}
	*/
	public int altura(){
		return this.raiz.altura();
	}
	public boolean include(Object o){
		if (this.raiz.getDato()==o) return true;
		else return this.raiz.include(o);
	}
	
}
