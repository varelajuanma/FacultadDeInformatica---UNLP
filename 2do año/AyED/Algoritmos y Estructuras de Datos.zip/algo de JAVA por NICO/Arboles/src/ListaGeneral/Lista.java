package ListaGeneral;

public class Lista {


    private NodoLista inicial,act;
	
	public NodoLista getAct() {
		return act;
	}
	public NodoLista getInicial() {
		return inicial;
	}
	
	public NodoLista getAnt(){
	NodoLista N=new NodoLista();
	N=this.inicial;
	while (N.getSig()!=this.act)
		N=N.getSig();
	return N;
	}
	
	public void setAct(NodoLista nodo) {
		act = nodo;
	}
	public void setInicial(NodoLista nodo) {
		inicial = nodo;
	}
	public void begin(){
		this.act=this.inicial;
	}
	public void next(){
		
        this.act=act.getSig();
	}
	public boolean end(){
		if (this.act== null){
			return true;
		}else{
			return false;
		}
	}
	public Object get(){
		
        return this.act.getDato();
	}
	public Object get(int x){
		for (int i=0;i<x;i++){
			this.next();
		}
		return act.getDato();
	}
	public boolean add (Object args,int pos){
		NodoLista nodo=new NodoLista();
		nodo.setDato(args);
		int posact=0;
		this.begin();
		if (pos==0){
			nodo.setSig(this.act);
			this.setInicial(nodo);
			return true;
		}else{
			while((!this.end())&& ((pos-1)!=posact))
			{
				this.next();
				posact++;
			}if((pos-1)==posact){
				nodo.setSig(this.act.getSig());
				act.setSig(nodo);
				return true;	}
			else {
					return false;
				}}
	}
	public void remove(){
		if (act==inicial)
		{
			this.setInicial(inicial.getSig());
		}else{
			NodoLista aux= new NodoLista();
			aux=this.getAnt();
			aux.setSig(act.getSig());
		}
	}
	public void remove(int pos){
		if (pos==0)
		{
			this.setInicial(inicial.getSig());
		}else{
			this.begin();
			for(int i=0;i<pos;i++){
			this.next();
			}
			NodoLista aux= new NodoLista();
			aux=this.getAnt();
			aux.setSig(act.getSig());
		}
	}
	public void remove(Object elem){
		if (this.includes(elem)) {this.remove();}
	}
	public boolean isEmpty(){
		return inicial==null;
	}
	public boolean includes(Object elem){
		this.begin();
		while((!this.end())&&(act.getDato()!=elem)){
			this.next();
		}
		return (act.getDato()==elem);
		
	}
	public int size(){
		Lista L=new Lista();
		L=this;
		int cant=0;
		while(!L.end()){
			cant++;
			L.next();
		}
		cant++;
		return cant;
	}
	
    
	
}
	

