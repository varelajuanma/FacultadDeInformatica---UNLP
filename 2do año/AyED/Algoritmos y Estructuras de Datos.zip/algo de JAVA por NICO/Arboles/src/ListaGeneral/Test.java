package ListaGeneral;

public class Test {

public static void main(String[] args){
 Lista L=new Lista();
 //String J= new String();
L.add( "Robertito ",0 );
L.add("Jorgito ",1);
L.add("Pedrito ", 0);
L.remove(1);
L.begin();
while (!L.end()){
	System.out.print(L.get());
	L.next();
	}

}
}