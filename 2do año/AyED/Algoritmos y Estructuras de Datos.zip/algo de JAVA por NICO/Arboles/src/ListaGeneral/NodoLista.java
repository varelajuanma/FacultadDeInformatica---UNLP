package ListaGeneral;

public class NodoLista {
		private Object dato;
		private NodoLista sig;

		public Object getDato() {
			return dato;
		}
		public NodoLista getSig() {
			return sig;
		}
		public void setDato(Object o) {
			dato = o;
		}
		public void setSig(NodoLista nodo) {
			sig = nodo;
		}
		
	}

