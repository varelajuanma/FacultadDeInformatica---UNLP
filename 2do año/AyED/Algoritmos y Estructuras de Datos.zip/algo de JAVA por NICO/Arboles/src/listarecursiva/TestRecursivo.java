/*package listarecursiva;

public class TestRecursivo {


	public static void main (String[] args) {
		ListaPosicionalDeString lis=new ListaPosicionalDeString();
		ListaString lis2=new ListaString();
		lis.add("a", 0);
		lis.add("b", 1);
		lis.add("c", 2);
		lis.add("d", 3);
		lis2.add("00", 0);
		lis2.add("01", 1);
		lis2.add("03", 2);
		lis2.add("04", 3);
		lis.begin();
		lis2.begin();
		for (int i=0;i<lis2.size();i++){
			System.out.println(lis2.get());
			lis2.next();
		}

		System.out.println("...insertando el 2...");
		lis2.add("02");
		lis2.begin();
		for (int i=0;i<lis2.size();i++){
			System.out.println(lis2.get());
			lis2.next();
		}
		System.out.println("y ahora el 8...");
		lis2.add("08");
		lis2.begin();
		for (int i=0;i<lis2.size();i++){
			System.out.println(lis2.get());
			lis2.next();
		}
	}
}
*/