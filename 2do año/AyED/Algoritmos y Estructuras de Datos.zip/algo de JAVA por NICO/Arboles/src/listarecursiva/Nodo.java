

package listarecursiva;

public class Nodo {
	private String dato;
	private Nodo sig;
	
	public String getDato() {
		return dato;
	}
	public Nodo getSig() {
		return sig;
	}
	public void setDato(String string) {
		dato = string;
	}
	public void setSig(Nodo nodo) {
		sig = nodo;
	}
	
}
