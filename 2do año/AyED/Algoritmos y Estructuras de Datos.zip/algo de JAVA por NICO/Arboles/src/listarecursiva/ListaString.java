package listarecursiva;

public class ListaString extends ListaPosicionalDeString {

	public boolean add (String args,int pos){
		Nodo nodo=new Nodo();
		nodo.setDato(args);
		int posact=0;
		this.begin();
		if (pos==0){
			nodo.setSig(this.act);
			this.setInicial(nodo);
			return true;
		}else{
			while((act.getSig()!=null)&& ((pos-1)!=posact))
			{
				this.next();
				posact++;
			}if((pos-1)==posact){
				nodo.setSig(this.act.getSig());
				act.setSig(nodo);
				return true;}
			else {
					this.begin();
					nodo.setSig(this.act);
					this.setInicial(nodo);
					return true;
				}}
	}

		public void remove(String elem){
			boolean encontre=false;
			Nodo n=new Nodo();
			n=this.getInicial();
			if (n.getDato() == elem){
				encontre=true;n=n.getSig();
			}else{
				while((n.getSig()!= null)&&(!(encontre)));{
					encontre=(n.getSig().getDato()==elem);
					if (!encontre)n=n.getSig();}
				if (encontre) {n.setSig(n.getSig().getSig());}
			}
			if(!encontre) {System.out.println("No se pudo borrar el string.");}

		}

public void add (String args){
	Nodo nodo=new Nodo();
	nodo.setDato(args);
	this.begin();
	if (args.compareTo(this.act.getDato()) < 0)
	{//el string a insertar es menor al primer elemento de la lista
		nodo.setSig(this.act);
		this.setInicial(nodo);
	
	}else{
		while(((act.getSig()!=null)&& (args.compareTo(act.getSig().getDato()) > 0)))
		{
			this.next();
			
		}if(act.getSig()==null){
			nodo.setSig(null);
			act.setSig(nodo);
		}
		else {
				nodo.setSig(this.act.getSig());
				act.setSig(nodo);
			}}
}
}
