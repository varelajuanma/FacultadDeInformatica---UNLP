package listarecursiva;

public class ListaPosicionalDeString {
    public Nodo inicial,act;
	
	public Nodo getAct() {
		return act;
	}
	public Nodo getInicial() {
		return inicial;
	}
	public void setAct(Nodo nodo) {
		act = nodo;
	}
	public void setInicial(Nodo nodo) {
		inicial = nodo;
	}
	public void begin(){
		this.act=this.inicial;
	}
	public void next(){
		
        this.act=act.getSig();
	}
	public boolean end(){
		if (this.act.getSig()== null){
			return true;
		}else{
			return false;
		}
	}
	public String get(){
		
        return this.act.getDato();
	}
	public String get(int x){
		for (int i=0;i<x;i++){
			this.next();
		}
		return act.getDato();
	}
	public boolean add (String args,int pos){
		Nodo nodo=new Nodo();
		nodo.setDato(args);
		int posact=0;
		this.begin();
		if (pos==0){
			nodo.setSig(this.act);
			this.setInicial(nodo);
			return true;
		}else{
			while((act.getSig()!=null)&& ((pos-1)!=posact))
			{
				this.next();
				posact++;
			}if((pos-1)==posact){
				nodo.setSig(this.act.getSig());
				act.setSig(nodo);
				return true;	}
			else {
					return false;
				}}
	}
	public void remove(){
		if (act==inicial)
		{
			this.next();
			inicial.setSig(act.getSig());
		}else{
			Nodo aux= new Nodo();
			aux=act;
			this.next();
			aux.setSig(act.getSig());
		}
	}
	public void remove(int pos){
		this.begin();
		for(int i=0;pos-1>i;i++){
			this.next();
		}
		Nodo aux= new Nodo();
		aux=act;
		this.next();
		aux.setSig(act.getSig());
	}
	public boolean isEmpty(){
		return inicial==null;
	}
	public boolean includes(String elem){
		this.begin();
		while((act.getSig()!=null)&&(act.getDato()!=elem)){
			this.next();
		}
		return act.getDato()==elem;
		
	}
	public int size(){
		Nodo n=new Nodo();
		n=this.getInicial();
		int cant=0;
		while(n.getSig()!= null){
			cant++;
			n=n.getSig();
		}
		cant++;
		return cant;
	}
	
    
	
}
	

