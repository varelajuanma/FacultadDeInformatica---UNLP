//main basico para resolucion de grafos tipo: Grafo no dirigido conexo pesado.

public class Macba {
	public ListaEnlazadaGenerica<Vertice<Sala>> mejorRecorrido(Grafo<Sala> grafo,
																	Vertice<Sala> entrada) {
																	
		//Preparamos el vector de visitados.
		boolean[] visitados = new boolean[grafo.listaDeVertices().tamanio()];
		//Creamos las listas de camino actual y mejor camino.
		ListaEnlazadaGenerica<Vertice<Sala>> caminoActual = new ListaEnlazadaGenerica<Vertice<Sala>>();
		ListaEnlazadaGenerica<Vertice<Sala>> mejorCamino = new ListaEnlazadaGenerica<Vertice<Sala>>();
		//Inicializamos una constante (por el ejercicio) de 120 minutos. 
		int minutos = 120;
		//Inicializamos un contador para saber cuanto tiempo vamos recorriendo.
		int[] contadorMinutos = { 0 };
		//llamamos al dfs con todos los parametros.
		dfs(visitados, grafo, entrada, caminoActual, mejorCamino, minutos, contadorMinutos);
		return mejorCamino;

	}

	private void dfs(boolean[] visitados, Grafo<Sala> grafo, Vertice<Sala> entrada,
							ListaEnlazadaGenerica<Vertice<Sala>> caminoActual,
							ListaEnlazadaGenerica<Vertice<Sala>> mejorCamino, int minutos,
							int[] contadorMinutos) {

		//Preguntamos si nuestra constante (120) es mayor al tiempo que vamos recorriendo:
		//si es mayor (todavia podemos recorrer).
		if (minutos > contadorMinutos[0]) {
			//marcamos la sala como visitada (cada sitio tiene una hubicacion dentro del grafo).
			visitados[entrada.getPosicion()] = true;
			//incrementamos el tiempo que vamos recorriendo con el tiempo que tiene la sala.
			contadorMinutos[0] = contadorMinutos[0] + entrada.getDato().getMinutos();
			//agregamos la sala al camino actual.
			caminoActual.agregar(entrada, caminoActual.tamanio());
			//Creamos la lista de adyacentes y la cargamos con los adyacentes de la sala actual.
			//ACLARACION: la arista es de tipo sala por practicidad, el pasillo tiene
							//un peso, en minutos, y el nombre no lo usamos.
			ListaGenerica<Arista<Sala>> ady = grafo.listaDeAdyacentes(entrada);
			//nos posicionamos al principio de la lista de adyacentes.
			ady.comenzar();
			//mientras la lista de adyacentes no se termine...
			while (!ady.fin()) {
				//si la sala no esta visitada en el vector "visitados".
				if (!visitados[ady.elemento().getVerticeDestino().getPosicion()]) {
					//incrementamos el tiempo del recorrido con el tiempo del pasillo (arista).
					contadorMinutos[0] = contadorMinutos[0] + ady.elemento().getPeso();
					//llamamos recursivamente al dfs pero ahora, la "entrada" es el vertice
					// destino de la arista en la que estamos.
					dfs(visitados, grafo, ady.elemento().getVerticeDestino(),
							caminoActual, mejorCamino, minutos, contadorMinutos);
					//cuando vuelve de la recursion desahacemos los cambios realizados...
					//restamos el tiempo del pasillo(arista) y del sitio (vertice) que
					//sumamos anteriormente.
					contadorMinutos[0] = contadorMinutos[0] - ady.elemento().getPeso();
					contadorMinutos[0] = contadorMinutos[0] - entrada.getDato().getMinutos();
					//tambien removemos el sitio del camino actual.
					caminoActual.eliminar(caminoActual.tamanio() - 1);
					//y marcamos nuevamente al sitio como no visitado en el vector "visitados"
					visitados[entrada.getPosicion()] = false;
				}
				//avanzamos en la lista de adyacentes.
				ady.proximo();
			}
		//si entramos al "else" es porque se acabo el tiempo o estamos estamos en la salida
		} else {
			//preguntamos si la lista esta vacia por la primera vez que entremos.
			if (mejorCamino.esVacia())
				//asignamos el camino actual como mejor camino.
				mejorCamino = ((ListaEnlazadaGenerica<Vertice<Sala>>) caminoActual).clone();

			else {
				�//preguntamos si el camino actual es mejor que el que ya teniamos(mejorCamino).
				if (caminoActual.tamanio() > mejorCamino.tamanio())
			//deberiamos preguntar si la cant de minutos es mayor a 120 para restar la ultima sala
					mejorCamino = ((ListaEnlazadaGenerica<Vertice<Sala>>) caminoActual).clone();
			}
		}
	}
}

public class Sala{
	   private String nombre;
	   private int minutos;
	//Setter y getters creados.
}
