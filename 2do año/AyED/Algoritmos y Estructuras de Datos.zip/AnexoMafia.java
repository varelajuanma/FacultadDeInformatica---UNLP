package TP7;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;

public class AnexoMafia<T> {

	public void dfs(Grafo<T> grafo,Vertice<T> CasaDelIntendente)
	{
		
		Stack<Vertice<T>> camino = new Stack<Vertice<T>>();
		Stack<Vertice<T>> caminoMinimo = new Stack<Vertice<T>>();
		
		Integer[] numeroDeMafiasEnCamino = new Integer[0];
		int    numeroActualDeMafiasEnCamino = 0;
		boolean[]  marca = new boolean[grafo.listaDeVertices().size()];
		
		numeroDeMafiasEnCamino[0] = Integer.MAX_VALUE;
		
		//Lo pongo como arreglo para que se pase por refencia
		
		for(int i=0;i<grafo.listaDeVertices().size();i++)
		{
			if(!marca[i])
			{
				dfs(i,grafo,marca,camino,caminoMinimo,numeroDeMafiasEnCamino,numeroActualDeMafiasEnCamino,CasaDelIntendente);
			}
		}
	}

	private void dfs(int i,Grafo<T> grafo,boolean[] marca,
					Stack<Vertice<T>> camino,Stack<Vertice<T>> caminoMinimo,
					Integer[] numeroDeMafiasEnCamino,int numeroActualDeMafiasEnCamino,
					Vertice<T> CasaDelIntendente)
	{
		marca[i] = true;
		VerticeLista<T> vertice = (VerticeLista<T>)grafo.vertice(i);
		
		if( vertice.controladoPorMafia() )
		{
			numeroActualDeMafiasEnCamino += 1;
		}
		
		camino.push(vertice);
		
		LinkedList<Arista<T>> ListaAristas = grafo.listaDeAdyacentes(vertice);
		Iterator<Arista<T>> iterador = ListaAristas.iterator();
		
		while(iterador.hasNext())
		{
			AristaImpl<T> arista = (AristaImpl<T>) iterador.next();
			if(!marca[arista.verticeDestino().posicion()])
			{
				if( arista.controladoPorMafia() )
				{
					numeroActualDeMafiasEnCamino += 1;
				}
				
				if(arista.verticeDestino() != CasaDelIntendente )
				{
					int j = arista.verticeDestino().posicion();
					this.dfs(j, grafo, marca,camino,caminoMinimo,numeroDeMafiasEnCamino,numeroActualDeMafiasEnCamino,CasaDelIntendente);
				} else {
					// Si es la casa
					
					camino.push(arista.verticeDestino()); //Para que se guarde la casa del intendente
					
					if(numeroActualDeMafiasEnCamino < numeroDeMafiasEnCamino[0])
					{
						numeroDeMafiasEnCamino[0] = numeroActualDeMafiasEnCamino;
						caminoMinimo = camino;
					}
					
					camino.pop(); // Saco la casa del intendente
				}
				
			}
		}
		
		camino.pop();
		
	}
	
}
