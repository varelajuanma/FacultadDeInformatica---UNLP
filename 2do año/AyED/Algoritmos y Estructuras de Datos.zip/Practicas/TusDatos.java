
public class TusDatos {

	public static void main(String[] args) {
	
		String nombre = args[0];
		String apellido = args[1];
		int codigopostal = 46859;
		String colorFavorito = "Rojo";
		System.out.println("Hola " + Nombre +" " + apellido);
		System.out.println("Tu codigo postal es: " + codigoPostal);
		System.out.println("Tu color favorito es: " + Colorfavorito);
	}

}
