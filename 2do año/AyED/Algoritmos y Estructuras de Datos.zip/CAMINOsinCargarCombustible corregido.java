public ListaGenerica<String> caminoSinCargarCombustible(String ciudad1, String ciudad2, int tanqueAuto){
	
	//asumimos que las ciudades existen en el grafo
	ListaGenerica<String> lista = new ListaGenerica<String>(); 		//creamos las lista que vamos a devolver
	
	//ahora buscamos la posicion del vertice con la ciudad1 para comenzar nuestra busquede desde este origen
		
	ListaGenerica<Vertice<String>> lisVerti = grafo.listaDeVertices(); //pedimos la lista de vertices
	
	lisVerti.comenzar();	//preparamos para comenzar a iterar
	int pos1=-1;
		
		while(pos1=-1){		//Estamos seguros de que la ciudad existe, por lo tanto sabes que el valor de "pos1" va a cambiar si o si!
			
			if(lisVerti.elemento().dato()==ciudad1)
				pos1=lisVerti.elemento().posicion();
			
			lisVerti.proximo();
		}
	
	//ahora crearemos el vector donde marcaremos como visitados los vertices
	
	boolean[] marca = new boolean[lisVerti.tamanio];
		
		for(int i=0; i<marca.lenght; i++)
			marca[i]=0;
		
	 //y ahora creamos un vector de enteros donde guardaremos dos cosas
		//1ro) lo que se le va sumando y restando al tanque segun sean los pesos de la arista
		//2do) lo dejaremos con un numero -1 y en el momento que encontremos un camino que cumpla condicion, cortamos la buqueda cambiando este valor
		
		int[] tanque = new int[]{tanqueAuto,-1};
		
		// ahora llamamos a un metodo auxiliar que con uso de la recursion resolvera el problema
		//le pasamos la lista, el vector de marcas, el vector de tanques, el vertice origen, dato del vertice destino
		
		combustible(lista,marca,tanque,grafo.vertice(pos1),ciudad2);
		
		if(tanque[2]!=-1)
			return lista;
		else {lista=null;
				return lista;
			}
}

public void combustible(ListaGenerica<String> lista, boolean[] marca, int[] tanque, Vertice<String> v, String ciudad2){
	
	if(v.dato()==ciudad2){
		tanque[1]=999; //esto nos va a permitir cortar la busqueda
	}
	else{	if(!marca[v.posicion()]){
				
				ListaGenerica<Arista> aristas = v.obtenerAdyacentes();	//obtenemos la lista de adyacentes para empezar a recorrerla
				aristas.comenzar();
				marca[v.posicion()]=true; //lo marcamos para no caer en un ciclo
				lista.agregar(v.dato(),lista.tamanio);	//con esto lo agregamos al ultimo;
					while(!aristas.esFin())&&(tanque[1]==-1){ //aca verificamos que mientras no es fin de los adyacentes y mientras no encontre el camino, sigo buscando
						
						tanque[0] -= aristas.elemento().peso(); //restamos la nafta que nos costara para ir al siguiente adyacente (verticeDestino)
						
						if(tanque[0] > 0) 				//si la nafta alcanzo entonces voy por ese camino
							combustible(lista,marca,tanque,aristas.elemento().verticeDestino(),ciudad2);
			
						tanque[0] += aristas.elemento().peso();	//si no alcanzo o volvio del camino porque no era sumo de nuevo la nafta
						aristas.proximo();		//paso al proximo
						
					}
				lista.eliminar(lista.tamanio);	//si llegamos a este punto es porque el vetice no estaba en el camino y por eso lo eliminamos de la lista
				marca[v.posicion()]=false;	//	lo desmarcamos por si en algun otro camino que se forme pasamos por este vertices
					
			}
		}

}





























