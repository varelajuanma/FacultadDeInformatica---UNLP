public int ancho(){
		NodoGeneral ag=this.raiz;
		Cola cola=new Cola();
		if(ag!=null){
			cola.encolar(ag);
			cola.encolar("null");
			int max=0;
			int cant=0;
			while(!cola.esVacia()){
				Object elem=cola.desencolar();
				if(!elem.equals("null")){
						NodoGeneral nodoAux=(NodoGeneral)elem;
						cant++;
						Lista hijos=nodoAux.getListaHijos();
						if(!hijos.esVacia()){
						
							//si es hoja tiene null en hijos
							hijos.comenzar();
							while(!hijos.fin()){
								cola.enconlar(hijos.elemento());
								hijos.proximo();
							}
						}
				}else{
					//cambio de nivel
					max=Math.max(max,cant);
					cant=0;
					if(!cola.esVacia()){
						cola.encolar("null");
					}
				}
			}
			return max;		
	}
	}