package tp07.ejercicio2;

public interface ColaPrioridades<T extends Comparable<T>> {
	public abstract boolean esVacia();  
	public abstract T eliminar();  
	public abstract boolean agregar(T elemento);
	public abstract T tope();
}
