package tp07.ejercicio2;

import listasgenericas.ListaGenerica;

public class MaxHeap<T extends Comparable<T>> implements ColaPrioridades<T> {

	@SuppressWarnings("unchecked")
	private T[] datos = (T[]) new Comparable[100]; 
	private int cantEltos = 0;

	public MaxHeap() {
	}

	public MaxHeap(ListaGenerica<T> lista){
		lista.comenzar();
		while(!lista.fin()){			
			this.agregar(lista.proximo());
		}
	}

	public MaxHeap(T[] datos) {
		this.cantEltos = 0;
		for (int i = 0; i < datos.length; i++) {
			cantEltos++;
			this.datos[cantEltos] = datos[i];
		}
		for (int i = cantEltos/2; i>0; i--) {
			percolate_down(i);
		}
	}

	public boolean esVacia() {
		if (this.cantEltos>0) {
			return false;
		}
		return true;
	}

	public T eliminar() {
		T elemento = null;
		if (this.cantEltos > 0) {
			elemento = this.datos[1];
			this.datos[1] = this.datos[this.cantEltos];
			this.cantEltos--;
			this.percolate_down(1);
			return elemento;
		}
		return elemento;
	}

	public boolean agregar(T elemento) {
		this.cantEltos++;
		this.datos[cantEltos] = elemento;
		this.percolate_up();
		return true;
	}

	 
	private void percolate_up() {
		T temporal = (T) datos[cantEltos];
		int indice = cantEltos;
		while (indice/2> 0
				&& (datos[indice/2]).compareTo(temporal)>0) {
			datos[indice] = datos[indice/2];
			indice = indice/2;
		}
		datos[indice] = temporal;
	}

 
	private void percolate_down(int posicion) {
		T candidato = this.datos[posicion];
		boolean detener_percolate = false;
		while (2 * posicion <= this.cantEltos && !detener_percolate) {
			int hijo_minimo = 2 * posicion; // buscar el hijo con clave menor
			if (hijo_minimo != this.cantEltos) {
				if (this.datos[hijo_minimo + 1].compareTo(this.datos[hijo_minimo]) < 0) {
					hijo_minimo++;
				}
			}
			if (candidato.compareTo(this.datos[hijo_minimo]) > 0) {
				this.datos[posicion] = this.datos[hijo_minimo];
				posicion = hijo_minimo;
			} else {
				detener_percolate = true;
			}
		}
		this.datos[posicion] = candidato;
	}

	public void imprimir() {
		for (int i = 1; i <= this.cantEltos; i++) {
			if (this.datos[i] == null) {
				break;
			}
			System.out.println(this.datos[i]);

		}
	}

	@Override
	public T tope() {
		// TODO Auto-generated method stub
		return this.datos[1];
	}
	
}
