package tp04.ej3;
public class TestNodo {

	public static void main(String[] args) {
		NodoBinario<Integer> n = new NodoMax<Integer>(5);
	}

}
