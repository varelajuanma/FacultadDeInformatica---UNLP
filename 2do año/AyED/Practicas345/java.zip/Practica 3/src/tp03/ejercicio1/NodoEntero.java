package tp03.ejercicio1;

public class NodoEntero {
	private Integer dato;
	private NodoEntero siguiente;
	
	public Integer getDato() {
		return dato;
	}
	public void setDato(Integer dato) {
		this.dato = dato;
	}
	public NodoEntero getSiguiente() {
		return siguiente;
	}
	public void setSiguiente(NodoEntero siguiente) {
		this.siguiente = siguiente;
	}

}