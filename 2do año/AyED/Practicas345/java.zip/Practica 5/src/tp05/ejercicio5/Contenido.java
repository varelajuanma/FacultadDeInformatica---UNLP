package tp05.ejercicio5;

public class Contenido {
	private String nombre;
	private String tema;
	private int pagin;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTema() {
		return tema;
	}
	public void setTema(String tema) {
		this.tema = tema;
	}
	public int getPagin() {
		return pagin;
	}
	public void setPagin(int pagin) {
		this.pagin = pagin;
	}
}
